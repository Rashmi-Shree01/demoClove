$(document).ready(function(){
    
    var yesterdayLabels = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24];
    var thisWeekLabels = ['Sunday', 'Monday', 'Tuesday'];
    var lastWeekLabels = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    var thisMonthLabels = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26];
    var lastMonthLabels = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31];
    var lastSixMonthLabels = ["Mar", "Apr", "May", "June", "July", "Aug"];
    var thisYearLabels = [ "Jan", "Feb", "Mar", "Apr", "May", "June", "July", "Aug", "Sep" ];

    customersThisMonthChanges();
    tableAlignment();
    $('.time-range').change(function() {
        var selectedRange = $(this).val();
        // alert(selectedRange);
        switch(selectedRange) {
            case 'Yesterday' :
                customersYesterdayChanges();
                tableAlignment();
                break;
            case 'This Week'    :
                customersThisWeekChanges();
                tableAlignment();
                break;
            case 'Last week'    :
               // customersLastWeekChanges();
                break;
            case 'This Month'   :
                customersThisMonthChanges();
                tableAlignment();
                break;
            case 'Last month'   :
               // customersLastMonthChanges();
                break;
            case 'Last 6 month' :
               // customersLastSixMonthChanges();
                break;
            case 'Year'    :
                customersYearChanges();
                tableAlignment();
                break;
            default             :
                customersThisMonthChanges();
                tableAlignment();
                break;
        }
    });

    //customers yesterday changes
    function customersYesterdayChanges() {

        //top row
        //add data in text()
        $('#totalCustomersHere').text('891');
        $('#totalCustomerTrend').text('8%').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#avgLtvCustomer').text('318');
        $('#avgLTVTrend').text('5%').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');
        $('#avgOrdersHere').text('3');
        $('#avgOrdersTrend').text('0.40%').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#reorderFrequencyCustomer').text('-');
        $('#reorderFrequencyTrend').text('-'); //.append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>')

        //customer funnel
        //change customerFunnelData for timeline
        var customerFunnelData = [
            {
                "label": "Visitors",
                "value": "8853"
            },
            {
                "label": "Viewed Products",
                "value": "7702"
            },
            {
                "label": "Added to Cart",
                "value": "2696"
            },
            {
                "label": "Order placed",
                "value": "891"
            }
        ];
        $('#funnelThisWeek').hide();
        $('#funnelLastWeek').hide();
        $('#funnelThisMonth').hide();
        $('#funnelLastMonth').hide();
        $('#funnelLastSixMonth').hide();
        $('#funnelYear').hide();
        $('#funnelYesterday').show();
        customerFunnel('funnelYesterday',customerFunnelData);

        //retention table
        //change retentionTable for timeline
        var retentionTable = {
            "20/May/2018": {
                "custCount": "1098",
                "retention": {
                    "day0": "100",
                    "day1": "33.9",
                    "day2": "23.5",
                    "day3": "18.7",
                    "day4": "15.9",
                    "day5": "16.3",
                    "day6": "14.2"
                }
            },
            "21/May/2018": {
                "custCount": "1358",
                "retention": {
                    "day0": "100",
                    "day1": "31.1",
                    "day2": "18.6",
                    "day3": "14.3",
                    "day4": "16.0",
                    "day5": "14.9",
                    "day6": "0"
                }
            },
            "22/May/2018": {
                "custCount": "1257",
                "retention": {
                    "day0": "100",
                    "day1": "27.2",
                    "day2": "19.6",
                    "day3": "14.5",
                    "day4": "12.9",
                    "day5": "0",
                    "day6": "0"
                }
            },
            "23/May/2018": {
                "custCount": "1587",
                "retention": {
                    "day0": "100",
                    "day1": "17.9",
                    "day2": "14.6",
                    "day3": "14.8",
                    "day4": "0",
                    "day5": "0",
                    "day6": "0"
                }
            },
            "24/May/2018": {
                "custCount": "1758",
                "retention": {
                    "day0": "100",
                    "day1": "26.2",
                    "day2": "20.4",
                    "day3": "0",
                    "day4": "0",
                    "day5": "0",
                    "day6": "0"
                }
            },
            "25/May/2018": {
                "custCount": "1624",
                "retention": {
                    "day0": "100",
                    "day1": "26.4",
                    "day2": "0",
                    "day3": "0",
                    "day4": "0",
                    "day5": "0",
                    "day6": "0"
                }
            },
            "26/May/2018": {
                "custCount": "1541",
                "retention": {
                    "day0": "100",
                    "day1": "0",
                    "day2": "0",
                    "day3": "0",
                    "day4": "0",
                    "day5": "0",
                    "day6": "0"
                }
            }
        }

        $('#customerRetentionTable tbody').empty();
        customerRetention('customerRetentionTable',retentionTable);

        //customer details table
        //change customerTable for timeline
        customerTable = [
            {
                "customer": "Steve Rogers",
                "city": "New York",
                "ltv": "227",
                "totalOrders": "1",
                "avgQtyPerOrder": "2",
                "purchaseFrequency": "-",
                "lastOrderedDate": "2018-04-13",
                "channel": "Amazon",
                "device": "iOS"
            },
            {
                "customer": "Hugo Daniel",
                "city": "California",
                "ltv": "323",
                "totalOrders": "1",
                "avgQtyPerOrder": "1",
                "purchaseFrequency": "-",
                "lastOrderedDate": "2018-04-13",
                "channel": "eBay",
                "device": "Android"
            },
            {
                "customer": "Rosa carla",
                "city": "New York",
                "ltv": "190",
                "totalOrders": "1",
                "avgQtyPerOrder": "1",
                "purchaseFrequency": "-",
                "lastOrderedDate": "2018-04-13",
                "channel": "Flipkart",
                "device": "Desktop"
            },
            {
                "customer": "Henry Mark",
                "city": "California",
                "ltv": "210",
                "totalOrders": "1",
                "avgQtyPerOrder": "1",
                "purchaseFrequency": "-",
                "lastOrderedDate": "2018-04-13",
                "channel": "Amazon",
                "device": "Android"
            },
        ]
        customerDetails(customerTable);
    }

    //customers this week changes
    function customersThisWeekChanges() {

        //top row
        //add data in text()
        $('#totalCustomersHere').text('2,673');
        $('#totalCustomerTrend').text('10%').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#avgLtvCustomer').text('321');
        $('#avgLTVTrend').text('8%').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');
        $('#avgOrdersHere').text('4');
        $('#avgOrdersTrend').text('0.90%').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#reorderFrequencyCustomer').text('-');
        $('#reorderFrequencyTrend').text('-'); //.append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>')

        //customer funnel
        //change customerFunnelData for timeline
        var customerFunnelData = [
            {
                "label": "Visitors",
                "value": "44265"
            },
            {
                "label": "Viewed Products",
                "value": "38511"
            },
            {
                "label": "Added to Cart",
                "value": "13479"
            },
            {
                "label": "Order placed",
                "value": "2673"
            }
        ];
        $('#funnelLastWeek').hide();
        $('#funnelThisMonth').hide();
        $('#funnelLastMonth').hide();
        $('#funnelLastSixMonth').hide();
        $('#funnelYesterday').hide();
        $('#funnelYear').hide();
        $('#funnelThisWeek').show();
        customerFunnel('funnelThisWeek',customerFunnelData);

        //retention table
        //change retentionTable for timeline
        var retentionTable = {
            "20/May/2018": {
                "custCount": "1098",
                "retention": {
                    "day0": "100",
                    "day1": "33.9",
                    "day2": "23.5",
                    "day3": "18.7",
                    "day4": "15.9",
                    "day5": "16.3",
                    "day6": "14.2"
                }
            },
            "21/May/2018": {
                "custCount": "1358",
                "retention": {
                    "day0": "100",
                    "day1": "31.1",
                    "day2": "18.6",
                    "day3": "14.3",
                    "day4": "16.0",
                    "day5": "14.9",
                    "day6": "0"
                }
            },
            "22/May/2018": {
                "custCount": "1257",
                "retention": {
                    "day0": "100",
                    "day1": "27.2",
                    "day2": "19.6",
                    "day3": "14.5",
                    "day4": "12.9",
                    "day5": "0",
                    "day6": "0"
                }
            },
            "23/May/2018": {
                "custCount": "1587",
                "retention": {
                    "day0": "100",
                    "day1": "17.9",
                    "day2": "14.6",
                    "day3": "14.8",
                    "day4": "0",
                    "day5": "0",
                    "day6": "0"
                }
            },
            "24/May/2018": {
                "custCount": "1758",
                "retention": {
                    "day0": "100",
                    "day1": "26.2",
                    "day2": "20.4",
                    "day3": "0",
                    "day4": "0",
                    "day5": "0",
                    "day6": "0"
                }
            },
            "25/May/2018": {
                "custCount": "1624",
                "retention": {
                    "day0": "100",
                    "day1": "26.4",
                    "day2": "0",
                    "day3": "0",
                    "day4": "0",
                    "day5": "0",
                    "day6": "0"
                }
            },
            "26/May/2018": {
                "custCount": "1541",
                "retention": {
                    "day0": "100",
                    "day1": "0",
                    "day2": "0",
                    "day3": "0",
                    "day4": "0",
                    "day5": "0",
                    "day6": "0"
                }
            }
        }

        $('#customerRetentionTable tbody').empty();
        customerRetention('customerRetentionTable',retentionTable);

        //customer details table
        //change customerTable for timeline
        customerTable = [
            {
                "customer": "Steve Rogers",
                "city": "New York",
                "ltv": "227",
                "totalOrders": "3",
                "avgQtyPerOrder": "2",
                "purchaseFrequency": "2",
                "lastOrderedDate": "2018-04-13",
                "channel": "Amazon",
                "device": "iOS"
            },
            {
                "customer": "Hugo Daniel",
                "city": "California",
                "ltv": "323",
                "totalOrders": "3",
                "avgQtyPerOrder": "1",
                "purchaseFrequency": "1",
                "lastOrderedDate": "2018-04-13",
                "channel": "eBay",
                "device": "Android"
            },
            {
                "customer": "Rosa carla",
                "city": "New York",
                "ltv": "190",
                "totalOrders": "3",
                "avgQtyPerOrder": "1",
                "purchaseFrequency": "1",
                "lastOrderedDate": "2018-04-13",
                "channel": "Flipkart",
                "device": "Desktop"
            },
            {
                "customer": "Henry Mark",
                "city": "Calfornia",
                "ltv": "210",
                "totalOrders": "3",
                "avgQtyPerOrder": "1",
                "purchaseFrequency": "1",
                "lastOrderedDate": "2018-04-13",
                "channel": "Amazon",
                "device": "Android"
            },
        ]
        customerDetails(customerTable);
    }

    //customers last week changes
    function customersLastWeekChanges() {

        //top row
        //add data in text()
        $('#totalCustomersHere').text('');
        $('#totalCustomerTrend').text('').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#avgLtvCustomer').text('');
        $('#avgLTVTrend').text('').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');
        $('#avgOrdersHere').text('');
        $('#avgOrdersTrend').text('').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#reorderFrequencyCustomer').text('');
        $('#reorderFrequencyTrend').text('').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');

        //customer funnel
        //change customerFunnelData for timeline
        var customerFunnelData = [
            {
                "label": "Landing",
                "value": "100"
            },
            {
                "label": "Product View",
                "value": "82"
            },
            {
                "label": "Added to Cart",
                "value": "56"
            },
            {
                "label": "Checkout",
                "value": "21"
            }
        ];
        
        $('#funnelThisMonth').hide();
        $('#funnelLastMonth').hide();
        $('#funnelLastSixMonth').hide();
        $('#funnelYesterday').hide();
        $('#funnelThisWeek').hide();
        $('#funnelYear').hide();
        $('#funnelLastWeek').show();
        customerFunnel('funnelLastWeek',customerFunnelData);

        //retention table
        //change retentionTable for timeline
        var retentionTable = {
            "20/May/2018": {
                "custCount": "1098",
                "retention": {
                    "day0": "100",
                    "day1": "33.9",
                    "day2": "23.5",
                    "day3": "18.7",
                    "day4": "15.9",
                    "day5": "16.3",
                    "day6": "14.2"
                }
            },
            "21/May/2018": {
                "custCount": "1358",
                "retention": {
                    "day0": "100",
                    "day1": "31.1",
                    "day2": "18.6",
                    "day3": "14.3",
                    "day4": "16.0",
                    "day5": "14.9",
                    "day6": "0"
                }
            },
            "22/May/2018": {
                "custCount": "1257",
                "retention": {
                    "day0": "100",
                    "day1": "27.2",
                    "day2": "19.6",
                    "day3": "14.5",
                    "day4": "12.9",
                    "day5": "0",
                    "day6": "0"
                }
            },
            "23/May/2018": {
                "custCount": "1587",
                "retention": {
                    "day0": "100",
                    "day1": "17.9",
                    "day2": "14.6",
                    "day3": "14.8",
                    "day4": "0",
                    "day5": "0",
                    "day6": "0"
                }
            },
            "24/May/2018": {
                "custCount": "1758",
                "retention": {
                    "day0": "100",
                    "day1": "26.2",
                    "day2": "20.4",
                    "day3": "0",
                    "day4": "0",
                    "day5": "0",
                    "day6": "0"
                }
            },
            "25/May/2018": {
                "custCount": "1624",
                "retention": {
                    "day0": "100",
                    "day1": "26.4",
                    "day2": "0",
                    "day3": "0",
                    "day4": "0",
                    "day5": "0",
                    "day6": "0"
                }
            },
            "26/May/2018": {
                "custCount": "1541",
                "retention": {
                    "day0": "100",
                    "day1": "0",
                    "day2": "0",
                    "day3": "0",
                    "day4": "0",
                    "day5": "0",
                    "day6": "0"
                }
            }
        }
        
        $('#customerRetentionTable tbody').empty();
        customerRetention('customerRetentionTable',retentionTable);

        //customer details table
        //change customerTable for timeline
        customerTable = [
            {
                "customer": "Steve Rogers",
                "city": "New Delhi",
                "ltv": "250",
                "totalOrders": "2",
                "avgQtyPerOrder": "1",
                "purchaseFrequency": "0",
                "lastOrderedDate": "2018-04-13",
                "channel": "Amazon",
                "device": "Mobile"
            },
            {
                "customer": "Bruce Wayne",
                "city": "Lucknow",
                "ltv": "621",
                "totalOrders": "3",
                "avgQtyPerOrder": "3",
                "purchaseFrequency": "0",
                "lastOrderedDate": "2018-04-13",
                "channel": "eBay",
                "device": "Mobile"
            },
            {
                "customer": "Hal Jordan",
                "city": "Bangalore",
                "ltv": "541",
                "totalOrders": "2",
                "avgQtyPerOrder": "1",
                "purchaseFrequency": "0",
                "lastOrderedDate": "2018-04-13",
                "channel": "Flipkart",
                "device": "Tablet"
            },
            {
                "customer": "Tony Stark",
                "city": "Chennai",
                "ltv": "369",
                "totalOrders": "1",
                "avgQtyPerOrder": "1",
                "purchaseFrequency": "0",
                "lastOrderedDate": "2018-04-13",
                "channel": "Amazon",
                "device": "Desktop"
            },
            {
                "customer": "Bruce Banner",
                "city": "Ahemdabad",
                "ltv": "584",
                "totalOrders": "4",
                "avgQtyPerOrder": "2",
                "purchaseFrequency": "0",
                "lastOrderedDate": "2018-04-13",
                "channel": "Amazon",
                "device": "Tablet"
            }
        ]
        customerDetails(customerTable);
    }

    //customers this month changes
    function customersThisMonthChanges() {

        //top row
        //add data in text()
        $('#totalCustomersHere').text('17,820');
        $('#totalCustomerTrend').text('15%').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#avgLtvCustomer').text('330');
        $('#avgLTVTrend').text('13%').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');
        $('#avgOrdersHere').text('2');
        $('#avgOrdersTrend').text('1.10%').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#reorderFrequencyCustomer').text('-');
        $('#reorderFrequencyTrend').text('-');//.append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>')

        //customer funnel
        //change customerFunnelData for timeline
        var customerFunnelData = [
            {
                "label": "Visitors",
                "value": "177060"
            },
            {
                "label": "Viewed Products",
                "value": "154042"
            },
            {
                "label": "Added to Cart",
                "value": "53915"
            },
            {
                "label": "Order placed",
                "value": "17820"
            }
        ];
        
        $('#funnelLastMonth').hide();
        $('#funnelLastSixMonth').hide();
        $('#funnelYesterday').hide();
        $('#funnelThisWeek').hide();
        $('#funnelLastWeek').hide();
        $('#funnelYear').hide();
        $('#funnelThisMonth').show();
        customerFunnel('funnelThisMonth',customerFunnelData);

        //retention table
        //change retentionTable for timeline
        var retentionTable = {
            "20/May/2018": {
                "custCount": "1098",
                "retention": {
                    "day0": "100",
                    "day1": "33.9",
                    "day2": "23.5",
                    "day3": "18.7",
                    "day4": "15.9",
                    "day5": "16.3",
                    "day6": "14.2"
                }
            },
            "21/May/2018": {
                "custCount": "1358",
                "retention": {
                    "day0": "100",
                    "day1": "31.1",
                    "day2": "18.6",
                    "day3": "14.3",
                    "day4": "16.0",
                    "day5": "14.9",
                    "day6": "0"
                }
            },
            "22/May/2018": {
                "custCount": "1257",
                "retention": {
                    "day0": "100",
                    "day1": "27.2",
                    "day2": "19.6",
                    "day3": "14.5",
                    "day4": "12.9",
                    "day5": "0",
                    "day6": "0"
                }
            },
            "23/May/2018": {
                "custCount": "1587",
                "retention": {
                    "day0": "100",
                    "day1": "17.9",
                    "day2": "14.6",
                    "day3": "14.8",
                    "day4": "0",
                    "day5": "0",
                    "day6": "0"
                }
            },
            "24/May/2018": {
                "custCount": "1758",
                "retention": {
                    "day0": "100",
                    "day1": "26.2",
                    "day2": "20.4",
                    "day3": "0",
                    "day4": "0",
                    "day5": "0",
                    "day6": "0"
                }
            },
            "25/May/2018": {
                "custCount": "1624",
                "retention": {
                    "day0": "100",
                    "day1": "26.4",
                    "day2": "0",
                    "day3": "0",
                    "day4": "0",
                    "day5": "0",
                    "day6": "0"
                }
            },
            "26/May/2018": {
                "custCount": "1541",
                "retention": {
                    "day0": "100",
                    "day1": "0",
                    "day2": "0",
                    "day3": "0",
                    "day4": "0",
                    "day5": "0",
                    "day6": "0"
                }
            }
        }

        $('#customerRetentionTable tbody').empty();
        customerRetention('customerRetentionTable',retentionTable);

        //customer details table
        //change customerTable for timeline
        customerTable = [
            {
                "customer": "Steve Rogers",
                "city": "New York",
                "ltv": "227",
                "totalOrders": "7",
                "avgQtyPerOrder": "2",
                "purchaseFrequency": "20",
                "lastOrderedDate": "2018-04-13",
                "channel": "Amazon",
                "device": "iOS"
            },
            {
                "customer": "Hugo Daniel",
                "city": "Calfornia",
                "ltv": "323",
                "totalOrders": "4",
                "avgQtyPerOrder": "1",
                "purchaseFrequency": "45",
                "lastOrderedDate": "2018-04-13",
                "channel": "eBay",
                "device": "Android"
            },
            {
                "customer": "Rosa carla",
                "city": "New York",
                "ltv": "190",
                "totalOrders": "4",
                "avgQtyPerOrder": "1",
                "purchaseFrequency": "55",
                "lastOrderedDate": "2018-04-13",
                "channel": "Flipkart",
                "device": "Desktop"
            },
            {
                "customer": "Henry Mark",
                "city": "Calfornia",
                "ltv": "210",
                "totalOrders": "2",
                "avgQtyPerOrder": "1",
                "purchaseFrequency": "75",
                "lastOrderedDate": "2018-04-13",
                "channel": "Amazon",
                "device": "Android"
            },
        ]
        customerDetails(customerTable);
    }

    //customers last month changes
    function customersLastMonthChanges() {

        //top row
        //add data in text()
        $('#totalCustomersHere').text('');
        $('#totalCustomerTrend').text('').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#avgLtvCustomer').text('');
        $('#avgLTVTrend').text('').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');
        $('#avgOrdersHere').text('');
        $('#avgOrdersTrend').text('').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#reorderFrequencyCustomer').text('');
        $('#reorderFrequencyTrend').text('').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');

        //customer funnel
        //change customerFunnelData for timeline
        var customerFunnelData = [
            {
                "label": "Landing",
                "value": "100"
            },
            {
                "label": "Product View",
                "value": "82"
            },
            {
                "label": "Added to Cart",
                "value": "56"
            },
            {
                "label": "Checkout",
                "value": "21"
            }
        ];
        $('#funnelLastSixMonth').hide();
        $('#funnelYesterday').hide();
        $('#funnelThisWeek').hide();
        $('#funnelLastWeek').hide();
        $('#funnelThisMonth').hide();
        $('#funnelYear').hide();
        $('#funnelLastMonth').show();
        customerFunnel('funnelLastMonth',customerFunnelData);

        //retention table
        //change retentionTable for timeline
        var retentionTable = {
            "20/May/2018": {
                "custCount": "1098",
                "retention": {
                    "day0": "100",
                    "day1": "33.9",
                    "day2": "23.5",
                    "day3": "18.7",
                    "day4": "15.9",
                    "day5": "16.3",
                    "day6": "14.2"
                }
            },
            "21/May/2018": {
                "custCount": "1358",
                "retention": {
                    "day0": "100",
                    "day1": "31.1",
                    "day2": "18.6",
                    "day3": "14.3",
                    "day4": "16.0",
                    "day5": "14.9",
                    "day6": "0"
                }
            },
            "22/May/2018": {
                "custCount": "1257",
                "retention": {
                    "day0": "100",
                    "day1": "27.2",
                    "day2": "19.6",
                    "day3": "14.5",
                    "day4": "12.9",
                    "day5": "0",
                    "day6": "0"
                }
            },
            "23/May/2018": {
                "custCount": "1587",
                "retention": {
                    "day0": "100",
                    "day1": "17.9",
                    "day2": "14.6",
                    "day3": "14.8",
                    "day4": "0",
                    "day5": "0",
                    "day6": "0"
                }
            },
            "24/May/2018": {
                "custCount": "1758",
                "retention": {
                    "day0": "100",
                    "day1": "26.2",
                    "day2": "20.4",
                    "day3": "0",
                    "day4": "0",
                    "day5": "0",
                    "day6": "0"
                }
            },
            "25/May/2018": {
                "custCount": "1624",
                "retention": {
                    "day0": "100",
                    "day1": "26.4",
                    "day2": "0",
                    "day3": "0",
                    "day4": "0",
                    "day5": "0",
                    "day6": "0"
                }
            },
            "26/May/2018": {
                "custCount": "1541",
                "retention": {
                    "day0": "100",
                    "day1": "0",
                    "day2": "0",
                    "day3": "0",
                    "day4": "0",
                    "day5": "0",
                    "day6": "0"
                }
            }
        }

        $('#customerRetentionTable tbody').empty();
        customerRetention('customerRetentionTable',retentionTable);

        //customer details table
        //change customerTable for timeline
        customerTable = [
            {
                "customer": "Steve Rogers",
                "city": "New Delhi",
                "ltv": "250",
                "totalOrders": "2",
                "avgQtyPerOrder": "1",
                "purchaseFrequency": "0",
                "lastOrderedDate": "2018-04-13",
                "channel": "Amazon",
                "device": "Mobile"
            },
            {
                "customer": "Bruce Wayne",
                "city": "Lucknow",
                "ltv": "621",
                "totalOrders": "3",
                "avgQtyPerOrder": "3",
                "purchaseFrequency": "0",
                "lastOrderedDate": "2018-04-13",
                "channel": "eBay",
                "device": "Mobile"
            },
            {
                "customer": "Hal Jordan",
                "city": "Bangalore",
                "ltv": "541",
                "totalOrders": "2",
                "avgQtyPerOrder": "1",
                "purchaseFrequency": "0",
                "lastOrderedDate": "2018-04-13",
                "channel": "Flipkart",
                "device": "Tablet"
            },
            {
                "customer": "Tony Stark",
                "city": "Chennai",
                "ltv": "369",
                "totalOrders": "1",
                "avgQtyPerOrder": "1",
                "purchaseFrequency": "0",
                "lastOrderedDate": "2018-04-13",
                "channel": "Amazon",
                "device": "Desktop"
            },
            {
                "customer": "Bruce Banner",
                "city": "Ahemdabad",
                "ltv": "584",
                "totalOrders": "4",
                "avgQtyPerOrder": "2",
                "purchaseFrequency": "0",
                "lastOrderedDate": "2018-04-13",
                "channel": "Amazon",
                "device": "Tablet"
            }
        ]
        customerDetails(customerTable);
    }

    //customers last six month changes
    function customersLastSixMonthChanges() {

        //top row
        //add data in text()
        $('#totalCustomersHere').text('');
        $('#totalCustomerTrend').text('').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#avgLtvCustomer').text('');
        $('#avgLTVTrend').text('').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');
        $('#avgOrdersHere').text('');
        $('#avgOrdersTrend').text('').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#reorderFrequencyCustomer').text('');
        $('#reorderFrequencyTrend').text('').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');

        //customer funnel
        //change customerFunnelData for timeline
        var customerFunnelData = [
            {
                "label": "Landing",
                "value": "100"
            },
            {
                "label": "Product View",
                "value": "82"
            },
            {
                "label": "Added to Cart",
                "value": "56"
            },
            {
                "label": "Checkout",
                "value": "21"
            }
        ];
        
        $('#funnelYesterday').hide();
        $('#funnelThisWeek').hide();
        $('#funnelLastWeek').hide();
        $('#funnelThisMonth').hide();
        $('#funnelLastMonth').hide();
        $('#funnelYear').hide();
        $('#funnelLastSixMonth').show();
        customerFunnel('funnelLastSixMonth',customerFunnelData);

        //retention table
        //change retentionTable for timeline
        var retentionTable = {
            "20/May/2018": {
                "custCount": "1098",
                "retention": {
                    "day0": "100",
                    "day1": "33.9",
                    "day2": "23.5",
                    "day3": "18.7",
                    "day4": "15.9",
                    "day5": "16.3",
                    "day6": "14.2"
                }
            },
            "21/May/2018": {
                "custCount": "1358",
                "retention": {
                    "day0": "100",
                    "day1": "31.1",
                    "day2": "18.6",
                    "day3": "14.3",
                    "day4": "16.0",
                    "day5": "14.9",
                    "day6": "0"
                }
            },
            "22/May/2018": {
                "custCount": "1257",
                "retention": {
                    "day0": "100",
                    "day1": "27.2",
                    "day2": "19.6",
                    "day3": "14.5",
                    "day4": "12.9",
                    "day5": "0",
                    "day6": "0"
                }
            },
            "23/May/2018": {
                "custCount": "1587",
                "retention": {
                    "day0": "100",
                    "day1": "17.9",
                    "day2": "14.6",
                    "day3": "14.8",
                    "day4": "0",
                    "day5": "0",
                    "day6": "0"
                }
            },
            "24/May/2018": {
                "custCount": "1758",
                "retention": {
                    "day0": "100",
                    "day1": "26.2",
                    "day2": "20.4",
                    "day3": "0",
                    "day4": "0",
                    "day5": "0",
                    "day6": "0"
                }
            },
            "25/May/2018": {
                "custCount": "1624",
                "retention": {
                    "day0": "100",
                    "day1": "26.4",
                    "day2": "0",
                    "day3": "0",
                    "day4": "0",
                    "day5": "0",
                    "day6": "0"
                }
            },
            "26/May/2018": {
                "custCount": "1541",
                "retention": {
                    "day0": "100",
                    "day1": "0",
                    "day2": "0",
                    "day3": "0",
                    "day4": "0",
                    "day5": "0",
                    "day6": "0"
                }
            }
        }

        $('#customerRetentionTable tbody').empty();
        customerRetention('customerRetentionTable',retentionTable);

        //customer details table
        //change customerTable for timeline
        customerTable = [
            {
                "customer": "Steve Rogers",
                "city": "New Delhi",
                "ltv": "250",
                "totalOrders": "2",
                "avgQtyPerOrder": "1",
                "purchaseFrequency": "0",
                "lastOrderedDate": "2018-04-13",
                "channel": "Amazon",
                "device": "Mobile"
            },
            {
                "customer": "Bruce Wayne",
                "city": "Lucknow",
                "ltv": "621",
                "totalOrders": "3",
                "avgQtyPerOrder": "3",
                "purchaseFrequency": "0",
                "lastOrderedDate": "2018-04-13",
                "channel": "eBay",
                "device": "Mobile"
            },
            {
                "customer": "Hal Jordan",
                "city": "Bangalore",
                "ltv": "541",
                "totalOrders": "2",
                "avgQtyPerOrder": "1",
                "purchaseFrequency": "0",
                "lastOrderedDate": "2018-04-13",
                "channel": "Flipkart",
                "device": "Tablet"
            },
            {
                "customer": "Tony Stark",
                "city": "Chennai",
                "ltv": "369",
                "totalOrders": "1",
                "avgQtyPerOrder": "1",
                "purchaseFrequency": "0",
                "lastOrderedDate": "2018-04-13",
                "channel": "Amazon",
                "device": "Desktop"
            },
            {
                "customer": "Bruce Banner",
                "city": "Ahemdabad",
                "ltv": "584",
                "totalOrders": "4",
                "avgQtyPerOrder": "2",
                "purchaseFrequency": "0",
                "lastOrderedDate": "2018-04-13",
                "channel": "Amazon",
                "device": "Tablet"
            }
        ]
        customerDetails(customerTable);
    }

    //customers this year changes
    function customersYearChanges() {

        //top row
        //add data in text()
        $('#totalCustomersHere').text('160,380');
        $('#totalCustomerTrend').text('20%').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#avgLtvCustomer').text('301');
        $('#avgLTVTrend').text('18%').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');
        $('#avgOrdersHere').text('4');
        $('#avgOrdersTrend').text('0.85%').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#reorderFrequencyCustomer').text('150');
        $('#reorderFrequencyTrend').text('2%').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');

        //customer funnel
        //change customerFunnelData for timeline
        var customerFunnelData = [
            {
                "label": "Visitors",
                "value": "1593540"
            },
            {
                "label": "Viewed Products",
                "value": "1386380"
            },
            {
                "label": "Added to Cart",
                "value": "485233"
            },
            {
                "label": "Order placed",
                "value": "160380"
            }
        ];
        $('#funnelYesterday').hide();
        $('#funnelThisWeek').hide();
        $('#funnelLastWeek').hide();
        $('#funnelThisMonth').hide();
        $('#funnelLastMonth').hide();
        $('#funnelLastSixMonth').hide();-
        $('#funnelYear').show();
        customerFunnel('funnelYear',customerFunnelData);

        //retention table
        //change retentionTable for timeline
        var retentionTable = {
            "20/May/2018": {
                "custCount": "1098",
                "retention": {
                    "day0": "100",
                    "day1": "33",
                    "day2": "23",
                    "day3": "18",
                    "day4": "15",
                    "day5": "16",
                    "day6": "14"
                }
            },
            "21/May/2018": {
                "custCount": "1358",
                "retention": {
                    "day0": "100",
                    "day1": "31.1",
                    "day2": "18.6",
                    "day3": "14.3",
                    "day4": "16.0",
                    "day5": "14.9",
                    "day6": "0"
                }
            },
            "22/May/2018": {
                "custCount": "1257",
                "retention": {
                    "day0": "100",
                    "day1": "27.2",
                    "day2": "19.6",
                    "day3": "14.5",
                    "day4": "12.9",
                    "day5": "0",
                    "day6": "0"
                }
            },
            "23/May/2018": {
                "custCount": "1587",
                "retention": {
                    "day0": "100",
                    "day1": "17.9",
                    "day2": "14.6",
                    "day3": "14.8",
                    "day4": "0",
                    "day5": "0",
                    "day6": "0"
                }
            },
            "24/May/2018": {
                "custCount": "1758",
                "retention": {
                    "day0": "100",
                    "day1": "26.2",
                    "day2": "20.4",
                    "day3": "0",
                    "day4": "0",
                    "day5": "0",
                    "day6": "0"
                }
            },
            "25/May/2018": {
                "custCount": "1624",
                "retention": {
                    "day0": "100",
                    "day1": "26.4",
                    "day2": "0",
                    "day3": "0",
                    "day4": "0",
                    "day5": "0",
                    "day6": "0"
                }
            },
            "26/May/2018": {
                "custCount": "1541",
                "retention": {
                    "day0": "100",
                    "day1": "0",
                    "day2": "0",
                    "day3": "0",
                    "day4": "0",
                    "day5": "0",
                    "day6": "0"
                }
            }
        }
        
        $('#customerRetentionTable tbody').empty();
        customerRetention('customerRetentionTable',retentionTable);

        //customer details table
        //change customerTable for timeline
        customerTable = [
            {
                "customer": "Steve Rogers",
                "city": "New York",
                "ltv": "227",
                "totalOrders": "35",
                "avgQtyPerOrder": "2",
                "purchaseFrequency": "19",
                "lastOrderedDate": "2018-04-13",
                "channel": "Amazon",
                "device": "iOS"
            },
            {
                "customer": "Hugo Daniel",
                "city": "Calfornia",
                "ltv": "323",
                "totalOrders": "20",
                "avgQtyPerOrder": "1",
                "purchaseFrequency": "49",
                "lastOrderedDate": "2018-04-13",
                "channel": "eBay",
                "device": "Android"
            },
            {
                "customer": "Rosa carla",
                "city": "New York",
                "ltv": "190",
                "totalOrders": "20",
                "avgQtyPerOrder": "1",
                "purchaseFrequency": "50",
                "lastOrderedDate": "2018-04-13",
                "channel": "Flipkart",
                "device": "Desktop"
            },
            {
                "customer": "Henry Mark",
                "city": "Calfornia",
                "ltv": "210",
                "totalOrders": "1",
                "avgQtyPerOrder": "1",
                "purchaseFrequency": "0",
                "lastOrderedDate": "2018-04-13",
                "channel": "Amazon",
                "device": "Desktop"
            }
        ]
        customerDetails(customerTable);
    }
});