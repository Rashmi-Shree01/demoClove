$(document).ready(function(){

    var gdpData = {"af":"16.63","al":"11.58","dz":"158.97","ao":"85.81","ag":"1.1","ar":"351.02","am":"8.83","au":"1219.72","at":"366.26","az":"52.17","bs":"7.54","bh":"21.73","bd":"105.4","bb":"3.96","by":"52.89","be":"461.33","bz":"1.43","bj":"6.49","bt":"1.4","bo":"19.18","ba":"16.2","bw":"12.5","br":"2023.53","bn":"11.96","bg":"44.84","bf":"8.67","bi":"1.47","kh":"11.36","cm":"21.88","ca":"1563.66","cv":"1.57","cf":"2.11","td":"7.59","cl":"199.18","cn":"5745.13","co":"283.11","km":"0.56","cd":"12.6","cg":"11.88","cr":"35.02","ci":"22.38","hr":"59.92","cy":"22.75","cz":"195.23","dk":"304.56","dj":"1.14","dm":"0.38","do":"50.87","ec":"61.49","eg":"216.83","sv":"21.8","gq":"14.55","er":"2.25","ee":"19.22","et":"30.94","fj":"3.15","fi":"231.98","fr":"2555.44","ga":"12.56","gm":"1.04","ge":"11.23","de":"3305.9","gh":"18.06","gr":"305.01","gd":"0.65","gt":"40.77","gn":"4.34","gw":"0.83","gy":"2.2","ht":"6.5","hn":"15.34","hk":"226.49","hu":"132.28","is":"12.77","in":"1430.02","id":"695.06","ir":"337.9","iq":"84.14","ie":"204.14","il":"201.25","it":"2036.69","jm":"13.74","jp":"5390.9","jo":"27.13","kz":"129.76","ke":"32.42","ki":"0.15","kr":"986.26","undefined":"5.73","kw":"117.32","kg":"4.44","la":"6.34","lv":"23.39","lb":"39.15","ls":"1.8","lr":"0.98","ly":"77.91","lt":"35.73","lu":"52.43","mk":"9.58","mg":"8.33","mw":"5.04","my":"218.95","mv":"1.43","ml":"9.08","mt":"7.8","mr":"3.49","mu":"9.43","mx":"1004.04","md":"5.36","mn":"5.81","me":"3.88","ma":"91.7","mz":"10.21","mm":"35.65","na":"11.45","np":"15.11","nl":"770.31","nz":"138","ni":"6.38","ne":"5.6","ng":"206.66","no":"413.51","om":"53.78","pk":"174.79","pa":"27.2","pg":"8.81","py":"17.17","pe":"153.55","ph":"189.06","pl":"438.88","pt":"223.7","qa":"126.52","ro":"158.39","ru":"1476.91","rw":"5.69","ws":"0.55","st":"0.19","sa":"434.44","sn":"12.66","rs":"38.92","sc":"0.92","sl":"1.9","sg":"217.38","sk":"86.26","si":"46.44","sb":"0.67","za":"354.41","es":"1374.78","lk":"48.24","kn":"0.56","lc":"1","vc":"0.58","sd":"65.93","sr":"3.3","sz":"3.17","se":"444.59","ch":"522.44","sy":"59.63","tw":"426.98","tj":"5.58","tz":"22.43","th":"312.61","tl":"0.62","tg":"3.07","to":"0.3","tt":"21.2","tn":"43.86","tr":"729.05","tm":0,"ug":"17.12","ua":"136.56","ae":"239.65","gb":"2258.57","us":"14624.18","uy":"40.71","uz":"37.72","vu":"0.72","ve":"285.21","vn":"101.99","ye":"30.02","zm":"15.69","zw":"5.57"};
    var max = 0,
        min = Number.MAX_VALUE,
        cc,
        startColor = [200, 238, 255],
        endColor = [0, 100, 145],
        colors = {},
        hex;

    //find maximum and minimum values
    for (cc in gdpData)
    {
        if (parseFloat(gdpData[cc]) > max)
        {
            max = parseFloat(gdpData[cc]);
        }
        if (parseFloat(gdpData[cc]) < min)
        {
            min = parseFloat(gdpData[cc]);
        }
    }

    //set colors according to values of GDP
    for (cc in gdpData)
    {
        if (gdpData[cc] > 0)
        {
            colors[cc] = '#';
            for (var i = 0; i<3; i++)
            {
                hex = Math.round(startColor[i]
                    + (endColor[i]
                    - startColor[i])
                    * (gdpData[cc] / (max - min))).toString(16);

                if (hex.length == 1)
                {
                    hex = '0'+hex;
                }

                colors[cc] += (hex.length == 1 ? '0' : '') + hex;
            }
        }
    }

    //country map
    function mapForCountry() {
        $('#seasonCountryMap').vectorMap({  
            enableZoom: true,
            colors: colors,
            hoverOpacity: 0.7,
            hoverColor: false,
            backgroundColor : 'transparent',
            showTooltip: true,
            onLabelShow : function(event, label, code) {
                var val = gdpData[code] == undefined ? 0 : gdpData[code];
                label.append(' : (Visits - ' + val + ')');
            }
        });
    }

    mapForCountry();

    // sales heatmap
    var margin = { top: 50, right: 0, bottom: 100, left: 30 },
                width = 650 - margin.left - margin.right,
                height = 350 - margin.top - margin.bottom,
                gridSize = Math.floor(width / 24),
                legendElementWidth = gridSize*2,
                buckets = 9,
                colors = ["#41b6c4","#1d91c0","#225ea8","#253494","#081d58"], 
                days = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
                times = ["12a", "2a", "4a", "6a", "8a", "10a", "12p", "2p", "4p", "6p", "8p", "10p"];
                datasets = ["data.tsv"];
  
    var svg = d3.select("#daySalesChart").append("svg")
        .attr("width", 350)
        .attr("height", 300)
        .append("g")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")");
        
    var dayLabels = svg.selectAll(".dayLabel")
        .data(days)
        .enter().append("text")
        .text(function (d) { return d; })
        .attr("x", 0)
        .attr("y", function (d, i) { return i * gridSize; })
        .style("text-anchor", "end")
        .attr("transform", "translate(-6," + gridSize / 1.5 + ")")
        .attr("class", function (d, i) { return ("dayLabel mono axis axis-workweek"); });

    var timeLabels = svg.selectAll(".timeLabel")
        .data(times)
        .enter().append("text")
        .text(function(d) { return d; })
        .attr("x", function(d, i) { return i * gridSize; })
        .attr("y", 0)
        .style("text-anchor", "middle")
        .attr("transform", "translate(" + gridSize / 2 + ", -6)")
        .attr("class", function(d, i) { return ("timeLabel mono axis axis-worktime"); });
        
    var heatmapChart = function(tsvFile) {
        d3.tsv(tsvFile,
        function(d) {
            return {
            day: +d.day,
            hour: +d.hour,
            value: +d.value
            };
        },
          
        function(error, data) {
            var colorScale = d3.scale.quantile()
                .domain([500, buckets - 2, d3.max(data, function (d) { return d.value; })])
                .range(colors);

            var cards = svg.selectAll(".hour")
                .data(data, function(d) {return d.day+':'+d.hour;});    

            cards.enter().append("rect")
                .attr("x", function(d) { return (d.hour - 0) * (gridSize/2); })
                .attr("y", function(d) { return (d.day - 1) * gridSize; })
                .attr("rx", 4)
                .attr("ry", 4)
                .attr("class", "hour bordered")
                .attr("width", gridSize)
                .attr("height", gridSize)
                .style("fill", colors[0])
                .append("svg:title")
                .text(function(d) { return (d.value+" units") });

            cards.transition().duration(1000)
                .style("fill", function(d) { return colorScale(d.value); });
            
            cards.exit().remove();

            var legend = svg.selectAll(".legend")
            .data([0].concat(colorScale.quantiles()), function(d) { return d; });

            legend.enter().append("g")
                .attr("class", "legend");

            legend.append("rect")
            .attr("x", function(d, i) { return (legendElementWidth * i); })
            .attr("y", height)
            .attr("width", legendElementWidth)
            .attr("height", gridSize / 2)
            .style("fill", function(d, i) { return colors[i]; });

            legend.append("text")
            .attr("class", "mono")
            .text(function(d) { return "≥" + Math.round(d); })
            .attr("x", function(d, i) { return (legendElementWidth * i); })
            .attr("y", height + gridSize);

            legend.exit().remove();

        });  
    };
    heatmapChart(datasets);

    //sales trend chart
    var uniqueStackLabels = "Total Sales";
    var labels = ["Jan", "Feb", "Mar", "Apr", "May", "June", "July", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var totalSalesData = [ 540, 270, 660, 128, 523, 890, 324, 432, 156, 888, 765, 222 ];

    drawBarChartHere('line', 'seasonSalesTrend', uniqueStackLabels,  labels,  totalSalesData, ["Time Period", "Sales"]);

    // top bestsellers table data
    var dataBySales = [
        {
            "Sales": "28192",
            "Quantity Sold": "4",
            "Product": "Thermal Printer"
          },
          {
            "Sales": "27424",
            "Quantity Sold": "9",
            "Product": "T1-PRO Tripod"
          },
          {
            "Sales": "13794",
            "Quantity Sold": "6",
            "Product": "EC-58 58mm (2 Inches) Printer"
          },
          {
            "Sales": "10488",
            "Quantity Sold": "51",
            "Product": "White Pingo Earphone"
          },
          {
            "Sales": "9314",
            "Quantity Sold": "31",
            "Product": "Mi Band 2 Strap"
          }
    ]
    var dataByQty = [
        {
            "Sales": "1458",
            "Quantity Sold": "120",
            "Product": "Roller Skates"
          },
          {
            "Sales": "9314",
            "Quantity Sold": "31",
            "Product": "Fidget Spinner"
          },
          {
            "Sales": "5214",
            "Quantity Sold": "141",
            "Product": "Screen Guard"
          },
          {
            "Sales": "1452",
            "Quantity Sold": "15",
            "Product": "Universal Grip Mount"
          },
          {
            "Sales": "6524",
            "Quantity Sold": "51",
            "Product": "Biking Gloves"
          }
    ]
    columns = [
        {data : "Product"},
        {data : "Quantity Sold"},
        {data : "Sales"}
    ];

    createDataTable('bestSellerSales',dataBySales,columns);			
    createDataTable('bestSellerQty',dataByQty,columns);

     //toggling between quantity and sales
     $("#byQtyBestSeller").click(function(){
        var buttonClass = $("#byQtyBestSeller").hasClass('btn btn-light');
        if(buttonClass) {
            $("#byQtyBestSeller").removeClass('btn btn-light');
            $("#byQtyBestSeller").addClass('btn btn-toggle');
            $("#bySalesBestSeller").removeClass('btn btn-toggle');
            $("#bySalesBestSeller").addClass('btn btn-light');
            $('.bestSellerBySalesData').hide();
            $('.bestSellersQtyData').show();
        } 
    });

    $("#bySalesBestSeller").click( function() {
        var buttonClass = $("#bySalesBestSeller").hasClass('btn btn-light');
        if(buttonClass) {
            $("#bySalesBestSeller").removeClass('btn btn-light');
            $("#bySalesBestSeller").addClass('btn btn-toggle');
            $("#byQtyBestSeller").removeClass('btn btn-toggle');
            $("#byQtyBestSeller").addClass('btn btn-light');
            $('.bestSellersQtyData').hide();
            $('.bestSellerBySalesData').show();
        } 
    });

    //repeat order table data
    var repeatTableData = [
        {
            "Product": "DSLR",
            "No of Repeat Orders": "4",
            "Customers": "2"
          },
          {
            "Product": "Seat Cover",
            "No of Repeat Orders": "6",
            "Customers": "3"
          },
          {
            "Product": "Pendrive",
            "No of Repeat Orders": "5",
            "Customers": "3"
          },
          {
            "Product": "Screen Protector",
            "No of Repeat Orders": "2",
            "Customers": "2"
          },
          {
            "Product": "Seinheiser Earphones",
            "No of Repeat Orders": "4",
            "Customers": "2"
          }
    ]
    columns = [
        {data : "Product"},
        {data : "No of Repeat Orders"},
        {data : "Customers"}
    ];
    createDataTable('repeatSegmentTable',repeatTableData,columns);
    
    //customer details table
    var customerDetailsData = [
            {
                "Name"          : "Bruce Wayne",
                "City"          : "New York",
                "Total Orders"  :   "6",
                "Total Value"   :   "$320"    
            },
            {
                "Name"          : "Clark Kent",
                "City"          : "New York",
                "Total Orders"  :   "7",
                "Total Value"   :   "$500"    
            },
            {
                "Name"          : "John Lane",
                "City"          : "Washington",
                "Total Orders"  :   "5",
                "Total Value"   :   "$222"    
            },
            {
                "Name"          : "Carol Danvers",
                "City"          : "Mountain View",
                "Total Orders"  :   "8",
                "Total Value"   :   "$600"    
            },
            {
                "Name"          : "Hope Van",
                "City"          : "Las Vegas",
                "Total Orders"  :   "3",
                "Total Value"   :   "$112"    
            }
    ]
    columns = [
        {data : "Name"},
        {data : "City"},
        {data : "Total Orders"},
        {data : "Total Value"}
    ];
    createDataTable('customerDetailsTable',customerDetailsData,columns);

    //payments detail table
    var paymentDetailsData = [
        {
            "Gateway"       :   "Paypal",
            "Payments"      :   "$400",
            "Declines"      :   "20",
            "Fees"          :   "$110",
            "Refunds"       :   "$100",
            "Chargebacks"   :   "$20",
            "Effective Rate":   "11.2%"
        },
        {
            "Gateway"       :   "Stripe",
            "Payments"      :   "$300",
            "Declines"      :   "23",
            "Fees"          :   "$120",
            "Refunds"       :   "$130",
            "Chargebacks"   :   "$20",
            "Effective Rate":   "8.2%"
        },
        {
            "Gateway"       :   "Authorize.net",
            "Payments"      :   "$500",
            "Declines"      :   "15",
            "Fees"          :   "$150",
            "Refunds"       :   "$141",
            "Chargebacks"   :   "$30",
            "Effective Rate":   "10.2%"
        }
    ]
    columns = [
        {data : 'Gateway'},
        {data : 'Payments'},
        {data : 'Declines'},
        {data : 'Fees'},
        {data : 'Refunds'},
        {data : 'Chargebacks'},
        {data : 'Effective Rate'}
    ];
    createDataTable('paymentsDetailsTable',paymentDetailsData,columns);

    $('td').filter(function() {
        return this.innerHTML.match(/^[0-9\%\$\s\.,]+$/);
      }).css('text-align','right');
});