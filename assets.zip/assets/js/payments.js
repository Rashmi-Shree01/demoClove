$('[data-toggle="popover"]').popover();

var charts = [];

//doughnut chart
function doughnutCharts(idToUse, labels, data) {
    $.each(charts, function(index, bar) {
		if (bar['id'] == idToUse) {
			bar['object'].destroy();
		}
    })
    var parent = $("#" + idToUse).parent();
	$(parent).html("");
    $(parent).append("<canvas id='" + idToUse + "' />");
    var ctx = $("#"+idToUse);
    var chart = new Chart(ctx, {
        type: 'doughnut',
        responsive: true,
        maintainAspectRatio: false,
        data: {
            labels: labels,
            datasets: [{
                label: "Dataset",
                data: data,
                backgroundColor:[
                                    "rgb(144,135,192)",
                                    "rgb(150,209,243)",
                                    "rgb(244,137,167)",
                                    "rgb(197,229,214)",
                                    "rgb(231,180,211)"
                    
                ],
                borderColor:[
                                    "rgb(144,135,192)",
                                    "rgb(150,209,243)",
                                    "rgb(244,137,167)",
                                    "rgb(197,229,214)",
                                    "rgb(231,180,211)"
                ],
                borderWidth:2
            }]
        },
        options: {
            animateRotate: true,
            cutoutPercentage: 60,
            legend: {
                display: true,
                position: 'bottom',
                labels: {
                    boxWidth: 10
                }
            }
        }
    });
    var index = -1;
	$.each(charts, function(i, bar) {
		if (bar['id'] == idToUse) {
			index = i;
		}
	})
	if (index != -1) {
		charts.splice(index, 1);
	}
	var bar = {
		id : idToUse,
		object : chart
	}
	charts.push(bar);
}

//decline trend - bar chart
function chartForDeclines(idToUse, labels, dataSetOne, dataSetTwo) {
    $.each(charts, function(index, bar) {
		if (bar['id'] == idToUse) {
			bar['object'].destroy();
		}
    })
    var parent = $("#" + idToUse).parent();
	$(parent).html("");
    $(parent).append("<canvas id='" + idToUse + "' />");
    var ctx = $("#"+idToUse);
    var chart = new Chart( ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [ dataSetOne, dataSetTwo ]
        },
        options: {
            legend: {
                display: true,
                position: 'top',
                labels: {
                    boxWidth: 10
                }
            },
            scales : {
                xAxes : [ {
                    scaleLabel : {
                        display : true,
                        labelString: 'Payment Gateway'
                    },
                    ticks : {
                        stepSize : 1,
                        min : 0,
                        autoSkip : false
                    }
                } ],
                yAxes : [ {
                    scaleLabel : {
                        display : true,
                        labelString : 'Amount'
                    },
                    ticks : {
                        beginAtZero: true
                    }
                } ]
            },
            responsive : true,
            stacked : true,
            title : {
                display : false
            }
        }
    });
    var index = -1;
	$.each(charts, function(i, bar) {
		if (bar['id'] == idToUse) {
			index = i;
		}
	})
	if (index != -1) {
		charts.splice(index, 1);
	}
	var bar = {
		id : idToUse,
		object : chart
	}
	charts.push(bar);
}

//decline trend - trend chart
function declineTrends(idToUse,labels,dataSet) {
    $.each(charts, function(index, bar) {
        if (bar['id'] == idToUse) {
            bar['object'].destroy();
        }
    })
    var parent = $("#" + idToUse).parent();
    $(parent).html("");
    $(parent).append("<canvas id='" + idToUse + "' />");
    var ctx = $("#"+idToUse);
    var chart = new Chart(ctx, {
        type : 'line',
        data : {
            labels : labels,
            datasets : dataSet
        },
        options : {
            legend: {
                display: true,
                position: 'top',
                labels: {
                    boxWidth: 10
                }
            },
            scales : {
                xAxes : [ {
                    scaleLabel : {
                        display : true,
                        labelString: 'Time'
                    },
                    ticks : {
                        stepSize : 1,
                        min : 0,
                        autoSkip : false
                    }
                } ],
                yAxes : [ {
                    scaleLabel : {
                        display : true,
                        labelString : 'Decline Rate'
                    }
                } ]
            }
        }
    });
    var index = -1;
    $.each(charts, function(i, bar) {
        if (bar['id'] == idToUse) {
            index = i;
        }
    })
    if (index != -1) {
        charts.splice(index, 1);
    }
    var bar = {
        id : idToUse,
        object : chart
    }
    charts.push(bar);
}

//revenue datatable
function tableForRevenue(revenueData) {
    $("#revenueDetailsTable").DataTable({
        order : [],
        data : revenueData,
        paging : true,
        bFilter: false,
        destroy: true,
        "scrollX": true,
        sDom: "<'row'<'col-sm-12'tr>>" +
                 "<'row'<'col-sm-4'i><'col-sm-8'p>>" ,
        language : {
            emptyTable : "Data not available"
        },
        columns : [ 
                    { data : 'Payment Channel'},
                    { data : 'Total Transactions' },   
                    { data : 'Success Rate' },
                    { data : 'Total Revenue' },
                    { data : 'Declines' },
                    { data : 'Refunds'},
                    { data : 'Chargebacks' },
                    { data : 'Fees' },
                    { data : 'Effective Rate' }
        ]
    });
    $('.dataTable').wrap('<div class="dataTables_scroll" />');
}

//table alignment
$('td').filter(function() {
    return this.innerHTML.match(/^[0-9\%\$\s\-\.,]+$/);
}).css('text-align','right');