$('[data-toggle="popover"]').popover();

$(document).ready(function () {

    //stacked bar chart -- conversion funnel
    function stackedFunnelChart() {
        var ctx = $("#conversionChart");
        var chart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['View Products', 'Add to Cart', 'Remove from Cart', 'Checkout'],
                datasets: [
                    {
                        label: 'Registered Users',
                        data: [300, 150, 50, 60],
                        backgroundColor: 'rgb(150,209,243)'
                    },
                    {
                        label: 'Anonymous Users',
                        data: [500, 300, 100, 0],
                        backgroundColor: 'rgb(144,135,192)'
                    },
                    {
                        label: 'Guest Users',
                        data: [0, 0, 0, 40],
                        backgroundColor: 'rgb(244,137,167)'
                    }
                ]
            },
            options: {
                scales: {
                    xAxes: [{
                        scaleLabel: {
                            display: true,
                            labelString: 'Stages',
                        },
                        stacked: true
                    }],
                    yAxes: [{
                        scaleLabel: {
                            display: true,
                            labelString: 'Visitors',
                        },
                        stacked: true
                    }]
                },
                legend: {
                    display: true,
                    position: 'top',
                    labels: {
                        boxWidth: 10
                    }
                },
                responsive: true,
                title: {
                    display: false
                }
            }
        });
    }
    stackedFunnelChart();

    //location chart
    function doughnutChart(idToUse, labels, dataset) {
        var parent = $("#" + idToUse).parent();
        $(parent).html("");
        $(parent).append("<canvas id='" + idToUse + "' />")
        var ctx = $("#" + idToUse);
        var chart = new Chart(ctx, {
            type: 'doughnut',
            responsive: 'true',
            maintainAspectRatio: false,
            data: {
                labels: labels,
                datasets: [{
                    label: "Dataset",
                    data: dataset,
                    //fill: false,
                    backgroundColor: [
                        "rgb(144,135,192)",
                        "rgb(150,209,243)",
                        "rgb(244,137,167)",
                        "rgb(197,229,214)",
                        "rgb(231,180,211)"
                    ],
                    borderWidth: 2
                }]
            },
            options: {
                animateRotate: true,
                cutoutPercentage: 60,
                legend: {
                    display: true,
                    position: 'bottom',
                    labels: {
                        boxWidth: 10
                    }
                }
            }
        });
    }
    var doughnutLabel = ['Bangalore', 'Delhi', 'Amritsar', 'Chennai', 'Chandigarh']
    var doughnutData = [342, 242, 120, 109, 100];

    doughnutChart('locationChart', doughnutLabel, doughnutData);

    function pageTables(idToUse, data, columns) {
        $("#" + idToUse).DataTable({
            order: [],
            data: data,
            paging: true,
            bFilter: false,
            bInfo: false,
            sDom: "<'row'<'col-sm-12'tr>>" +
                "<'row'<'col-sm-4'i><'col-sm-8'p>>",
            language: {
                emptyTable: "Data not available"
            },
            columns: columns
        });
        $('.dataTable').wrap('<div class="dataTables_scroll" />');
    }

    //drop off table
    var dropOffData = [
        {
            "User Email": "divehew@gmail.com ",
            "Visit Count": "1",
            "Page Visited": "5",
            "Date": "9/30/2018",
            "Referrer Page": "https://www.imgprod.com/slimming-shapewear.html",
            "Landing Page": "https://www.imgprod.com",
            "Device/OS": "Mac OS X (iPad)",
            "User Type": "Registered"
        },
        {
            "User Email": "-",
            "Visit Count": "1",
            "Page Visited": "29",
            "Date": "10/6/2018",
            "Referrer Page": "https://www.google.co.in",
            "Landing Page": "https://www.imgprod.com",
            "Device/OS": "Windows 7",
            "User Type": "Anonymous"
        },
        {
            "User Email": "sam_1012@gmail.com ",
            "Visit Count": "1",
            "Page Visited": "21",
            "Date": "10/6/2018",
            "Referrer Page": "-",
            "Landing Page": "imgprod",
            "Device/OS": "Windows 7",
            "User Type": "Guest"
        },
        {
            "User Email": "bruce.banner@yahoo.com ",
            "Visit Count": "1",
            "Page Visited": "27",
            "Date": "10/6/2018",
            "Referrer Page": "-",
            "Landing Page": "https://www.imgprod.com",
            "Device/OS": "Windows 8.1",
            "User Type": "Registered"
        },
        {
            "User Email": "amanda12@outlook.com ",
            "Visit Count": "1",
            "Page Visited": "17",
            "Date": "10/5/2018",
            "Referrer Page": "https://www.google.com",
            "Landing Page": "https://www.imgprod.com",
            "Device/OS": "Android Mobile",
            "User Type": "Registered"
        },
        {
            "User Email": "-",
            "Visit Count": "1",
            "Page Visited": "10",
            "Date": "10/5/2018",
            "Referrer Page": "https://www.imgprod.com/books/fiction/all.html",
            "Landing Page": "https://www.imgprod.com",
            "Device/OS": "Mac OS X",
            "User Type": "Anonymous"
        }
    ]
    var dropOffColumn = [
        { data: "User Email" },
        { data: "Visit Count" },
        { data: "Page Visited" },
        { data: "Date" },
        { data: "Referrer Page" },
        { data: "Landing Page" },
        { data: "Device/OS" },
        { data: "User Type" }
    ]
    pageTables('dropOffTable', dropOffData, dropOffColumn);

    var dropOffData2 = [
        {
            "Marketing Medium": "instgramAds",
            "Marketing Source": "Direct",
            "Marketing Campaign": "just_accesories",
            "Landing Page": "https://travel/access/hats.html",
            "Page Before Exit": "https://looks/watches/titan.html",
            "Exit Page": "https://travel/access/hats.html",
            "Count of Visitors": "15",
            "Conversions": "3"
        },
        {
            "Marketing Medium": "fb_ads",
            "Marketing Source": "Social",
            "Marketing Campaign": "all_books",
            "Landing Page": "https://books/fiction.html",
            "Page Before Exit": "https://books/fiction/hp.html",
            "Exit Page": "https://books/fiction/all.html",
            "Count of Visitors": "10",
            "Conversions": "5"
        },
        {
            "Marketing Medium": "ad_ads",
            "Marketing Source": "Direct",
            "Marketing Campaign": "play+all+sports",
            "Landing Page": "https://sports/cricket.html",
            "Page Before Exit": "https://ports/cricket/kit.html",
            "Exit Page": "https://sports/basketball/jersey.html",
            "Count of Visitors": "5",
            "Conversions": "2"
        },
        {
            "Marketing Medium": "google_ads",
            "Marketing Source": "Direct",
            "Marketing Campaign": "fashion+new+arrivals",
            "Landing Page": "https://bestbuys/fashion/new.html",
            "Page Before Exit": "https://bestbuys/apparels.html",
            "Exit Page": "https://bestbuys/ethnic/fashion/new.html",
            "Count of Visitors": "3",
            "Conversions": "1"
        }
    ]
    var dropOffColumn2 = [
        { data: 'Marketing Medium' },
        { data: 'Marketing Source' },
        { data: 'Marketing Campaign' },
        {
            data: 'Landing Page',
            render: function (data, type, row) {
                var oldData = data;
                var newData = data.length > 15 ? data.substr(0, 20) + '…' : data;
                return "<span title='" + oldData + "'>" + newData + "</span>";
            }
        },
        {
            data: 'Page Before Exit',
            render: function (data, type, row) {
                var oldData = data;
                var newData = data.length > 15 ? data.substr(0, 20) + '…' : data;
                return "<span title='" + oldData + "'>" + newData + "</span>";
            }
        },
        {
            data: 'Exit Page',
            render: function (data, type, row) {
                var oldData = data;
                var newData = data.length > 15 ? data.substr(0, 20) + '…' : data;
                return "<span title='" + oldData + "'>" + newData + "</span>";
            }
        },
        { data: 'Count of Visitors' },
        { data: 'Conversions' }
    ]
    pageTables('dropOffTable2', dropOffData2, dropOffColumn2);

    //checkouts table
    var checkoutsData = [
        {
            "User Email": "smith@email.com ",
            "No of Visits": "2",
            "Pages Visited": "5",
            "Purchase Date": "22/10/2018",
            "First Referrer Page": "FB.com/mkt1",
            "Current Referrer Page": "FB cover page",
            "Device": "Desktop"
        },
        {
            "User Email": "elly@joyful.com ",
            "No of Visits": "1",
            "Pages Visited": "7",
            "Purchase Date": "21/10/2018",
            "First Referrer Page": "instagram.com/src2",
            "Current Referrer Page": "instagram.com",
            "Device": "Mobile"
        },
        {
            "User Email": "jane@path.com ",
            "No of Visits": "4",
            "Pages Visited": "10",
            "Purchase Date": "18/10/2018",
            "First Referrer Page": "-",
            "Current Referrer Page": "google.com",
            "Device": "Mobile"
        }
    ]
    var checkoutColumns = [
        { data: 'User Email' },
        { data: 'No of Visits' },
        { data: 'Pages Visited' },
        { data: 'Purchase Date' },
        { data: 'First Referrer Page' },
        { data: 'Current Referrer Page' },
        { data: 'Device' }
    ]

    pageTables('checkoutsTable', checkoutsData, checkoutColumns);

    //page urls table
    var pageUrlData = [
        {
            "Page URL": "https://bestbuys/accessories.html",
            "Count": "10"
        },
        {
            "Page URL": "https://bestbuys/sports/cricket.html",
            "Count": "7"
        },
        {
            "Page URL": "https://bestbuys/travel/accessories.html",
            "Count": "13"
        },
        {
            "Page URL": "https://bestbuys/books/fiction/jkrowling.html",
            "Count": "15"
        },
        {
            "Page URL": "https://bestbuys/fashion/new.html",
            "Count": "8"
        }
    ]
    var pageUrlColumns = [
        { data: 'Page URL' },
        { data: 'Count' }
    ]

    pageTables('pageUrls', pageUrlData, pageUrlColumns);

     //referral urls table
     var referralUrlData = [
        {
            "Referral Page URL": "https://facebook.com/new_accessories",
            "Count": "5"
        },
        {
            "Referral Page URL": "https://google.com",
            "Count": "10"
        },
        {
            "Referral Page URL": "https://facebook.com/sports_cricket_bats",
            "Count": "6"
        },
        {
            "Referral Page URL": "https://google.com/fiction_books",
            "Count": "15"
        },
        {
            "Referral Page URL": "https://google.com/fashion_new",
            "Count": "8"
        }
    ]
    var referralPageUrlColumns = [
        { data: 'Referral Page URL' },
        { data: 'Count' }
    ]

    pageTables('referralPages', referralUrlData, referralPageUrlColumns);

    tableAlignment();
});