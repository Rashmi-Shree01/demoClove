$('[data-toggle="popover"]').popover();

//function to get the day and time stacked chart and sales trend chart
function dataComparisonChart(tsvFileUsed){
    //heatmap
    var margin = { top: 50, right: 0, bottom: 100, left: 30 },
    width = 650 - margin.left - margin.right,
    height = 350 - margin.top - margin.bottom,
    gridSize = Math.floor(width / 24),
    legendElementWidth = gridSize*2,
    buckets = 9,
    colors = ["#41b6c4","#1d91c0","#225ea8","#253494","#081d58"], 
    days = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
    times = ["12a", "2a", "4a", "6a", "8a", "10a", "12p", "2p", "4p", "6p", "8p", "10p"];
    datasets = [tsvFileUsed];

    var svg = d3.select("#daySalesChart").append("svg")
        .attr("width", 350)
        .attr("height", 300)
        .append("g")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

    var dayLabels = svg.selectAll(".dayLabel")
        .data(days)
        .enter().append("text")
        .text(function (d) { return d; })
        .attr("x", 0)
        .attr("y", function (d, i) { return i * gridSize; })
        .style("text-anchor", "end")
        .attr("transform", "translate(-6," + gridSize / 1.5 + ")")
        .attr("class", function (d, i) { return ("dayLabel mono axis axis-workweek"); });

    var timeLabels = svg.selectAll(".timeLabel")
        .data(times)
        .enter().append("text")
        .text(function(d) { return d; })
        .attr("x", function(d, i) { return i * gridSize; })
        .attr("y", 0)
        .style("text-anchor", "middle")
        .attr("transform", "translate(" + gridSize / 2 + ", -6)")
        .attr("class", function(d, i) { return ("timeLabel mono axis axis-worktime"); });

    var heatmapChart = function(tsvFile) {
    d3.tsv(tsvFile,
    function(d) {
        return {
        day: +d.day,
        hour: +d.hour,
        value: +d.value
        };
    },

    function(error, data) {
        var colorScale = d3.scale.quantile()
            .domain([500, buckets - 2, d3.max(data, function (d) { return d.value; })])
            .range(colors);

        var cards = svg.selectAll(".hour")
            .data(data, function(d) {return d.day+':'+d.hour;});    

        cards.enter().append("rect")
            .attr("x", function(d) { return (d.hour - 0) * (gridSize/2); })
            .attr("y", function(d) { return (d.day - 1) * gridSize; })
            .attr("rx", 4)
            .attr("ry", 4)
            .attr("class", "hour bordered")
            .attr("width", gridSize)
            .attr("height", gridSize)
            .style("fill", colors[0])
            .append("svg:title")
            .text(function(d) { return (d.value+" units") });

        cards.transition().duration(1000)
            .style("fill", function(d) { return colorScale(d.value); });
        
        cards.exit().remove();

        var legend = svg.selectAll(".legend")
        .data([0].concat(colorScale.quantiles()), function(d) { return d; });

        legend.enter().append("g")
            .attr("class", "legend");

        legend.append("rect")
        .attr("x", function(d, i) { return (legendElementWidth * i); })
        .attr("y", height)
        .attr("width", legendElementWidth)
        .attr("height", gridSize / 2)
        .style("fill", function(d, i) { return colors[i]; });

        legend.append("text")
        .attr("class", "mono")
        .text(function(d) { return "≥" + Math.round(d); })
        .attr("x", function(d, i) { return (legendElementWidth * i); })
        .attr("y", height + gridSize);

        legend.exit().remove();

    });  
    };
    heatmapChart(datasets);
};

//best seller product table
function bestSellerProducts(bestSellers) {
    var productData = bestSellers['product'];
    var tableDataSales = [];
    var tableDataQty = [];
    var columns = [];
    
    var bySales = productData['sales'];
    var byQty = productData['quantitySold'];

    for(var i=0; i<bySales.length; i++) {
        var dataBySales = {
                "Product" : bySales[i]['product'],
                "Quantity Sold" : bySales[i]['quantity'],
                "Sales" : '$' + bySales[i]['sale'],
                "Change %" : bySales[i]['percentage'] != undefined ? (bySales[i]['percentage']*100).toFixed(2) : "-"
        };
        tableDataSales.push(dataBySales);
    }

    for(var i=0; i<byQty.length; i++) {
        var dataByQty = {
                "Product" : byQty[i]['product'],
                "Quantity Sold" : byQty[i]['quantity'],
                "Sales" : '$' + byQty[i]['sale'],
                "Change %" : byQty[i]['percentage'] != undefined ? (byQty[i]['percentage']*100).toFixed(2) : "-"
        };
        tableDataQty.push(dataByQty);
    }
    
    columns = [
        {data : "Product"},
        {data : "Quantity Sold"},
        {data : "Sales"},
        {data : "Change %",
            render: function(data,type,row){
                if(data > 0){
                    return "<p class='positive'>"+data+"</p>";
                }else{
                    return "<p class='negative'>"+data+"</p>";
                }
        }}
        
    ];
    
    createDataTable('bestSellerSalesProd',tableDataSales,columns,undefined,false);			
    createDataTable('bestSellerQtyProd',tableDataQty,columns,undefined,false);
};

//best seller category table
function bestSellerCategory(bestSellers) {
    var categoryData = bestSellers['category'];
    var tableDataSales = [];
    var tableDataQty = [];
    var columns = [];
    
    var bySales = categoryData['sales'];
    var byQty = categoryData['quantitySold'];

    for(var i=0; i<bySales.length; i++) {
        var dataBySales = {
                "Category" : bySales[i]['category'],
                "Quantity Sold" : bySales[i]['quantity'],
                "Sales" : '$' + bySales[i]['sale'],
                "Change %" : bySales[i]['percentage'] != undefined ? (bySales[i]['percentage']*100).toFixed(2) : "-"
        };
        tableDataSales.push(dataBySales);
    }

    for(var i=0; i<byQty.length; i++) {
        var dataByQty = {
                "Category" : byQty[i]['category'],
                "Quantity Sold" : byQty[i]['quantity'],
                "Sales" : '$' + byQty[i]['sale'],
                "Change %" : byQty[i]['percentage'] != undefined ? (byQty[i]['percentage']*100).toFixed(2) : "-"
        };
        tableDataQty.push(dataByQty);
    }
    
    columns = [
        {data : "Category"},
        {data : "Quantity Sold"},
        {data : "Sales"},
        {data : "Change %", 
            render: function(data,type,row){
                        if(data > 0){
                            return "<p class='positive'>"+data+"</p>";
                        }else{
                            return "<p class='negative'>"+data+"</p>";
                        }
            }
        }
    ];
    
    createDataTable('bestSellerSalesCat',tableDataSales,columns,undefined,false);		
    createDataTable('bestSellerQtyCat',tableDataQty,columns,undefined,false);
};

//repeat order table
function productRepeatOrders(repeatOrderDetails){
    var tableDataProd = [];
    var tableDataCat = [];
    var columnsProd = [];
    var columnsCat = [];
    
    var byProducts = repeatOrderDetails['product'];
    var byCategory = repeatOrderDetails['category'];

    for(var i=0; i<byProducts.length; i++) {
        var dataBySales = {
                "Product" : byProducts[i]['product'],
                "No of Repeat Orders" : byProducts[i]['repeatOrders'],
                "Customers" : byProducts[i]['customers']
        };
        tableDataProd.push(dataBySales);
    }

    for(var i=0; i<byCategory.length; i++) {
        var dataByQty = {
                "Category" : byCategory[i]['category'],
                "No of Repeat Orders" : byCategory[i]['repeatOrders'],
                "Customers" : byCategory[i]['customers']
        };
        tableDataCat.push(dataByQty);
    }
    
    columnsProd = [
        {data : 'Product'},
        {data : 'No of Repeat Orders'},
        {data : 'Customers'}
    ];
    
    columnsCat = [
        {data : 'Category'},
        {data : 'No of Repeat Orders'},
        {data : 'Customers'}
    ];
    
    createDataTable('productRepeatsTable',tableDataProd,columnsProd,undefined,false);
    createDataTable('categoryRepeatsTable',tableDataCat,columnsCat,undefined,false);
};

//return product table
function returnsProducts(returnData) {
    var productData = returnData['product'];
    var tableDataSales = [];
    var tableDataQty = [];
    var columns = [];
    
    var bySales = productData['sales'];
    var byQty = productData['quantitySold'];

    for(var i=0; i<bySales.length; i++) {
        var dataBySales = {
                "Product" : bySales[i]['product'],
                "Quantity Returned" : bySales[i]['quantityReturned'],
                "Sales" : '$' + bySales[i]['sale'],
        };
        tableDataSales.push(dataBySales);
    }

    for(var i=0; i<byQty.length; i++) {
        var dataByQty = {
                "Product" : byQty[i]['product'],
                "Quantity Returned" : byQty[i]['quantityReturned'],
                "Sales" : '$' + byQty[i]['sale'],
        };
        tableDataQty.push(dataByQty);
    }
    
    columns = [
        {data : "Product"},
        {data : "Quantity Returned"},
        {data : "Sales"}
    ];
    
    createDataTable('returnSalesProd',tableDataSales,columns,undefined,false);			
    createDataTable('returnQtyProd',tableDataQty,columns,undefined,false);
};

//return category table
function returnsCategory(returnData) {
    var productData = returnData['category'];
    var tableDataSales = [];
    var tableDataQty = [];
    var columns = [];
    
    var bySales = productData['sales'];
    var byQty = productData['quantitySold'];

    for(var i=0; i<bySales.length; i++) {
        var dataBySales = {
                "Product" : bySales[i]['category'],
                "Quantity Returned" : bySales[i]['quantityReturned'],
                "Sales" : '$' + bySales[i]['sale'],
        };
        tableDataSales.push(dataBySales);
    }

    for(var i=0; i<byQty.length; i++) {
        var dataByQty = {
                "Product" : byQty[i]['category'],
                "Quantity Returned" : byQty[i]['quantityReturned'],
                "Sales" : '$' + byQty[i]['sale'],
        };
        tableDataQty.push(dataByQty);
    }
    
    columns = [
        {data : "Product"},
        {data : "Quantity Returned"},
        {data : "Sales"}
    ];
    
    createDataTable('returnSalesCat',tableDataSales,columns,undefined,false);			
    createDataTable('returnQtyCat',tableDataQty,columns,undefined,false);
};

var selected = 'Products';
var byQtyBtn = true;

// toggling between quantity and sales
$("#byQtyBestSeller").click(function(){
    var buttonClass = $("#byQtyBestSeller").hasClass('btn btn-light');
    byQtyBtn = true;
    if(buttonClass) {
        $("#byQtyBestSeller").removeClass('btn btn-light');
        $("#byQtyBestSeller").addClass('btn btn-toggle');
        $("#bySalesBestSeller").removeClass('btn btn-toggle');
        $("#bySalesBestSeller").addClass('btn btn-light');
        if(selected == "Products") {
            $('.prodQtyBestSeller').show();
            $('.prodSalesBestSeller').hide();
            $('.categorySalesBestSeller').hide();
            $('.categoryQtyBestSeller').hide();
        } else {
            $('.prodQtyBestSeller').hide();
            $('.prodSalesBestSeller').hide();
            $('.categorySalesBestSeller').hide();
            $('.categoryQtyBestSeller').show();
        }
    } 
});

$("#bySalesBestSeller").click( function() {
    var buttonClass = $("#bySalesBestSeller").hasClass('btn btn-light');
    byQtyBtn = false;
    if(buttonClass) {
        $("#bySalesBestSeller").removeClass('btn btn-light');
        $("#bySalesBestSeller").addClass('btn btn-toggle');
        $("#byQtyBestSeller").removeClass('btn btn-toggle');
        $("#byQtyBestSeller").addClass('btn btn-light');
        if(selected == "Products") {
            $('.prodQtyBestSeller').hide();
            $('.prodSalesBestSeller').show();
            $('.categorySalesBestSeller').hide();
            $('.categoryQtyBestSeller').hide();
        } else {
            $('.prodQtyBestSeller').hide();
            $('.prodSalesBestSeller').hide();
            $('.categorySalesBestSeller').show();
            $('.categoryQtyBestSeller').hide();
        }
    } 
});

//toggling between category and product bestseller
$(".salesSelector").change(function () {
    selected = $(this).val();
    switch(selected) {
        case 'Products' :
            if(byQtyBtn) {
                $('.prodQtyBestSeller').show();
                $('.prodSalesBestSeller').hide();
                $('.categorySalesBestSeller').hide();
                $('.categoryQtyBestSeller').hide();
            } else {
                $('.prodQtyBestSeller').hide();
                $('.prodSalesBestSeller').show();
                $('.categorySalesBestSeller').hide();
                $('.categoryQtyBestSeller').hide();
            }
            break;
        case 'Category' :
            if(byQtyBtn) {
                $('.prodQtyBestSeller').hide();
                $('.prodSalesBestSeller').hide();
                $('.categorySalesBestSeller').hide();
                $('.categoryQtyBestSeller').show();
            } else {
                $('.prodQtyBestSeller').hide();
                $('.prodSalesBestSeller').hide();
                $('.categorySalesBestSeller').show();
                $('.categoryQtyBestSeller').hide();
            }
            break;
        default :
            $('.prodQtyBestSeller').show();
            $('.prodSalesBestSeller').hide();
            $('.categorySalesBestSeller').hide();
            $('.categoryQtyBestSeller').hide();
            break;
    }
});

//toggling between category and products - repeat order
$(".repeatOrderSelector").change(function () {
    var selected = $(this).val();
    switch(selected) {
    case 'Products' :
        $('.productRepeats').show();
        $('.categoryRepeats').hide();
        break;
    case 'Category' :
        $('.productRepeats').hide();
        $('.categoryRepeats').show();
        break;
    default :
        $('.productRepeats').show();
        $('.categoryRepeats').hide();
        break;
    }
});

// toggling between sales and quantity for returns
var selectedReturn = 'Products';
var byQtyReturn = true;

$("#byQtyReturns").click(function(){
    var buttonClass = $("#byQtyReturns").hasClass('btn btn-light');
    byQtyReturn = true;
    if(buttonClass) {
        $("#byQtyReturns").removeClass('btn btn-light');
        $("#byQtyReturns").addClass('btn btn-toggle');
        $("#bySalesReturns").removeClass('btn btn-toggle');
        $("#bySalesReturns").addClass('btn btn-light');
        if(selected == "Products") {
            $('.prodQtyReturns').show();
            $('.prodSalesReturns').hide();
            $('.categorySalesReturns').hide();
            $('.categoryQtyReturns').hide();
        } else {
            $('.prodQtyReturns').hide();
            $('.prodSalesReturns').hide();
            $('.categorySalesReturns').hide();
            $('.categoryQtyReturns').show();
        }
    } 
});

$("#bySalesReturns").click( function() {
    var buttonClass = $("#bySalesReturns").hasClass('btn btn-light');
    byQtyBtn = false;
    if(buttonClass) {
        $("#bySalesReturns").removeClass('btn btn-light');
        $("#bySalesReturns").addClass('btn btn-toggle');
        $("#byQtyReturns").removeClass('btn btn-toggle');
        $("#byQtyReturns").addClass('btn btn-light');
        if(selected == "Products") {
            $('.prodQtyReturns').hide();
            $('.prodSalesReturns').show();
            $('.categorySalesReturns').hide();
            $('.categoryQtyReturns').hide();
        } else {
            $('.prodQtyReturns').hide();
            $('.prodSalesReturns').hide();
            $('.categorySalesReturns').show();
            $('.categoryQtyReturns').hide();
        }
    } 
});


//toggling between category and product returns
$(".returnSelector").change(function () {
    selectedReturn = $(this).val();
    switch(selectedReturn) {
        case 'Products' :
            if(byQtyReturn) {
                $('.prodQtyReturns').show();
                $('.prodSalesReturns').hide();
                $('.categorySalesReturns').hide();
                $('.categoryQtyReturns').hide();
            } else {
                $('.prodQtyReturns').hide();
                $('.prodSalesReturns').show();
                $('.categorySalesReturns').hide();
                $('.categoryQtyReturns').hide();
            }
            break;
        case 'Category' :
            if(byQtyReturn) {
                $('.prodQtyReturns').hide();
                $('.prodSalesReturns').hide();
                $('.categorySalesReturns').hide();
                $('.categoryQtyReturns').show();
            } else {
                $('.prodQtyReturns').hide();
                $('.prodSalesReturns').hide();
                $('.categorySalesReturns').show();
                $('.categoryQtyReturns').hide();
            }
            break;
        default :
            $('.prodQtyReturns').show();
            $('.prodSalesReturns').hide();
            $('.categorySalesReturns').hide();
            $('.categoryQtyReturns').hide();
            break;
    }
});

//table alignment
$('td').filter(function() {
    return this.innerHTML.match(/^[0-9\%\$\s\-\.,]+$/);
}).css('text-align','right');