$(document).ready( function () {

    //product table function
    function productTable(idToUse, tableData) {
        $("#"+idToUse).DataTable({
            order : [],
            data : tableData,
            paging : false,
            bFilter: false,
            bInfo: false,
            sDom: "<'row'<'col-sm-12'tr>>" +
                     "<'row'<'col-sm-4'i><'col-sm-8'p>>" ,
            language : {
                emptyTable : "Data not available"
            },
            columns : [ 
                        { data : 'Product'}, 
                        { data : 'Quantity' }, 
                        { data : 'Sales' }
            ]
        });
        $('.dataTable').wrap('<div class="dataTables_scroll" />');
    }

    //best seller data
    var bestSellerId = "bestSellerQty";
    var bestSellerData = [ 
        {
            "Product"   :   "iPhone7 Back Case",
            "Quantity"  :   "120",
            "Sales"     :   "$1234"
        },
        {
            "Product"   :   "Thermal Receipt Printer",
            "Quantity"  :   "210",
            "Sales"     :   "$5263"
        },
        {
            "Product"   :   "Stereo Sound Earpods",
            "Quantity"  :   "85",
            "Sales"     :   "$965"
        },
        {
            "Product"   :   "Bose Speakers",
            "Quantity"  :   "358",
            "Sales"     :   "$9632"
        },
        {
            "Product"   :   "Extendable Tripod",
            "Quantity"  :   "110",
            "Sales"     :   "$2510"
        }
    ]

    productTable(bestSellerId, bestSellerData);

    //returns data
    var returnsId = "returnQty";
    var returnsData = [
                                {
                                    "Product"   :   "HTC Desire 610",
                                    "Quantity"  :   "254",
                                    "Sales"     :   "$1245"
                                },
                                {
                                    "Product"   :   "Protective Case Cover",
                                    "Quantity"  :   "110",
                                    "Sales"     :   "$2514"
                                },
                                {
                                    "Product"   :   "Thermal Printer",
                                    "Quantity"  :   "25",
                                    "Sales"     :   "$3333"
                                },
                                {
                                    "Product"   :   "USB Cable",
                                    "Quantity"  :   "302",
                                    "Sales"     :   "$9584"
                                },
                                {
                                    "Product"   :   "NoteBook",
                                    "Quantity"  :   "101",
                                    "Sales"     :   "$2415"
                                }
    ]

    productTable(returnsId, returnsData);

     //repeat order segment
    function repeatOrderTable() {
        var data = [
                        {
                            "Product"               :   "Seinheiser Earphones",
                            "No of Repeat Orders"  :   "4",
                            "Customers"             :   "2"
                        },
                        {
                            "Product"               :   "Screen Protector",
                            "No of Repeat Orders"  :   "2",
                            "Customers"             :   "2"
                        },
                        {
                            "Product"               :   "Pendrive",
                            "No of Repeat Orders"  :   "5",
                            "Customers"             :   "3"
                        },
                        {
                            "Product"               :   "Seat Cover",
                            "No of Repeat Orders"  :   "6",
                            "Customers"             :   "3"
                        },
                        {
                            "Product"               :   "DSLR",
                            "No of Repeat Orders"  :   "4",
                            "Customers"             :   "2"
                        }
        ]
        $("#repeatSegmentTable").DataTable({
            order : [],
            data : data,
            paging : false,
            bFilter: false,
            bInfo: false,
            sDom: "<'row'<'col-sm-12'tr>>" +
                     "<'row'<'col-sm-4'i><'col-sm-8'p>>" ,
            language : {
                emptyTable : "Data not available"
            },
            columns : [ 
                        { data : 'Product'}, 
                        { data : 'No of Repeat Orders' }, 
                        { data : 'Customers' }
            ]
        });
        $('.dataTable').wrap('<div class="dataTables_scroll" />');
    }
    repeatOrderTable();

    //unsold products
    function unsoldProductsTable() {
        var unsoldData = [
            {
                "Product"               :   "In-Ear Earphones",
                "Quantity"              :   "358",
                "Last Purchased Date"   :   "3/Feb/2018"
            },
            {
                "Product"               :   "Auto Cutter",
                "Quantity"              :   "101",
                "Last Purchased Date"   :   "4/Feb/2018"
            },
            {
                "Product"               :   "Stereo Sound Earpods",
                "Quantity"              :   "85",
                "Last Purchased Date"   :   "5/Feb/2018"
            },
            {
                "Product"               :   "Water Bottles",
                "Quantity"              :   "210",
                "Last Purchased Date"   :   "6/Feb/2018"
            },
            {
                "Product"               :   "Tempered Glass Screen Protector",
                "Quantity"              :   "254",
                "Last Purchased Date"   :   "7/Feb/2018"
            }

        ]
        $("#unsoldProdTable").DataTable({
            order : [],
            data : unsoldData,
            paging : false,
            bFilter: false,
            bInfo: false,
            sDom: "<'row'<'col-sm-12'tr>>" +
                     "<'row'<'col-sm-4'i><'col-sm-8'p>>" ,
            language : {
                emptyTable : "Data not available"
            },
            columns : [ 
                        { data : 'Product'}, 
                        { data : 'Quantity' }, 
                        { data : 'Last Purchased Date' }
            ]
        });
        $('.dataTable').wrap('<div class="dataTables_scroll" />');
    }
    unsoldProductsTable();

    //table alignment
    $('td').filter(function() {
        return this.innerHTML.match(/^[0-9\%\$\s\.,]+$/);
      }).css('text-align','right');

    $('th').css('text-align','center');

});