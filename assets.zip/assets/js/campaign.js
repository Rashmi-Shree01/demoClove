$('[data-toggle="popover"]').popover();

var charts = [];

// abstract function that creates the specified graph 
function createGraph(type,idToUse,data,options){
    if(options != null){
        $.each(charts, function(index, bar) {
            if (bar['id'] == idToUse) {
                bar['object'].destroy();
            }
        })
        var parent = $("#" + idToUse).parent();
        $(parent).html("");
        $(parent).append("<canvas id='" + idToUse + "' />");
        var ctx = $('#'+idToUse)
        var chart = new Chart(ctx,{
            type: type,
            data: data,
            options: options
        });
        var index = -1;
        $.each(charts, function(i, bar) {
            if (bar['id'] == idToUse) {
                index = i;
            }
        })
        if (index != -1) {
            charts.splice(index, 1);
        }
        var bar = {
            id : idToUse,
            object : chart
        }
        charts.push(bar);
    }
    else {
        $.each(charts, function(index, bar) {
            if (bar['id'] == idToUse) {
                bar['object'].destroy();
            }
        })
        var parent = $("#" + idToUse).parent();
        $(parent).html("");
        $(parent).append("<canvas id='" + idToUse + "' />");
        var ctx = $('#'+idToUse)
        var chart = new Chart(ctx,{
            type: type,
            data: data
        });
        var index = -1;
        $.each(charts, function(i, bar) {
            if (bar['id'] == idToUse) {
                index = i;
            }
        })
        if (index != -1) {
            charts.splice(index, 1);
        }
        var bar = {
            id : idToUse,
            object : chart
        }
        charts.push(bar);
    }
}

// function to create data tables
function createDataTable(id,data,columns,paging,binfo){
    var dt = id.DataTable({
        order : [],
        data : data,
        paging : paging,
        bFilter: false,
        info : binfo,
        destroy : true,
        // "scrollX": true,
        sDom: "<'row'<'col-sm-12'tr>>" +
                 "<'row'<'col-sm-4'i><'col-sm-8'p>>" ,
        language : {
            emptyTable : "Data not available"
        },
        columns : columns
    });
    $('.dataTable').wrap('<div class="dataTables_scroll" />');
    return dt;
}

//table alignment
$('td').filter(function() {
    return this.innerHTML.match(/^[0-9\%\$\s\-\.,]+$/);
}).css('text-align','right');

$(document).ready(function(){
    
    "use strict";
    function checkUlList(){
        console.log(screen.width);
        if(screen.width < 1440){
            $('#deleteWhentablet').remove();
            $('#deviceGraphColumn').removeClass('col-lg-5');
            $('#deviceGraphColumn').addClass('col-lg-6');
            $('#deviceGraphColumn').css("padding-right","20px");
            $('#clicksctrcpc').removeClass('col-lg-5');
            $('#clicksctrcpc').addClass('col-lg-6');
            $('#clicksVctr').css("padding","0.75em");
            $('#clicksctrcpc').css("padding-left","20px");
            $('#deleteWhenLarge').css("display","inline-block");
            $('#deleteWhenLarge').css("width","101%");
        }
        else {
            $('#deleteWhenLarge').remove();
            $('#deleteWhentablet').css("display","block");
        }
    }
    
    
    checkUlList();
    // call checkUlList() when screen is resized
    $(window).resize(function(){
        checkUlList();
    });
    
});
