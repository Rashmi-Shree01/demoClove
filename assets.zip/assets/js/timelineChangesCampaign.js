$(document).ready(function () {

    var yesterdayLabels = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24];
    var thisWeekLabels = ['Sunday', 'Monday', 'Tuesday'];
    var lastWeekLabels = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    var thisMonthLabels = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26];
    var lastMonthLabels = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31];
    var lastSixMonthLabels = ["Mar", "Apr", "May", "June", "July", "Aug"];
    var thisYearLabels = ["Jan", "Feb", "Mar", "Apr", "May", "June", "July", "Aug", "Sep"];

    campaignsThisMonthChanges();
    tableAlignment();
    $('.time-range').change(function () {
        var selectedRange = $(this).val();
        // alert(selectedRange);
        switch (selectedRange) {
            case 'Yesterday':
                // campaignsYesterdayChanges();
                break;
            case 'This Week':
                // campaignsThisWeekChanges();
                break;
            case 'Last week':
                // campaignsLastWeekChanges();
                break;
            case 'This Month':
                campaignsThisMonthChanges();
                tableAlignment();
                break;
            case 'Last month':
                // campaignsLastMonthChanges();
                break;
            case 'Last 6 month':
                // campaignsLastSixMonthChanges();
                break;
            case 'Year':
                campaignsYearChanges();
                tableAlignment();
                break;
            default:
                campaignsThisMonthChanges();
                tableAlignment();
                break;
        }
    });

    //campaign yesterday changes
    function campaignsYesterdayChanges() {
        //top row
        //add data in text()
        $('#clicks').text('');
        $('#clicksPercent').text('').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#ctr').text('');
        $('#ctrPercent').text('').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');
        $('#cpc').text('');
        $('#cpcPercent').text('').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#impressions').text('');
        $('#impressionsPercent').text('').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');

        // Devices horizontal graph
        //change dataDesktops, dataMobiles and dataTablets for timeline
        var dataDesktops = [2000, 2345, 1345];
        var dataTablets = [1234, 1000, 786];
        var dataMobiles = [978, 345, 234];
        createGraph('horizontalBar', 'deviceGraph', {
            labels: ["Clicks", "CTR", "CPC"],
            datasets: [{
                data: dataDesktops,
                backgroundColor: "rgb(144,135,192)"
            },
            {
                data: dataTablets,
                backgroundColor: "rgb(150,209,243)"
            },
            {
                data: dataMobiles,
                backgroundColor: "rgb(244,137,167)"
            }
            ]
        }, {
                tooltips: {
                    enabled: true
                },
                scales: {
                    xAxes: [{
                        ticks: {
                            beginAtZero: true,
                            fontFamily: "'Open Sans Bold', sans-serif",
                            fontSize: 11
                        },
                        scaleLabel: {
                            display: false
                        },
                        gridLines: {
                        },
                        stacked: true
                    }],
                    yAxes: [{
                        gridLines: {
                            display: false,
                            color: "#fff",
                            zeroLineColor: "#fff",
                            zeroLineWidth: 0
                        },
                        ticks: {
                            fontFamily: "'Open Sans Bold', sans-serif",
                            fontSize: 11
                        },
                        stacked: true
                    }]
                },
                legend: {
                    display: false
                }
            });

        // clicks/CTR line graph
        //change clicksData and ctrData for timeline
        var clicksData = [{
            x: 10,
            y: 100
        }, {
            x: 20,
            y: 11
        }, {
            x: 23,
            y: 12
        }, {
            x: 27,
            y: 9
        }, {
            x: 28,
            y: 16
        }, {
            x: 29,
            y: 19
        }, {
            x: 30,
            y: 25
        }, {
            x: 31,
            y: 36
        }, {
            x: 32,
            y: 34
        }, {
            x: 33,
            y: 18
        }, {
            x: 34,
            y: 25
        }, {
            x: 35,
            y: 12
        }
        ]
        var ctrData = [{
            x: 10,
            y: 11
        }, {
            x: 20,
            y: 12
        }, {
            x: 23,
            y: 13
        }, {
            x: 27,
            y: 15
        }, {
            x: 28,
            y: 17
        }, {
            x: 29,
            y: 5
        }, {
            x: 30,
            y: 27
        }, {
            x: 31,
            y: 24
        }, {
            x: 32,
            y: 32
        }, {
            x: 33,
            y: 12
        }, {
            x: 34,
            y: 7
        }, {
            x: 35,
            y: 16
        }
        ]
        createGraph('line', 'clicksGraph', {
            labels: thisYearLabels,
            datasets: [
                {
                    label: "Clicks",
                    backgroundColor: "rgb(144,135,192)",
                    borderColor: "rgb(144,135,192)",
                    fill: false,
                    data: clicksData
                }, {
                    label: "CTR",
                    backgroundColor: "rgb(150,209,243)",
                    borderColor: "rgb(150,209,243)",
                    fill: false,
                    data: ctrData
                }
            ]
        }, {
                elements: {
                    line: {
                        tension: 0, // disables bezier curves
                    }
                }
            });

        //ctr/cpc line graph
        //change ctrLineData and cpcData for timeline
        var ctrLineData = [{
            x: 10,
            y: 11
        }, {
            x: 20,
            y: 12
        }, {
            x: 23,
            y: 13
        }, {
            x: 27,
            y: 15
        }, {
            x: 28,
            y: 17
        }, {
            x: 29,
            y: 5
        }, {
            x: 30,
            y: 27
        }, {
            x: 31,
            y: 24
        }, {
            x: 32,
            y: 32
        }, {
            x: 33,
            y: 12
        }, {
            x: 34,
            y: 7
        }, {
            x: 35,
            y: 16
        }
        ]
        var cpcData = [{
            x: 10,
            y: 25
        }, {
            x: 20,
            y: 16
        }, {
            x: 23,
            y: 9
        }, {
            x: 27,
            y: 36
        }, {
            x: 28,
            y: 49
        }, {
            x: 29,
            y: 25
        }, {
            x: 30,
            y: 54
        }, {
            x: 31,
            y: 36
        }, {
            x: 32,
            y: 12
        }, {
            x: 33,
            y: 24
        }, {
            x: 34,
            y: 28
        }, {
            x: 35,
            y: 35
        }
        ]
        createGraph('line', 'cpcGraph', {
            labels: thisYearLabels,
            datasets: [
                {
                    label: "CTR",
                    backgroundColor: "rgb(150,209,243)",
                    borderColor: "rgb(150,209,243)",
                    fill: false,
                    data: ctrLineData
                }, {
                    label: "CPC",
                    backgroundColor: "rgb(244,137,167)",
                    borderColor: "rgb(244,137,167)",
                    fill: false,
                    data: cpcData
                }

            ]
        }, {
                elements: {
                    line: {
                        tension: 0, // disables bezier curves
                    }
                }
            });

        //impressions data
        //add data in text()
        //$('#impressionDataCampaign').text('');
        $('#costDataCampaign').text('');
        $('#conversionDataCampaign').text('');
        $('#costPerConversionDataCampaign').text('');

        //$('#impressionData').text('');
        $('#costData').text('');
        $('#conversionData').text('');
        $('#costPerConversionData').text('');

        // Donut for clicks
        //change clickLabels and clickData for timeline
        var clickLabels = ["Adwords", "Facebook"];
        var clickData = [300, 200];
        createGraph('doughnut', "clickDonut", {
            labels: clickLabels,
            datasets: [{
                data: clickData,
                backgroundColor: ["#9087C0", "#96D1F3", "#F489A7", "#C5E5D6"]
            }]
        }, {
                legend: {
                    position: 'right'
                }
            });

        // Donut for costs
        //change costLabels and costData for timeline
        var costLabels = ["Adwords", "Facebook"];
        var costData = [170, 200];
        createGraph('doughnut', "costDonut", {
            labels: costLabels,
            datasets: [{
                data: costData,
                backgroundColor: ["#9087C0", "#96D1F3", "#F489A7", "#C5E5D6"]
            }]
        }, {
                legend: {
                    position: 'right'
                }
            });

        // Donut for conversion 
        //change conversionLabels and conversionData for timeline
        var conversionLabels = ["Adwords", "Facebook"];
        var conversionData = [400, 80];
        createGraph('doughnut', "conversionDonut", {
            labels: conversionLabels,
            datasets: [{
                data: conversionData,
                backgroundColor: ["#9087C0", "#96D1F3", "#F489A7", "#C5E5D6"]
            }]
        }, {
                legend: {
                    position: 'right',
                }
            });

        //campaign table
        //change campaignData for timeline
        var campaignData = [
            {
                "Campaign Name": "Google Adwords Electronics",
                "Channel": "Adwords",
                "Keywords": "usb drive",
                "Impression": "112522",
                "Clicks": "17000",
                "CTR": "0.15",
                "Conversions": "389",
                "Spend": "$8350",
                "CPC": "$0.49",
                "Cost / Conversion": "$21"
            }, {
                "Campaign Name": "Google Adwords Home",
                "Channel": "Adwords",
                "Keywords": "google clock",
                "Impression": "45234",
                "Clicks": "8500",
                "CTR": "0.18",
                "Conversions": "179",
                "Spend": "$6500",
                "CPC": "$0.76",
                "Cost / Conversion": "$36"
            }, {
                "Campaign Name": "Facebook Gadgets",
                "Channel": "facebook",
                "Keywords": "facebook variables clothing",
                "Impression": "60840",
                "Clicks": "550",
                "CTR": "0.09",
                "Conversions": "42",
                "Spend": "$4750",
                "CPC": "$0.86",
                "Cost / Conversion": "$113"
            }
        ]

        var campaignTable = createDataTable($('#campaignDetailsTable'), campaignData, [
            { data: 'Campaign Name' },
            { data: 'Channel', visible: false },
            { data: 'Keywords', visible: false },
            { data: 'Impression' },
            { data: 'Clicks' },
            { data: 'CTR' },
            { data: 'Conversions' },
            { data: 'Spend' },
            { data: 'CPC' },
            { data: 'Cost / Conversion' }
        ], true, true);

        //platform details table
        //change platformDetailData for timeline
        var platformDetailData = [
            {
                "Platform": "Adwords",
                "Clicks": "25500",
                "Impressions": "157756",
                "CTR": "0.16",
                "CPC": "$0.58",
                "Cost": "$14500",
                "Conversions": "568",
                "Conversion rate": "0.02",
                "Cost per Conversion": "$26"
            }, {
                "Platform": "Social",
                "Clicks": "550",
                "Impressions": "60840",
                "CTR": "0.09",
                "CPC": "$0.86",
                "Cost": "$4750",
                "Conversions": "42",
                "Conversion rate": "0.01",
                "Cost per Conversion": "$113"
            }
        ]
        createDataTable($('#platformDetailsTable'), platformDetailData, [
            { data: 'Platform' },
            { data: 'Clicks' },
            { data: 'Impressions' },
            { data: 'CTR' },
            { data: 'CPC' },
            { data: 'Cost' },
            { data: 'Conversions' },
            { data: 'Conversion rate' },
            { data: 'Cost per Conversion' }
        ], true, true);

        //top five keywords table
        //change topFiveKeywordData for timeline
        var topFiveKeywordData = [
            {
                "Channel": "Adwords",
                "Campaign Name": "Offer-Cross-Sell",
                "Keywords": "electronics+gadget+usb",
                "Quality Score": "4.8",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Offer-Cross-Sell",
                "Keywords": "iphone",
                "Quality Score": "4.3",
            }, {
                "Channel": "Facebook",
                "Campaign Name": "Offer-Cross-Sell",
                "Keywords": "headphone",
                "Quality Score": "3.9",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Offer-Cross-Sell",
                "Keywords": "mac",
                "Quality Score": "3.8",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Offer-Cross-Sell",
                "Keywords": "charger",
                "Quality Score": "3.5",
            }

        ]
        createDataTable($('#topFiveDetailsTable'), topFiveKeywordData, [
            { data: 'Channel' },
            { data: 'Campaign Name' },
            { data: 'Keywords' },
            { data: 'Quality Score' },
        ], false, false);

        //bottom five keywords table
        //change bottomFiveKeywordData for timeline
        var bottomFiveKeywordData = [
            {
                "Channel": "Adwords",
                "Campaign Name": "Offer-Cross-Sell_A1",
                "Keywords": "car charger",
                "Quality Score": "1.0",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Offer-Cross-Sell_B",
                "Keywords": "straps",
                "Quality Score": "0.8",
            }, {
                "Channel": "Facebook",
                "Campaign Name": "Offer-Cross-Sell_B2",
                "Keywords": "power",
                "Quality Score": "0.6",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Offer-Cross-Sell_C",
                "Keywords": "laptop_gaming",
                "Quality Score": "0.4",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Offer-Cross-Sell_C3",
                "Keywords": "portable",
                "Quality Score": "0.2",
            }
        ]
        createDataTable($('#bottomFiveDetailsTable'), bottomFiveKeywordData, [
            { data: 'Channel' },
            { data: 'Campaign Name' },
            { data: 'Keywords' },
            { data: 'Quality Score' },
        ], false, false);

        //all details table
        //change allDetailTableData for timeline
        var allDetailTableData = [
            {
                "Channel": "Adwords",
                "Campaign Name": "Cn_Adwords",
                "Keywords": "Earphones",
                "Quality Score": "1.0",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Cn_Adwords",
                "Keywords": "Air Pods",
                "Quality Score": "0.89",
            }, {
                "Channel": "Facebook",
                "Campaign Name": "C2_fb",
                "Keywords": "Wireless Charger",
                "Quality Score": "0.82",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Cn_Adwords",
                "Keywords": "Charger",
                "Quality Score": "0.67",
            }
        ]
        createDataTable($('#allDetailsTable'), allDetailTableData, [
            { data: 'Channel' },
            { data: 'Campaign Name' },
            { data: 'Keywords' },
            { data: 'Quality Score' },
        ], false, false);

        // Keywords table
        $("#campaignSelect").change(function () {
            var selectedTime = $("#campaignSelect option:selected").val();
            console.log(selectedTime);
            if (selectedTime == "Channel") {
                $("#hideCampaignChannel").show();
                campaignTable.column(1).visible(true);
            } else if (selectedTime == "Keywords") {
                $("#hideCampaignKeyword").show();
                campaignTable.column(2).visible(true);
            } else {
                $("#hideCampaignChannel").hide();
                $("#hideCampaignKeyword").hide();
                campaignTable.column(1).visible(false);
                campaignTable.column(2).visible(false);
            }
        });
        $('#hideCampaignChannel').click(function () {
            $('#hideCampaignChannel').hide();
            campaignTable.column(1).visible(false);
        });
        $('#hideCampaignKeyword').click(function () {
            $('#hideCampaignKeyword').hide();
            campaignTable.column(2).visible(false);
        });
    }

    //campaign this week changes
    function campaignsThisWeekChanges() {
        //top row
        //add data in text()
        $('#clicks').text('');
        $('#clicksPercent').text('').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#ctr').text('');
        $('#ctrPercent').text('').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');
        $('#cpc').text('');
        $('#cpcPercent').text('').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#impressions').text('');
        $('#impressionsPercent').text('').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');

        // Devices horizontal graph
        //change dataDesktops, dataMobiles and dataTablets for timeline
        var dataDesktops = [2000, 2345, 1345];
        var dataTablets = [1234, 1000, 786];
        var dataMobiles = [978, 345, 234];
        createGraph('horizontalBar', 'deviceGraph', {
            labels: ["Clicks", "CTR", "CPC"],
            datasets: [{
                data: dataDesktops,
                backgroundColor: "rgb(144,135,192)"
            },
            {
                data: dataTablets,
                backgroundColor: "rgb(150,209,243)"
            },
            {
                data: dataMobiles,
                backgroundColor: "rgb(244,137,167)"
            }
            ]
        }, {
                tooltips: {
                    enabled: true
                },
                scales: {
                    xAxes: [{
                        ticks: {
                            beginAtZero: true,
                            fontFamily: "'Open Sans Bold', sans-serif",
                            fontSize: 11
                        },
                        scaleLabel: {
                            display: false
                        },
                        gridLines: {
                        },
                        stacked: true
                    }],
                    yAxes: [{
                        gridLines: {
                            display: false,
                            color: "#fff",
                            zeroLineColor: "#fff",
                            zeroLineWidth: 0
                        },
                        ticks: {
                            fontFamily: "'Open Sans Bold', sans-serif",
                            fontSize: 11
                        },
                        stacked: true
                    }]
                },
                legend: {
                    display: false
                }
            });

        // clicks/CTR line graph
        //change clicksData and ctrData for timeline
        var clicksData = [{
            x: 10,
            y: 100
        }, {
            x: 20,
            y: 11
        }, {
            x: 23,
            y: 12
        }, {
            x: 27,
            y: 9
        }, {
            x: 28,
            y: 16
        }, {
            x: 29,
            y: 19
        }, {
            x: 30,
            y: 25
        }, {
            x: 31,
            y: 36
        }, {
            x: 32,
            y: 34
        }, {
            x: 33,
            y: 18
        }, {
            x: 34,
            y: 25
        }, {
            x: 35,
            y: 12
        }
        ]
        var ctrData = [{
            x: 10,
            y: 11
        }, {
            x: 20,
            y: 12
        }, {
            x: 23,
            y: 13
        }, {
            x: 27,
            y: 15
        }, {
            x: 28,
            y: 17
        }, {
            x: 29,
            y: 5
        }, {
            x: 30,
            y: 27
        }, {
            x: 31,
            y: 24
        }, {
            x: 32,
            y: 32
        }, {
            x: 33,
            y: 12
        }, {
            x: 34,
            y: 7
        }, {
            x: 35,
            y: 16
        }
        ]
        createGraph('line', 'clicksGraph', {
            labels: thisYearLabels,
            datasets: [
                {
                    label: "Clicks",
                    backgroundColor: "rgb(144,135,192)",
                    borderColor: "rgb(144,135,192)",
                    fill: false,
                    data: clicksData
                }, {
                    label: "CTR",
                    backgroundColor: "rgb(150,209,243)",
                    borderColor: "rgb(150,209,243)",
                    fill: false,
                    data: ctrData
                }
            ]
        }, {
                elements: {
                    line: {
                        tension: 0, // disables bezier curves
                    }
                }
            });

        //ctr/cpc line graph
        //change ctrLineData and cpcData for timeline
        var ctrLineData = [{
            x: 10,
            y: 11
        }, {
            x: 20,
            y: 12
        }, {
            x: 23,
            y: 13
        }, {
            x: 27,
            y: 15
        }, {
            x: 28,
            y: 17
        }, {
            x: 29,
            y: 5
        }, {
            x: 30,
            y: 27
        }, {
            x: 31,
            y: 24
        }, {
            x: 32,
            y: 32
        }, {
            x: 33,
            y: 12
        }, {
            x: 34,
            y: 7
        }, {
            x: 35,
            y: 16
        }
        ]
        var cpcData = [{
            x: 10,
            y: 25
        }, {
            x: 20,
            y: 16
        }, {
            x: 23,
            y: 9
        }, {
            x: 27,
            y: 36
        }, {
            x: 28,
            y: 49
        }, {
            x: 29,
            y: 25
        }, {
            x: 30,
            y: 54
        }, {
            x: 31,
            y: 36
        }, {
            x: 32,
            y: 12
        }, {
            x: 33,
            y: 24
        }, {
            x: 34,
            y: 28
        }, {
            x: 35,
            y: 35
        }
        ]
        createGraph('line', 'cpcGraph', {
            labels: thisYearLabels,
            datasets: [
                {
                    label: "CTR",
                    backgroundColor: "rgb(150,209,243)",
                    borderColor: "rgb(150,209,243)",
                    fill: false,
                    data: ctrLineData
                }, {
                    label: "CPC",
                    backgroundColor: "rgb(244,137,167)",
                    borderColor: "rgb(244,137,167)",
                    fill: false,
                    data: cpcData
                }

            ]
        }, {
                elements: {
                    line: {
                        tension: 0, // disables bezier curves
                    }
                }
            });

        //impressions data
        //add data in text()
        //$('#impressionDataCampaign').text('');
        $('#costDataCampaign').text('');
        $('#conversionDataCampaign').text('');
        $('#costPerConversionDataCampaign').text('');

        //$('#impressionData').text('');
        $('#costData').text('');
        $('#conversionData').text('');
        $('#costPerConversionData').text('');

        // Donut for clicks
        //change clickLabels and clickData for timeline
        var clickLabels = ["Adwords", "facebook", "Twitter", "Bing"];
        var clickData = [300, 200, 50, 60];
        createGraph('doughnut', "clickDonut", {
            labels: clickLabels,
            datasets: [{
                data: clickData,
                backgroundColor: ["#9087C0", "#96D1F3", "#F489A7", "#C5E5D6"]
            }]
        }, {
                legend: {
                    position: 'right'
                }
            });

        // Donut for costs
        //change costLabels and costData for timeline
        var costLabels = ["Adwords", "facebook", "Twitter", "Bing"];
        var costData = [170, 200, 20, 60];
        createGraph('doughnut', "costDonut", {
            labels: costLabels,
            datasets: [{
                data: costData,
                backgroundColor: ["#9087C0", "#96D1F3", "#F489A7", "#C5E5D6"]
            }]
        }, {
                legend: {
                    position: 'right'
                }
            });

        // Donut for conversion 
        //change conversionLabels and conversionData for timeline
        var conversionLabels = ["Adwords", "facebook", "Twitter", "Bing"];
        var conversionData = [400, 80, 60, 100];
        createGraph('doughnut', "conversionDonut", {
            labels: conversionLabels,
            datasets: [{
                data: conversionData,
                backgroundColor: ["#9087C0", "#96D1F3", "#F489A7", "#C5E5D6"]
            }]
        }, {
                legend: {
                    position: 'right'
                }
            });

        //campaign table
        //change campaignData for timeline
        var campaignData = [
            {
                "Campaign Name": "C1_Adwords",
                "Channel": "Adwords",
                "Keywords": "Phone",
                "Impression": "94,268,798",
                "Clicks": "4,12,000",
                "CTR": "$2,46,871",
                "Conversions": "64,500",
                "New Customers": "273,200",
                "Spend": "$382",
                "CPC": "$55",
                "CPA": "-85.26%"
            }, {
                "Campaign Name": "C2_Adwords",
                "Channel": "Adwords",
                "Keywords": "Laptops",
                "Impression": "4,268,798",
                "Clicks": "1,09,273",
                "CTR": "$46,871",
                "Conversions": "4,500",
                "New Customers": "23,210",
                "Spend": "$266",
                "CPC": "$52",
                "CPA": "-80.62%"
            }, {
                "Campaign Name": "C2_fb",
                "Channel": "facebook",
                "Keywords": "Tablets",
                "Impression": "702,268,798",
                "Clicks": "4,08,145",
                "CTR": "$1,36,812",
                "Conversions": "172,231",
                "New Customers": "360,221",
                "Spend": "$789",
                "CPC": "$36",
                "CPA": "-74.81%"
            }
        ]

        var campaignTable = createDataTable($('#campaignDetailsTable'), campaignData, [
            { data: 'Campaign Name' },
            { data: 'Channel', visible: false },
            { data: 'Keywords', visible: false },
            { data: 'Impression' },
            { data: 'Clicks' },
            { data: 'CTR' },
            { data: 'Conversions' },
            { data: 'New Customers' },
            { data: 'Spend' },
            { data: 'CPC' },
            { data: 'CPA' }
        ], true, true);

        //platform details table
        //change platformDetailData for timeline
        var platformDetailData = [
            {
                "Platform": "Adwords",
                "Clicks": "94,815",
                "Impressions": "194,268,798",
                "CTR": "0.59%",
                "CPC": "$1.70",
                "Cost": "161,002",
                "Conversions": "2,663",
                "Conversion rate": "2.81%",
                "Cost per Conversion": "$60.44"
            }, {
                "Platform": "Facebook",
                "Clicks": "65,129",
                "Impressions": "11,126,828",
                "CTR": "0.55%",
                "CPC": "$1.21",
                "Cost": "78,702",
                "Conversions": "1,772",
                "Conversion rate": "2.72%",
                "Cost per Conversion": "$44.50"
            }, {
                "Platform": "Twitter",
                "Clicks": "52,743",
                "Impressions": "31,653,102",
                "CTR": "0.17%",
                "CPC": "$1.44",
                "Cost": "75,678",
                "Conversions": "1,223",
                "Conversion rate": "2.34%",
                "Cost per Conversion": "$61.58"
            }, {
                "Platform": "Bing",
                "Clicks": "35,285",
                "Impressions": "6,712,342",
                "CTR": "0.53%",
                "CPC": "$1.98",
                "Cost": "16,211",
                "Conversions": "1,075",
                "Conversion rate": "3.05%",
                "Cost per Conversion": "$61.78"
            }
        ]
        createDataTable($('#platformDetailsTable'), platformDetailData, [
            { data: 'Platform' },
            { data: 'Clicks' },
            { data: 'Impressions' },
            { data: 'CTR' },
            { data: 'CPC' },
            { data: 'Cost' },
            { data: 'Conversions' },
            { data: 'Conversion rate' },
            { data: 'Cost per Conversion' }
        ], true, true);

        //top five keywords table
        //change topFiveKeywordData for timeline
        var topFiveKeywordData = [
            {
                "Channel": "Adwords",
                "Campaign Name": "C1_Adwords",
                "Keywords": "iPhone 6s",
                "Quality Score": "4.2",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "C2_Adwords",
                "Keywords": "One Plus 6T",
                "Quality Score": "4.1",
            }, {
                "Channel": "Facebook",
                "Campaign Name": "C1_fb",
                "Keywords": "Mi A1",
                "Quality Score": "3.9",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "C3_Adwords",
                "Keywords": "iPhone 6s",
                "Quality Score": "3.8",
            }
        ]
        createDataTable($('#topFiveDetailsTable'), topFiveKeywordData, [
            { data: 'Channel' },
            { data: 'Campaign Name' },
            { data: 'Keywords' },
            { data: 'Quality Score' },
        ], false, false);

        //bottom five keywords table
        //change bottomFiveKeywordData for timeline
        var bottomFiveKeywordData = [
            {
                "Channel": "Adwords",
                "Campaign Name": "Cn_Adwords",
                "Keywords": "Earphones",
                "Quality Score": "1.0",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Cn_Adwords",
                "Keywords": "Air Pods",
                "Quality Score": "0.89",
            }, {
                "Channel": "Facebook",
                "Campaign Name": "C2_fb",
                "Keywords": "Wireless Charger",
                "Quality Score": "0.82",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Cn_Adwords",
                "Keywords": "Charger",
                "Quality Score": "0.67",
            }
        ]
        createDataTable($('#bottomFiveDetailsTable'), bottomFiveKeywordData, [
            { data: 'Channel' },
            { data: 'Campaign Name' },
            { data: 'Keywords' },
            { data: 'Quality Score' },
        ], false, false);

        //all details table
        //change allDetailTableData for timeline
        var allDetailTableData = [
            {
                "Channel": "Adwords",
                "Campaign Name": "Cn_Adwords",
                "Keywords": "Earphones",
                "Quality Score": "1.0",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Cn_Adwords",
                "Keywords": "Air Pods",
                "Quality Score": "0.89",
            }, {
                "Channel": "Facebook",
                "Campaign Name": "C2_fb",
                "Keywords": "Wireless Charger",
                "Quality Score": "0.82",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Cn_Adwords",
                "Keywords": "Charger",
                "Quality Score": "0.67",
            }
        ]
        createDataTable($('#allDetailsTable'), allDetailTableData, [
            { data: 'Channel' },
            { data: 'Campaign Name' },
            { data: 'Keywords' },
            { data: 'Quality Score' },
        ], false, false);

        // Keywords table
        $("#campaignSelect").change(function () {
            var selectedTime = $("#campaignSelect option:selected").val();
            console.log(selectedTime);
            if (selectedTime == "Channel") {
                $("#hideCampaignChannel").show();
                campaignTable.column(1).visible(true);
            } else if (selectedTime == "Keywords") {
                $("#hideCampaignKeyword").show();
                campaignTable.column(2).visible(true);
            } else {
                $("#hideCampaignChannel").hide();
                $("#hideCampaignKeyword").hide();
                campaignTable.column(1).visible(false);
                campaignTable.column(2).visible(false);
            }
        });
        $('#hideCampaignChannel').click(function () {
            $('#hideCampaignChannel').hide();
            campaignTable.column(1).visible(false);
        });
        $('#hideCampaignKeyword').click(function () {
            $('#hideCampaignKeyword').hide();
            campaignTable.column(2).visible(false);
        });
    }

    //campaign last week changes
    function campaignsLastWeekChanges() {
        //top row
        //add data in text()
        $('#clicks').text('');
        $('#clicksPercent').text('').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#ctr').text('');
        $('#ctrPercent').text('').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');
        $('#cpc').text('');
        $('#cpcPercent').text('').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#impressions').text('');
        $('#impressionsPercent').text('').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');

        // Devices horizontal graph
        //change dataDesktops, dataMobiles and dataTablets for timeline
        var dataDesktops = [2000, 2345, 1345];
        var dataTablets = [1234, 1000, 786];
        var dataMobiles = [978, 345, 234];
        createGraph('horizontalBar', 'deviceGraph', {
            labels: ["Clicks", "CTR", "CPC"],
            datasets: [{
                data: dataDesktops,
                backgroundColor: "rgb(144,135,192)"
            },
            {
                data: dataTablets,
                backgroundColor: "rgb(150,209,243)"
            },
            {
                data: dataMobiles,
                backgroundColor: "rgb(244,137,167)"
            }
            ]
        }, {
                tooltips: {
                    enabled: true
                },
                scales: {
                    xAxes: [{
                        ticks: {
                            beginAtZero: true,
                            fontFamily: "'Open Sans Bold', sans-serif",
                            fontSize: 11
                        },
                        scaleLabel: {
                            display: false
                        },
                        gridLines: {
                        },
                        stacked: true
                    }],
                    yAxes: [{
                        gridLines: {
                            display: false,
                            color: "#fff",
                            zeroLineColor: "#fff",
                            zeroLineWidth: 0
                        },
                        ticks: {
                            fontFamily: "'Open Sans Bold', sans-serif",
                            fontSize: 11
                        },
                        stacked: true
                    }]
                },
                legend: {
                    display: false
                }
            });

        // clicks/CTR line graph
        //change clicksData and ctrData for timeline
        var clicksData = [{
            x: 10,
            y: 100
        }, {
            x: 20,
            y: 11
        }, {
            x: 23,
            y: 12
        }, {
            x: 27,
            y: 9
        }, {
            x: 28,
            y: 16
        }, {
            x: 29,
            y: 19
        }, {
            x: 30,
            y: 25
        }, {
            x: 31,
            y: 36
        }, {
            x: 32,
            y: 34
        }, {
            x: 33,
            y: 18
        }, {
            x: 34,
            y: 25
        }, {
            x: 35,
            y: 12
        }
        ]
        var ctrData = [{
            x: 10,
            y: 11
        }, {
            x: 20,
            y: 12
        }, {
            x: 23,
            y: 13
        }, {
            x: 27,
            y: 15
        }, {
            x: 28,
            y: 17
        }, {
            x: 29,
            y: 5
        }, {
            x: 30,
            y: 27
        }, {
            x: 31,
            y: 24
        }, {
            x: 32,
            y: 32
        }, {
            x: 33,
            y: 12
        }, {
            x: 34,
            y: 7
        }, {
            x: 35,
            y: 16
        }
        ]
        createGraph('line', 'clicksGraph', {
            labels: lastWeekLabels,
            datasets: [
                {
                    label: "Clicks",
                    backgroundColor: "rgb(144,135,192)",
                    borderColor: "rgb(144,135,192)",
                    fill: false,
                    data: clicksData
                }, {
                    label: "CTR",
                    backgroundColor: "rgb(150,209,243)",
                    borderColor: "rgb(150,209,243)",
                    fill: false,
                    data: ctrData
                }
            ]
        }, {
                elements: {
                    line: {
                        tension: 0, // disables bezier curves
                    }
                }
            });

        //ctr/cpc line graph
        //change ctrLineData and cpcData for timeline
        var ctrLineData = [{
            x: 10,
            y: 11
        }, {
            x: 20,
            y: 12
        }, {
            x: 23,
            y: 13
        }, {
            x: 27,
            y: 15
        }, {
            x: 28,
            y: 17
        }, {
            x: 29,
            y: 5
        }, {
            x: 30,
            y: 27
        }, {
            x: 31,
            y: 24
        }, {
            x: 32,
            y: 32
        }, {
            x: 33,
            y: 12
        }, {
            x: 34,
            y: 7
        }, {
            x: 35,
            y: 16
        }
        ]
        var cpcData = [{
            x: 10,
            y: 25
        }, {
            x: 20,
            y: 16
        }, {
            x: 23,
            y: 9
        }, {
            x: 27,
            y: 36
        }, {
            x: 28,
            y: 49
        }, {
            x: 29,
            y: 25
        }, {
            x: 30,
            y: 54
        }, {
            x: 31,
            y: 36
        }, {
            x: 32,
            y: 12
        }, {
            x: 33,
            y: 24
        }, {
            x: 34,
            y: 28
        }, {
            x: 35,
            y: 35
        }
        ]
        createGraph('line', 'cpcGraph', {
            labels: lastWeekLabels,
            datasets: [
                {
                    label: "CTR",
                    backgroundColor: "rgb(150,209,243)",
                    borderColor: "rgb(150,209,243)",
                    fill: false,
                    data: ctrLineData
                }, {
                    label: "CPC",
                    backgroundColor: "rgb(244,137,167)",
                    borderColor: "rgb(244,137,167)",
                    fill: false,
                    data: cpcData
                }

            ]
        }, {
                elements: {
                    line: {
                        tension: 0, // disables bezier curves
                    }
                }
            });

        //impressions data
        //add data in text()
        // $('#impressionDataCampaign').text('');
        $('#costDataCampaign').text('');
        $('#conversionDataCampaign').text('');
        $('#costPerConversionDataCampaign').text('');

        //$('#impressionData').text('');
        $('#costData').text('');
        $('#conversionData').text('');
        $('#costPerConversionData').text('');

        // Donut for clicks
        //change clickLabels and clickData for timeline
        var clickLabels = ["Adwords", "facebook", "Twitter", "Bing"];
        var clickData = [300, 200, 50, 60];
        createGraph('doughnut', "clickDonut", {
            labels: clickLabels,
            datasets: [{
                data: clickData,
                backgroundColor: ["#9087C0", "#96D1F3", "#F489A7", "#C5E5D6"]
            }]
        }, {
                legend: {
                    position: 'right'
                }
            });

        // Donut for costs
        //change costLabels and costData for timeline
        var costLabels = ["Adwords", "facebook", "Twitter", "Bing"];
        var costData = [170, 200, 20, 60];
        createGraph('doughnut', "costDonut", {
            labels: costLabels,
            datasets: [{
                data: costData,
                backgroundColor: ["#9087C0", "#96D1F3", "#F489A7", "#C5E5D6"]
            }]
        }, {
                legend: {
                    position: 'right'
                }
            });

        // Donut for conversion 
        //change conversionLabels and conversionData for timeline
        var conversionLabels = ["Adwords", "facebook", "Twitter", "Bing"];
        var conversionData = [400, 80, 60, 100];
        createGraph('doughnut', "conversionDonut", {
            labels: conversionLabels,
            datasets: [{
                data: conversionData,
                backgroundColor: ["#9087C0", "#96D1F3", "#F489A7", "#C5E5D6"]
            }]
        }, {
                legend: {
                    position: 'right'
                }
            });

        //campaign table
        //change campaignData for timeline
        var campaignData = [
            {
                "Campaign Name": "C1_Adwords",
                "Channel": "Adwords",
                "Keywords": "Phone",
                "Impression": "94,268,798",
                "Clicks": "4,12,000",
                "CTR": "$2,46,871",
                "Conversions": "64,500",
                "New Customers": "273,200",
                "Spend": "$382",
                "CPC": "$55",
                "CPA": "-85.26%"
            }, {
                "Campaign Name": "C2_Adwords",
                "Channel": "Adwords",
                "Keywords": "Laptops",
                "Impression": "4,268,798",
                "Clicks": "1,09,273",
                "CTR": "$46,871",
                "Conversions": "4,500",
                "New Customers": "23,210",
                "Spend": "$266",
                "CPC": "$52",
                "CPA": "-80.62%"
            }, {
                "Campaign Name": "C2_fb",
                "Channel": "facebook",
                "Keywords": "Tablets",
                "Impression": "702,268,798",
                "Clicks": "4,08,145",
                "CTR": "$1,36,812",
                "Conversions": "172,231",
                "New Customers": "360,221",
                "Spend": "$789",
                "CPC": "$36",
                "CPA": "-74.81%"
            }, {
                "Campaign Name": "C2_fb",
                "Channel": "facebook",
                "Keywords": "Internet",
                "Impression": "94,268,798",
                "Clicks": "4,12,000",
                "CTR": "$2,46,171",
                "Conversions": "61,200",
                "New Customers": "223,230",
                "Spend": "$612",
                "CPC": "$53",
                "CPA": "-82.26%"
            }, {
                "Campaign Name": "C1_Adwords",
                "Channel": "twitter",
                "Keywords": "Macbook",
                "Impression": "702,228,791",
                "Clicks": "4,13,211",
                "CTR": "$20,26,171",
                "Conversions": "64,522",
                "New Customers": "22,210",
                "Spend": "$312",
                "CPC": "$35",
                "CPA": "-60.26%"
            }
        ]

        var campaignTable = createDataTable($('#campaignDetailsTable'), campaignData, [
            { data: 'Campaign Name' },
            { data: 'Channel', visible: false },
            { data: 'Keywords', visible: false },
            { data: 'Impression' },
            { data: 'Clicks' },
            { data: 'CTR' },
            { data: 'Conversions' },
            { data: 'New Customers' },
            { data: 'Spend' },
            { data: 'CPC' },
            { data: 'CPA' }
        ], true, true);

        //platform details table
        //change platformDetailData for timeline
        var platformDetailData = [
            {
                "Platform": "Adwords",
                "Clicks": "94,815",
                "Impressions": "194,268,798",
                "CTR": "0.59%",
                "CPC": "$1.70",
                "Cost": "161,002",
                "Conversions": "2,663",
                "Conversion rate": "2.81%",
                "Cost per Conversion": "$60.44"
            }, {
                "Platform": "Facebook",
                "Clicks": "65,129",
                "Impressions": "11,126,828",
                "CTR": "0.55%",
                "CPC": "$1.21",
                "Cost": "78,702",
                "Conversions": "1,772",
                "Conversion rate": "2.72%",
                "Cost per Conversion": "$44.50"
            }, {
                "Platform": "Twitter",
                "Clicks": "52,743",
                "Impressions": "31,653,102",
                "CTR": "0.17%",
                "CPC": "$1.44",
                "Cost": "75,678",
                "Conversions": "1,223",
                "Conversion rate": "2.34%",
                "Cost per Conversion": "$61.58"
            }, {
                "Platform": "Bing",
                "Clicks": "35,285",
                "Impressions": "6,712,342",
                "CTR": "0.53%",
                "CPC": "$1.98",
                "Cost": "16,211",
                "Conversions": "1,075",
                "Conversion rate": "3.05%",
                "Cost per Conversion": "$61.78"
            }
        ]
        createDataTable($('#platformDetailsTable'), platformDetailData, [
            { data: 'Platform' },
            { data: 'Clicks' },
            { data: 'Impressions' },
            { data: 'CTR' },
            { data: 'CPC' },
            { data: 'Cost' },
            { data: 'Conversions' },
            { data: 'Conversion rate' },
            { data: 'Cost per Conversion' }
        ], true, true);

        //top five keywords table
        //change topFiveKeywordData for timeline
        var topFiveKeywordData = [
            {
                "Channel": "Adwords",
                "Campaign Name": "C1_Adwords",
                "Keywords": "iPhone 6s",
                "Quality Score": "4.2",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "C2_Adwords",
                "Keywords": "One Plus 6T",
                "Quality Score": "4.1",
            }, {
                "Channel": "Facebook",
                "Campaign Name": "C1_fb",
                "Keywords": "Mi A1",
                "Quality Score": "3.9",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "C3_Adwords",
                "Keywords": "iPhone 6s",
                "Quality Score": "3.8",
            }
        ]
        createDataTable($('#topFiveDetailsTable'), topFiveKeywordData, [
            { data: 'Channel' },
            { data: 'Campaign Name' },
            { data: 'Keywords' },
            { data: 'Quality Score' },
        ], false, false);

        //bottom five keywords table
        //change bottomFiveKeywordData for timeline
        var bottomFiveKeywordData = [
            {
                "Channel": "Adwords",
                "Campaign Name": "Cn_Adwords",
                "Keywords": "Earphones",
                "Quality Score": "1.0",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Cn_Adwords",
                "Keywords": "Air Pods",
                "Quality Score": "0.89",
            }, {
                "Channel": "Facebook",
                "Campaign Name": "C2_fb",
                "Keywords": "Wireless Charger",
                "Quality Score": "0.82",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Cn_Adwords",
                "Keywords": "Charger",
                "Quality Score": "0.67",
            }
        ]
        createDataTable($('#bottomFiveDetailsTable'), bottomFiveKeywordData, [
            { data: 'Channel' },
            { data: 'Campaign Name' },
            { data: 'Keywords' },
            { data: 'Quality Score' },
        ], false, false);

        //all details table
        //change allDetailTableData for timeline
        var allDetailTableData = [
            {
                "Channel": "Adwords",
                "Campaign Name": "Cn_Adwords",
                "Keywords": "Earphones",
                "Quality Score": "1.0",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Cn_Adwords",
                "Keywords": "Air Pods",
                "Quality Score": "0.89",
            }, {
                "Channel": "Facebook",
                "Campaign Name": "C2_fb",
                "Keywords": "Wireless Charger",
                "Quality Score": "0.82",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Cn_Adwords",
                "Keywords": "Charger",
                "Quality Score": "0.67",
            }
        ]
        createDataTable($('#allDetailsTable'), allDetailTableData, [
            { data: 'Channel' },
            { data: 'Campaign Name' },
            { data: 'Keywords' },
            { data: 'Quality Score' },
        ], false, false);

        // Keywords table
        $("#campaignSelect").change(function () {
            var selectedTime = $("#campaignSelect option:selected").val();
            console.log(selectedTime);
            if (selectedTime == "Channel") {
                $("#hideCampaignChannel").show();
                campaignTable.column(1).visible(true);
            } else if (selectedTime == "Keywords") {
                $("#hideCampaignKeyword").show();
                campaignTable.column(2).visible(true);
            } else {
                $("#hideCampaignChannel").hide();
                $("#hideCampaignKeyword").hide();
                campaignTable.column(1).visible(false);
                campaignTable.column(2).visible(false);
            }
        });
        $('#hideCampaignChannel').click(function () {
            $('#hideCampaignChannel').hide();
            campaignTable.column(1).visible(false);
        });
        $('#hideCampaignKeyword').click(function () {
            $('#hideCampaignKeyword').hide();
            campaignTable.column(2).visible(false);
        });
    }

    //campaign this month changes
    function campaignsThisMonthChanges() {
        //top row
        //add data in text()
        $('#clicks').text('20,000');
        $('#clicksPercent').text('0.25%').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#ctr').text('0.05%');
        $('#ctrPercent').text('0.25%').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');
        $('#cpc').text('$0.98');
        $('#cpcPercent').text('0.25%').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#impressions').text('218,596');
        $('#impressionsPercent').text('0.25%').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');

        // Devices horizontal graph
        //change dataDesktops, dataMobiles and dataTablets for timeline
        var dataDesktops = [7000, 2345, 1345];
        var dataTablets = [5500, 1000, 786];
        var dataMobiles = [7500, 345, 234];
        createGraph('horizontalBar', 'deviceGraph', {
            labels: ["Clicks", "CTR", "CPC"],
            datasets: [{
                data: dataDesktops,
                backgroundColor: "rgb(144,135,192)"
            },
            {
                data: dataTablets,
                backgroundColor: "rgb(150,209,243)"
            },
            {
                data: dataMobiles,
                backgroundColor: "rgb(244,137,167)"
            }
            ]
        }, {
                tooltips: {
                    enabled: true
                },
                scales: {
                    xAxes: [{
                        ticks: {
                            beginAtZero: true,
                            fontFamily: "'Open Sans Bold', sans-serif",
                            fontSize: 11
                        },
                        scaleLabel: {
                            display: false
                        },
                        gridLines: {
                        },
                        stacked: true
                    }],
                    yAxes: [{
                        gridLines: {
                            display: false,
                            color: "#fff",
                            zeroLineColor: "#fff",
                            zeroLineWidth: 0
                        },
                        ticks: {
                            fontFamily: "'Open Sans Bold', sans-serif",
                            fontSize: 11
                        },
                        stacked: true
                    }]
                },
                legend: {
                    display: false
                }
            });

        // clicks/CTR line graph
        //change clicksData and ctrData for timeline
        var clicksData = [{
            x: 10,
            y: 100
        }, {
            x: 20,
            y: 11
        }, {
            x: 23,
            y: 12
        }, {
            x: 27,
            y: 9
        }, {
            x: 28,
            y: 16
        }, {
            x: 29,
            y: 19
        }, {
            x: 30,
            y: 25
        }, {
            x: 31,
            y: 36
        }, {
            x: 32,
            y: 34
        }, {
            x: 33,
            y: 18
        }, {
            x: 34,
            y: 25
        }, {
            x: 35,
            y: 12
        }
        ]
        var ctrData = [{
            x: 10,
            y: 11
        }, {
            x: 20,
            y: 12
        }, {
            x: 23,
            y: 13
        }, {
            x: 27,
            y: 15
        }, {
            x: 28,
            y: 17
        }, {
            x: 29,
            y: 5
        }, {
            x: 30,
            y: 27
        }, {
            x: 31,
            y: 24
        }, {
            x: 32,
            y: 32
        }, {
            x: 33,
            y: 12
        }, {
            x: 34,
            y: 7
        }, {
            x: 35,
            y: 16
        }
        ]
        createGraph('line', 'clicksGraph', {
            labels: thisYearLabels,
            datasets: [
                {
                    label: "Clicks",
                    backgroundColor: "rgb(144,135,192)",
                    borderColor: "rgb(144,135,192)",
                    fill: false,
                    data: clicksData
                }, {
                    label: "CTR",
                    backgroundColor: "rgb(150,209,243)",
                    borderColor: "rgb(150,209,243)",
                    fill: false,
                    data: ctrData
                }
            ]
        }, {
                elements: {
                    line: {
                        tension: 0, // disables bezier curves
                    }
                }
            });

        //ctr/cpc line graph
        //change ctrLineData and cpcData for timeline
        var ctrLineData = [{
            x: 10,
            y: 11
        }, {
            x: 20,
            y: 12
        }, {
            x: 23,
            y: 13
        }, {
            x: 27,
            y: 15
        }, {
            x: 28,
            y: 17
        }, {
            x: 29,
            y: 5
        }, {
            x: 30,
            y: 27
        }, {
            x: 31,
            y: 24
        }, {
            x: 32,
            y: 32
        }, {
            x: 33,
            y: 12
        }, {
            x: 34,
            y: 7
        }, {
            x: 35,
            y: 16
        }
        ]
        var cpcData = [{
            x: 10,
            y: 25
        }, {
            x: 20,
            y: 16
        }, {
            x: 23,
            y: 9
        }, {
            x: 27,
            y: 36
        }, {
            x: 28,
            y: 49
        }, {
            x: 29,
            y: 25
        }, {
            x: 30,
            y: 54
        }, {
            x: 31,
            y: 36
        }, {
            x: 32,
            y: 12
        }, {
            x: 33,
            y: 24
        }, {
            x: 34,
            y: 28
        }, {
            x: 35,
            y: 35
        }
        ]
        createGraph('line', 'cpcGraph', {
            labels: thisYearLabels,
            datasets: [
                {
                    label: "CTR",
                    backgroundColor: "rgb(150,209,243)",
                    borderColor: "rgb(150,209,243)",
                    fill: false,
                    data: ctrLineData
                }, {
                    label: "CPC",
                    backgroundColor: "rgb(244,137,167)",
                    borderColor: "rgb(244,137,167)",
                    fill: false,
                    data: cpcData
                }

            ]
        }, {
                elements: {
                    line: {
                        tension: 0, // disables bezier curves
                    }
                }
            });

        //impressions data
        //add data in text()
        //$('#impressionDataCampaign').text('40,000');
        $('#costDataCampaign').text('$19,600');
        $('#conversionDataCampaign').text('588');
        $('#costPerConversionDataCampaign').text('$33');

        //$('#impressionData').text('40.5K');
        $('#costData').text('$19,600');
        $('#conversionData').text('588');
        $('#costPerConversionData').text('$33');

        // Donut for clicks
        //change clickLabels and clickData for timeline
        var clickLabels = ["Adwords", "Facebook", "Instagram"];
        var clickData = [300, 200, 100];
        createGraph('doughnut', "clickDonut", {
            labels: clickLabels,
            datasets: [{
                data: clickData,
                backgroundColor: ["#9087C0", "#96D1F3", "#F489A7", "#C5E5D6"]
            }]
        }, {
                legend: {
                    position: 'bottom',
                    onClick: null
                }
            });

        // Donut for costs
        //change costLabels and costData for timeline
        var costLabels = ["Adwords", "Facebook", "Instagram"];
        var costData = [170, 200, 250];
        createGraph('doughnut', "costDonut", {
            labels: costLabels,
            datasets: [{
                data: costData,
                backgroundColor: ["#9087C0", "#96D1F3", "#F489A7", "#C5E5D6"]
            }]
        }, {
                legend: {
                    position: 'bottom',
                    onClick: null
                }
            });

        // Donut for conversion 
        //change conversionLabels and conversionData for timeline
        var conversionLabels = ["Adwords", "Facebook", "Instagram"];
        var conversionData = [400, 80, 100];
        createGraph('doughnut', "conversionDonut", {
            labels: conversionLabels,
            datasets: [{
                data: conversionData,
                backgroundColor: ["#9087C0", "#96D1F3", "#F489A7", "#C5E5D6"]
            }]
        }, {
                legend: {
                    position: 'bottom',
                    onClick: null
                }
            });

        //keyword statistics table
        //change keywordData for timeline
        var keywordData = [
            {
                "CampaignName": "Google Adwords Electronics",
                "Status": "Enabled",
                "Keywords": "usb drive",
                "Impression": "112,522",
                "Clicks": "17,000",
                "CTR": "0.15",
                "Conversions": "389",
                "Spend": "$8,350",
                "CPC": "$0.49",
                "Cost / Conversion": "$21",
                "Quality Score": "5"
            }, {
                "CampaignName": "Google Adwords Home",
                "Status": "Enabled",
                "Keywords": "google clock",
                "Impression": "45,234",
                "Clicks": "8,500",
                "CTR": "0.18",
                "Conversions": "179",
                "Spend": "$6,500",
                "CPC": "$0.76",
                "Cost / Conversion": "$36",
                "Quality Score": "6"
            }, {
                "CampaignName": "Facebook Gadgets",
                "Status": "Enabled",
                "Keywords": "facebook variables clothing",
                "Impression": "60,840",
                "Clicks": "550",
                "CTR": "0.09",
                "Conversions": "42",
                "Spend": "$4,750",
                "CPC": "$0.86",
                "Cost / Conversion": "$113",
                "Quality Score": "5"
            }
        ]

        var campaignTable = createDataTable($('#campaignDetailsKeywordAndChannelTable'), keywordData, [
            { data: 'CampaignName' },
            { data: 'Status'},
            { data: 'Keywords'},
            { data: 'Impression' },
            { data: 'Clicks' },
            { data: 'CTR' },
            { data: 'Conversions' },
            { data: 'Spend' },
            { data: 'CPC' },
            { data: 'Cost / Conversion' },
            { data: 'Quality Score'}
        ], true, true);

        //ad statistics table
        //change adData for timeline
        var adData = [
            {
                "CampaignName": "Google Adwords Electronics",
                "Channel": "GoogleAds",
                "AdGroup": "Buy Electronics",
                "Ad": "All Electric",
                "Impression": "56,261",
                "Clicks": "8,500",
                "CTR": "0.15",
                "Conversions": "190",
                "Spend": "$4,000",
                "CPC": "$0.49",
                "Cost / Conversion": "$21"
            }, {
                "CampaignName": "Google Adwords Home",
                "Channel": "GoogleAds",
                "AdGroup": "Home Stats",
                "Ad": "Google Home",
                "Impression": "22,617",
                "Clicks": "4,250",
                "CTR": "0.18",
                "Conversions": "89",
                "Spend": "$3,250",
                "CPC": "$0.76",
                "Cost / Conversion": "$36"
            }, {
                "CampaignName": "Facebook Gadgets",
                "Channel": "FacebookAds",
                "AdGroup": "Gadgets",
                "Ad": "All Gadgets",
                "Impression": "30,420",
                "Clicks": "275",
                "CTR": "0.09",
                "Conversions": "21",
                "Spend": "$2,371",
                "CPC": "$0.86",
                "Cost / Conversion": "$112"
            }
        ]

        var campaignTable = createDataTable($('#adDetailsTable'), adData, [
            { data: 'CampaignName' },
            { data: 'Channel'},
            { data: 'AdGroup'},
            { data: 'Ad'},
            { data: 'Impression' },
            { data: 'Clicks' },
            { data: 'CTR' },
            { data: 'Conversions' },
            { data: 'Spend' },
            { data: 'CPC' },
            { data: 'Cost / Conversion' }
        ], true, true);

        //platform details table
        //change platformDetailData for timeline
        var platformDetailData = [
            {
                "Platform": "Adwords",
                "Clicks": "25,500",
                "Impressions": "157,756",
                "CTR": "0.16",
                "CPC": "$0.58",
                "Cost": "$14,500",
                "Conversions": "568",
                "Conversion rate": "0.02",
                "Cost per Conversion": "$26"
            }, {
                "Platform": "Facebook",
                "Clicks": "300",
                "Impressions": "30,840",
                "CTR": "0.05",
                "CPC": "$0.56",
                "Cost": "$2,750",
                "Conversions": "21",
                "Conversion rate": "0.05",
                "Cost per Conversion": "$58"
            }, {
                "Platform": "Instagram",
                "Clicks": "250",
                "Impressions": "30,000",
                "CTR": "0.04",
                "CPC": "$0.30",
                "Cost": "$2,000",
                "Conversions": "21",
                "Conversion rate": "0.01",
                "Cost per Conversion": "$57"
            }
        ]
        createDataTable($('#platformDetailsTable'), platformDetailData, [
            { data: 'Platform' },
            { data: 'Clicks' },
            { data: 'Impressions' },
            { data: 'CTR' },
            { data: 'CPC' },
            { data: 'Cost' },
            { data: 'Conversions' },
            { data: 'Conversion rate' },
            { data: 'Cost per Conversion' }
        ], true, true);

        //top five keywords table
        //change topFiveKeywordData for timeline
        var topFiveKeywordData = [
            {
                "Channel": "Adwords",
                "Campaign Name": "Offer-Cross-Sell",
                "Keywords": "electronics+gadget+usb",
                "Quality Score": "4.8",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Offer-Cross-Sell",
                "Keywords": "iphone adapter",
                "Quality Score": "4.3",
            }, {
                "Channel": "Facebook",
                "Campaign Name": "Offer-Cross-Sell",
                "Keywords": "headphone for kids",
                "Quality Score": "3.9",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Offer-Cross-Sell",
                "Keywords": "mac air",
                "Quality Score": "3.8",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Offer-Cross-Sell",
                "Keywords": "charger adapter",
                "Quality Score": "3.5",
            }

        ]
        createDataTable($('#topFiveDetailsTable'), topFiveKeywordData, [
            { data: 'Channel' },
            { data: 'Campaign Name' },
            { data: 'Keywords' },
            { data: 'Quality Score' },
        ], false, false);

        //bottom five keywords table
        //change bottomFiveKeywordData for timeline
        var bottomFiveKeywordData = [
            {
                "Channel": "Adwords",
                "Campaign Name": "Offer-Cross-Sell_A1",
                "Keywords": "car charger for laptop",
                "Quality Score": "1.0",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Offer-Cross-Sell_B",
                "Keywords": "straps - cable ties velcro",
                "Quality Score": "0.8",
            }, {
                "Channel": "Facebook",
                "Campaign Name": "Offer-Cross-Sell_B2",
                "Keywords": "power bank 15000",
                "Quality Score": "0.6",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Offer-Cross-Sell_C",
                "Keywords": "gaming laptop under 10000",
                "Quality Score": "0.4",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Offer-Cross-Sell_C3",
                "Keywords": "portable charger with outlet",
                "Quality Score": "0.2",
            }
        ]
        createDataTable($('#bottomFiveDetailsTable'), bottomFiveKeywordData, [
            { data: 'Channel' },
            { data: 'Campaign Name' },
            { data: 'Keywords' },
            { data: 'Quality Score' },
        ], false, false);

        //all details table
        //change allDetailTableData for timeline
        var allDetailTableData = [
            {
                "Channel": "Adwords",
                "Campaign Name": "Cn_Adwords",
                "Keywords": "Earphones",
                "Quality Score": "1.0",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Cn_Adwords",
                "Keywords": "Air Pods",
                "Quality Score": "0.89",
            }, {
                "Channel": "Facebook",
                "Campaign Name": "C2_fb",
                "Keywords": "Wireless Charger",
                "Quality Score": "0.82",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Cn_Adwords",
                "Keywords": "Charger",
                "Quality Score": "0.67",
            }
        ]
        createDataTable($('#allDetailsTable'), allDetailTableData, [
            { data: 'Channel' },
            { data: 'Campaign Name' },
            { data: 'Keywords' },
            { data: 'Quality Score' },
        ], false, false);

        // Keywords table
        $("#campaignSelect").change(function () {
            var selectedTime = $("#campaignSelect option:selected").val();
            console.log(selectedTime);
            if (selectedTime == "Channel") {
                $("#hideCampaignChannel").show();
                campaignTable.column(1).visible(true);
            } else if (selectedTime == "Keywords") {
                $("#hideCampaignKeyword").show();
                campaignTable.column(2).visible(true);
            } else {
                $("#hideCampaignChannel").hide();
                $("#hideCampaignKeyword").hide();
                campaignTable.column(1).visible(false);
                campaignTable.column(2).visible(false);
            }
        });
        $('#hideCampaignChannel').click(function () {
            $('#hideCampaignChannel').hide();
            campaignTable.column(1).visible(false);
        });
        $('#hideCampaignKeyword').click(function () {
            $('#hideCampaignKeyword').hide();
            campaignTable.column(2).visible(false);
        });
    }

    //campaign last month changes
    function campaignsLastMonthChanges() {
        //top row
        //add data in text()
        $('#clicks').text('');
        $('#clicksPercent').text('').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#ctr').text('');
        $('#ctrPercent').text('').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');
        $('#cpc').text('');
        $('#cpcPercent').text('').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#impressions').text('');
        $('#impressionsPercent').text('').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');

        // Devices horizontal graph
        //change dataDesktops, dataMobiles and dataTablets for timeline
        var dataDesktops = [2000, 2345, 1345];
        var dataTablets = [1234, 1000, 786];
        var dataMobiles = [978, 345, 234];
        createGraph('horizontalBar', 'deviceGraph', {
            labels: ["Clicks", "CTR", "CPC"],
            datasets: [{
                data: dataDesktops,
                backgroundColor: "rgb(144,135,192)"
            },
            {
                data: dataTablets,
                backgroundColor: "rgb(150,209,243)"
            },
            {
                data: dataMobiles,
                backgroundColor: "rgb(244,137,167)"
            }
            ]
        }, {
                tooltips: {
                    enabled: true
                },
                scales: {
                    xAxes: [{
                        ticks: {
                            beginAtZero: true,
                            fontFamily: "'Open Sans Bold', sans-serif",
                            fontSize: 11
                        },
                        scaleLabel: {
                            display: false
                        },
                        gridLines: {
                        },
                        stacked: true
                    }],
                    yAxes: [{
                        gridLines: {
                            display: false,
                            color: "#fff",
                            zeroLineColor: "#fff",
                            zeroLineWidth: 0
                        },
                        ticks: {
                            fontFamily: "'Open Sans Bold', sans-serif",
                            fontSize: 11
                        },
                        stacked: true
                    }]
                },
                legend: {
                    display: false
                }
            });

        // clicks/CTR line graph
        //change clicksData and ctrData for timeline
        var clicksData = [{
            x: 10,
            y: 100
        }, {
            x: 20,
            y: 11
        }, {
            x: 23,
            y: 12
        }, {
            x: 27,
            y: 9
        }, {
            x: 28,
            y: 16
        }, {
            x: 29,
            y: 19
        }, {
            x: 30,
            y: 25
        }, {
            x: 31,
            y: 36
        }, {
            x: 32,
            y: 34
        }, {
            x: 33,
            y: 18
        }, {
            x: 34,
            y: 25
        }, {
            x: 35,
            y: 12
        }
        ]
        var ctrData = [{
            x: 10,
            y: 11
        }, {
            x: 20,
            y: 12
        }, {
            x: 23,
            y: 13
        }, {
            x: 27,
            y: 15
        }, {
            x: 28,
            y: 17
        }, {
            x: 29,
            y: 5
        }, {
            x: 30,
            y: 27
        }, {
            x: 31,
            y: 24
        }, {
            x: 32,
            y: 32
        }, {
            x: 33,
            y: 12
        }, {
            x: 34,
            y: 7
        }, {
            x: 35,
            y: 16
        }
        ]
        createGraph('line', 'clicksGraph', {
            labels: lastMonthLabels,
            datasets: [
                {
                    label: "Clicks",
                    backgroundColor: "rgb(144,135,192)",
                    borderColor: "rgb(144,135,192)",
                    fill: false,
                    data: clicksData
                }, {
                    label: "CTR",
                    backgroundColor: "rgb(150,209,243)",
                    borderColor: "rgb(150,209,243)",
                    fill: false,
                    data: ctrData
                }
            ]
        }, {
                elements: {
                    line: {
                        tension: 0, // disables bezier curves
                    }
                }
            });

        //ctr/cpc line graph
        //change ctrLineData and cpcData for timeline
        var ctrLineData = [{
            x: 10,
            y: 11
        }, {
            x: 20,
            y: 12
        }, {
            x: 23,
            y: 13
        }, {
            x: 27,
            y: 15
        }, {
            x: 28,
            y: 17
        }, {
            x: 29,
            y: 5
        }, {
            x: 30,
            y: 27
        }, {
            x: 31,
            y: 24
        }, {
            x: 32,
            y: 32
        }, {
            x: 33,
            y: 12
        }, {
            x: 34,
            y: 7
        }, {
            x: 35,
            y: 16
        }
        ]
        var cpcData = [{
            x: 10,
            y: 25
        }, {
            x: 20,
            y: 16
        }, {
            x: 23,
            y: 9
        }, {
            x: 27,
            y: 36
        }, {
            x: 28,
            y: 49
        }, {
            x: 29,
            y: 25
        }, {
            x: 30,
            y: 54
        }, {
            x: 31,
            y: 36
        }, {
            x: 32,
            y: 12
        }, {
            x: 33,
            y: 24
        }, {
            x: 34,
            y: 28
        }, {
            x: 35,
            y: 35
        }
        ]
        createGraph('line', 'cpcGraph', {
            labels: lastMonthLabels,
            datasets: [
                {
                    label: "CTR",
                    backgroundColor: "rgb(150,209,243)",
                    borderColor: "rgb(150,209,243)",
                    fill: false,
                    data: ctrLineData
                }, {
                    label: "CPC",
                    backgroundColor: "rgb(244,137,167)",
                    borderColor: "rgb(244,137,167)",
                    fill: false,
                    data: cpcData
                }

            ]
        }, {
                elements: {
                    line: {
                        tension: 0, // disables bezier curves
                    }
                }
            });

        //impressions data
        //add data in text()
        //$('#impressionDataCampaign').text('');
        $('#costDataCampaign').text('');
        $('#conversionDataCampaign').text('');
        $('#costPerConversionDataCampaign').text('');

        //$('#impressionData').text('');
        $('#costData').text('');
        $('#conversionData').text('');
        $('#costPerConversionData').text('');

        // Donut for clicks
        //change clickLabels and clickData for timeline
        var clickLabels = ["Adwords", "facebook", "Twitter", "Bing"];
        var clickData = [300, 200, 50, 60];
        createGraph('doughnut', "clickDonut", {
            labels: clickLabels,
            datasets: [{
                data: clickData,
                backgroundColor: ["#9087C0", "#96D1F3", "#F489A7", "#C5E5D6"]
            }]
        }, {
                legend: {
                    position: 'right'
                }
            });

        // Donut for costs
        //change costLabels and costData for timeline
        var costLabels = ["Adwords", "facebook", "Twitter", "Bing"];
        var costData = [170, 200, 20, 60];
        createGraph('doughnut', "costDonut", {
            labels: costLabels,
            datasets: [{
                data: costData,
                backgroundColor: ["#9087C0", "#96D1F3", "#F489A7", "#C5E5D6"]
            }]
        }, {
                legend: {
                    position: 'right'
                }
            });

        // Donut for conversion 
        //change conversionLabels and conversionData for timeline
        var conversionLabels = ["Adwords", "facebook", "Twitter", "Bing"];
        var conversionData = [400, 80, 60, 100];
        createGraph('doughnut', "conversionDonut", {
            labels: conversionLabels,
            datasets: [{
                data: conversionData,
                backgroundColor: ["#9087C0", "#96D1F3", "#F489A7", "#C5E5D6"]
            }]
        }, {
                legend: {
                    position: 'right'
                }
            });

        //campaign table
        //change campaignData for timeline
        var campaignData = [
            {
                "Campaign Name": "C1_Adwords",
                "Channel": "Adwords",
                "Keywords": "Phone",
                "Impression": "94,268,798",
                "Clicks": "4,12,000",
                "CTR": "$2,46,871",
                "Conversions": "64,500",
                "New Customers": "273,200",
                "Spend": "$382",
                "CPC": "$55",
                "CPA": "-85.26%"
            }, {
                "Campaign Name": "C2_Adwords",
                "Channel": "Adwords",
                "Keywords": "Laptops",
                "Impression": "4,268,798",
                "Clicks": "1,09,273",
                "CTR": "$46,871",
                "Conversions": "4,500",
                "New Customers": "23,210",
                "Spend": "$266",
                "CPC": "$52",
                "CPA": "-80.62%"
            }, {
                "Campaign Name": "C2_fb",
                "Channel": "facebook",
                "Keywords": "Tablets",
                "Impression": "702,268,798",
                "Clicks": "4,08,145",
                "CTR": "$1,36,812",
                "Conversions": "172,231",
                "New Customers": "360,221",
                "Spend": "$789",
                "CPC": "$36",
                "CPA": "-74.81%"
            }
        ]

        var campaignTable = createDataTable($('#campaignDetailsTable'), campaignData, [
            { data: 'Campaign Name' },
            { data: 'Channel', visible: false },
            { data: 'Keywords', visible: false },
            { data: 'Impression' },
            { data: 'Clicks' },
            { data: 'CTR' },
            { data: 'Conversions' },
            { data: 'New Customers' },
            { data: 'Spend' },
            { data: 'CPC' },
            { data: 'CPA' }
        ], true, true);

        //platform details table
        //change platformDetailData for timeline
        var platformDetailData = [
            {
                "Platform": "Adwords",
                "Clicks": "94,815",
                "Impressions": "194,268,798",
                "CTR": "0.59%",
                "CPC": "$1.70",
                "Cost": "161,002",
                "Conversions": "2,663",
                "Conversion rate": "2.81%",
                "Cost per Conversion": "$60.44"
            }, {
                "Platform": "Facebook",
                "Clicks": "65,129",
                "Impressions": "11,126,828",
                "CTR": "0.55%",
                "CPC": "$1.21",
                "Cost": "78,702",
                "Conversions": "1,772",
                "Conversion rate": "2.72%",
                "Cost per Conversion": "$44.50"
            }, {
                "Platform": "Twitter",
                "Clicks": "52,743",
                "Impressions": "31,653,102",
                "CTR": "0.17%",
                "CPC": "$1.44",
                "Cost": "75,678",
                "Conversions": "1,223",
                "Conversion rate": "2.34%",
                "Cost per Conversion": "$61.58"
            }, {
                "Platform": "Bing",
                "Clicks": "35,285",
                "Impressions": "6,712,342",
                "CTR": "0.53%",
                "CPC": "$1.98",
                "Cost": "16,211",
                "Conversions": "1,075",
                "Conversion rate": "3.05%",
                "Cost per Conversion": "$61.78"
            }
        ]
        createDataTable($('#platformDetailsTable'), platformDetailData, [
            { data: 'Platform' },
            { data: 'Clicks' },
            { data: 'Impressions' },
            { data: 'CTR' },
            { data: 'CPC' },
            { data: 'Cost' },
            { data: 'Conversions' },
            { data: 'Conversion rate' },
            { data: 'Cost per Conversion' }
        ], true, true);

        //top five keywords table
        //change topFiveKeywordData for timeline
        var topFiveKeywordData = [
            {
                "Channel": "Adwords",
                "Campaign Name": "C1_Adwords",
                "Keywords": "iPhone 6s",
                "Quality Score": "4.2",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "C2_Adwords",
                "Keywords": "One Plus 6T",
                "Quality Score": "4.1",
            }, {
                "Channel": "Facebook",
                "Campaign Name": "C1_fb",
                "Keywords": "Mi A1",
                "Quality Score": "3.9",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "C3_Adwords",
                "Keywords": "iPhone 6s",
                "Quality Score": "3.8",
            }
        ]
        createDataTable($('#topFiveDetailsTable'), topFiveKeywordData, [
            { data: 'Channel' },
            { data: 'Campaign Name' },
            { data: 'Keywords' },
            { data: 'Quality Score' },
        ], false, false);

        //bottom five keywords table
        //change bottomFiveKeywordData for timeline
        var bottomFiveKeywordData = [
            {
                "Channel": "Adwords",
                "Campaign Name": "Cn_Adwords",
                "Keywords": "Earphones",
                "Quality Score": "1.0",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Cn_Adwords",
                "Keywords": "Air Pods",
                "Quality Score": "0.89",
            }, {
                "Channel": "Facebook",
                "Campaign Name": "C2_fb",
                "Keywords": "Wireless Charger",
                "Quality Score": "0.82",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Cn_Adwords",
                "Keywords": "Charger",
                "Quality Score": "0.67",
            }
        ]
        createDataTable($('#bottomFiveDetailsTable'), bottomFiveKeywordData, [
            { data: 'Channel' },
            { data: 'Campaign Name' },
            { data: 'Keywords' },
            { data: 'Quality Score' },
        ], false, false);

        //all details table
        //change allDetailTableData for timeline
        var allDetailTableData = [
            {
                "Channel": "Adwords",
                "Campaign Name": "Cn_Adwords",
                "Keywords": "Earphones",
                "Quality Score": "1.0",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Cn_Adwords",
                "Keywords": "Air Pods",
                "Quality Score": "0.89",
            }, {
                "Channel": "Facebook",
                "Campaign Name": "C2_fb",
                "Keywords": "Wireless Charger",
                "Quality Score": "0.82",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Cn_Adwords",
                "Keywords": "Charger",
                "Quality Score": "0.67",
            }
        ]
        createDataTable($('#allDetailsTable'), allDetailTableData, [
            { data: 'Channel' },
            { data: 'Campaign Name' },
            { data: 'Keywords' },
            { data: 'Quality Score' },
        ], false, false);

        // Keywords table
        $("#campaignSelect").change(function () {
            var selectedTime = $("#campaignSelect option:selected").val();
            console.log(selectedTime);
            if (selectedTime == "Channel") {
                $("#hideCampaignChannel").show();
                campaignTable.column(1).visible(true);
            } else if (selectedTime == "Keywords") {
                $("#hideCampaignKeyword").show();
                campaignTable.column(2).visible(true);
            } else {
                $("#hideCampaignChannel").hide();
                $("#hideCampaignKeyword").hide();
                campaignTable.column(1).visible(false);
                campaignTable.column(2).visible(false);
            }
        });
        $('#hideCampaignChannel').click(function () {
            $('#hideCampaignChannel').hide();
            campaignTable.column(1).visible(false);
        });
        $('#hideCampaignKeyword').click(function () {
            $('#hideCampaignKeyword').hide();
            campaignTable.column(2).visible(false);
        });
    }

    //campaign last six months changes
    function campaignsLastSixMonthChanges() {
        //top row
        //add data in text()
        $('#clicks').text('');
        $('#clicksPercent').text('').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#ctr').text('');
        $('#ctrPercent').text('').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');
        $('#cpc').text('');
        $('#cpcPercent').text('').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#impressions').text('');
        $('#impressionsPercent').text('').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');

        // Devices horizontal graph
        //change dataDesktops, dataMobiles and dataTablets for timeline
        var dataDesktops = [2000, 2345, 1345];
        var dataTablets = [1234, 1000, 786];
        var dataMobiles = [978, 345, 234];
        createGraph('horizontalBar', 'deviceGraph', {
            labels: ["Clicks", "CTR", "CPC"],
            datasets: [{
                data: dataDesktops,
                backgroundColor: "rgb(144,135,192)"
            },
            {
                data: dataTablets,
                backgroundColor: "rgb(150,209,243)"
            },
            {
                data: dataMobiles,
                backgroundColor: "rgb(244,137,167)"
            }
            ]
        }, {
                tooltips: {
                    enabled: true
                },
                scales: {
                    xAxes: [{
                        ticks: {
                            beginAtZero: true,
                            fontFamily: "'Open Sans Bold', sans-serif",
                            fontSize: 11
                        },
                        scaleLabel: {
                            display: false
                        },
                        gridLines: {
                        },
                        stacked: true
                    }],
                    yAxes: [{
                        gridLines: {
                            display: false,
                            color: "#fff",
                            zeroLineColor: "#fff",
                            zeroLineWidth: 0
                        },
                        ticks: {
                            fontFamily: "'Open Sans Bold', sans-serif",
                            fontSize: 11
                        },
                        stacked: true
                    }]
                },
                legend: {
                    display: false
                }
            });

        // clicks/CTR line graph
        //change clicksData and ctrData for timeline
        var clicksData = [{
            x: 10,
            y: 100
        }, {
            x: 20,
            y: 11
        }, {
            x: 23,
            y: 12
        }, {
            x: 27,
            y: 9
        }, {
            x: 28,
            y: 16
        }, {
            x: 29,
            y: 19
        }, {
            x: 30,
            y: 25
        }, {
            x: 31,
            y: 36
        }, {
            x: 32,
            y: 34
        }, {
            x: 33,
            y: 18
        }, {
            x: 34,
            y: 25
        }, {
            x: 35,
            y: 12
        }
        ]
        var ctrData = [{
            x: 10,
            y: 11
        }, {
            x: 20,
            y: 12
        }, {
            x: 23,
            y: 13
        }, {
            x: 27,
            y: 15
        }, {
            x: 28,
            y: 17
        }, {
            x: 29,
            y: 5
        }, {
            x: 30,
            y: 27
        }, {
            x: 31,
            y: 24
        }, {
            x: 32,
            y: 32
        }, {
            x: 33,
            y: 12
        }, {
            x: 34,
            y: 7
        }, {
            x: 35,
            y: 16
        }
        ]
        createGraph('line', 'clicksGraph', {
            labels: lastSixMonthLabels,
            datasets: [
                {
                    label: "Clicks",
                    backgroundColor: "rgb(144,135,192)",
                    borderColor: "rgb(144,135,192)",
                    fill: false,
                    data: clicksData
                }, {
                    label: "CTR",
                    backgroundColor: "rgb(150,209,243)",
                    borderColor: "rgb(150,209,243)",
                    fill: false,
                    data: ctrData
                }
            ]
        }, {
                elements: {
                    line: {
                        tension: 0, // disables bezier curves
                    }
                }
            });

        //ctr/cpc line graph
        //change ctrLineData and cpcData for timeline
        var ctrLineData = [{
            x: 10,
            y: 11
        }, {
            x: 20,
            y: 12
        }, {
            x: 23,
            y: 13
        }, {
            x: 27,
            y: 15
        }, {
            x: 28,
            y: 17
        }, {
            x: 29,
            y: 5
        }, {
            x: 30,
            y: 27
        }, {
            x: 31,
            y: 24
        }, {
            x: 32,
            y: 32
        }, {
            x: 33,
            y: 12
        }, {
            x: 34,
            y: 7
        }, {
            x: 35,
            y: 16
        }
        ]
        var cpcData = [{
            x: 10,
            y: 25
        }, {
            x: 20,
            y: 16
        }, {
            x: 23,
            y: 9
        }, {
            x: 27,
            y: 36
        }, {
            x: 28,
            y: 49
        }, {
            x: 29,
            y: 25
        }, {
            x: 30,
            y: 54
        }, {
            x: 31,
            y: 36
        }, {
            x: 32,
            y: 12
        }, {
            x: 33,
            y: 24
        }, {
            x: 34,
            y: 28
        }, {
            x: 35,
            y: 35
        }
        ]
        createGraph('line', 'cpcGraph', {
            labels: lastSixMonthLabels,
            datasets: [
                {
                    label: "CTR",
                    backgroundColor: "rgb(150,209,243)",
                    borderColor: "rgb(150,209,243)",
                    fill: false,
                    data: ctrLineData
                }, {
                    label: "CPC",
                    backgroundColor: "rgb(244,137,167)",
                    borderColor: "rgb(244,137,167)",
                    fill: false,
                    data: cpcData
                }

            ]
        }, {
                elements: {
                    line: {
                        tension: 0, // disables bezier curves
                    }
                }
            });

        //impressions data
        //add data in text()
        //$('#impressionDataCampaign').text('');
        $('#costDataCampaign').text('');
        $('#conversionDataCampaign').text('');
        $('#costPerConversionDataCampaign').text('');

        //$('#impressionData').text('');
        $('#costData').text('');
        $('#conversionData').text('');
        $('#costPerConversionData').text('');

        // Donut for clicks
        //change clickLabels and clickData for timeline
        var clickLabels = ["Adwords", "facebook", "Twitter", "Bing"];
        var clickData = [300, 200, 50, 60];
        createGraph('doughnut', "clickDonut", {
            labels: clickLabels,
            datasets: [{
                data: clickData,
                backgroundColor: ["#9087C0", "#96D1F3", "#F489A7", "#C5E5D6"]
            }]
        }, {
                legend: {
                    position: 'right'
                }
            });

        // Donut for costs
        //change costLabels and costData for timeline
        var costLabels = ["Adwords", "facebook", "Twitter", "Bing"];
        var costData = [170, 200, 20, 60];
        createGraph('doughnut', "costDonut", {
            labels: costLabels,
            datasets: [{
                data: costData,
                backgroundColor: ["#9087C0", "#96D1F3", "#F489A7", "#C5E5D6"]
            }]
        }, {
                legend: {
                    position: 'right'
                }
            });

        // Donut for conversion 
        //change conversionLabels and conversionData for timeline
        var conversionLabels = ["Adwords", "facebook", "Twitter", "Bing"];
        var conversionData = [400, 80, 60, 100];
        createGraph('doughnut', "conversionDonut", {
            labels: conversionLabels,
            datasets: [{
                data: conversionData,
                backgroundColor: ["#9087C0", "#96D1F3", "#F489A7", "#C5E5D6"]
            }]
        }, {
                legend: {
                    position: 'right'
                }
            });

        //campaign table
        //change campaignData for timeline
        var campaignData = [
            {
                "Campaign Name": "C1_Adwords",
                "Channel": "Adwords",
                "Keywords": "Phone",
                "Impression": "94,268,798",
                "Clicks": "4,12,000",
                "CTR": "$2,46,871",
                "Conversions": "64,500",
                "New Customers": "273,200",
                "Spend": "$382",
                "CPC": "$55",
                "CPA": "-85.26%"
            }, {
                "Campaign Name": "C2_Adwords",
                "Channel": "Adwords",
                "Keywords": "Laptops",
                "Impression": "4,268,798",
                "Clicks": "1,09,273",
                "CTR": "$46,871",
                "Conversions": "4,500",
                "New Customers": "23,210",
                "Spend": "$266",
                "CPC": "$52",
                "CPA": "-80.62%"
            }, {
                "Campaign Name": "C2_fb",
                "Channel": "facebook",
                "Keywords": "Tablets",
                "Impression": "702,268,798",
                "Clicks": "4,08,145",
                "CTR": "$1,36,812",
                "Conversions": "172,231",
                "New Customers": "360,221",
                "Spend": "$789",
                "CPC": "$36",
                "CPA": "-74.81%"
            }
        ]

        var campaignTable = createDataTable($('#campaignDetailsTable'), campaignData, [
            { data: 'Campaign Name' },
            { data: 'Channel', visible: false },
            { data: 'Keywords', visible: false },
            { data: 'Impression' },
            { data: 'Clicks' },
            { data: 'CTR' },
            { data: 'Conversions' },
            { data: 'New Customers' },
            { data: 'Spend' },
            { data: 'CPC' },
            { data: 'CPA' }
        ], true, true);

        //platform details table
        //change platformDetailData for timeline
        var platformDetailData = [
            {
                "Platform": "Adwords",
                "Clicks": "94,815",
                "Impressions": "194,268,798",
                "CTR": "0.59%",
                "CPC": "$1.70",
                "Cost": "161,002",
                "Conversions": "2,663",
                "Conversion rate": "2.81%",
                "Cost per Conversion": "$60.44"
            }, {
                "Platform": "Facebook",
                "Clicks": "65,129",
                "Impressions": "11,126,828",
                "CTR": "0.55%",
                "CPC": "$1.21",
                "Cost": "78,702",
                "Conversions": "1,772",
                "Conversion rate": "2.72%",
                "Cost per Conversion": "$44.50"
            }, {
                "Platform": "Twitter",
                "Clicks": "52,743",
                "Impressions": "31,653,102",
                "CTR": "0.17%",
                "CPC": "$1.44",
                "Cost": "75,678",
                "Conversions": "1,223",
                "Conversion rate": "2.34%",
                "Cost per Conversion": "$61.58"
            }, {
                "Platform": "Bing",
                "Clicks": "35,285",
                "Impressions": "6,712,342",
                "CTR": "0.53%",
                "CPC": "$1.98",
                "Cost": "16,211",
                "Conversions": "1,075",
                "Conversion rate": "3.05%",
                "Cost per Conversion": "$61.78"
            }
        ]
        createDataTable($('#platformDetailsTable'), platformDetailData, [
            { data: 'Platform' },
            { data: 'Clicks' },
            { data: 'Impressions' },
            { data: 'CTR' },
            { data: 'CPC' },
            { data: 'Cost' },
            { data: 'Conversions' },
            { data: 'Conversion rate' },
            { data: 'Cost per Conversion' }
        ], true, true);

        //top five keywords table
        //change topFiveKeywordData for timeline
        var topFiveKeywordData = [
            {
                "Channel": "Adwords",
                "Campaign Name": "C1_Adwords",
                "Keywords": "iPhone 6s",
                "Quality Score": "4.2",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "C2_Adwords",
                "Keywords": "One Plus 6T",
                "Quality Score": "4.1",
            }, {
                "Channel": "Facebook",
                "Campaign Name": "C1_fb",
                "Keywords": "Mi A1",
                "Quality Score": "3.9",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "C3_Adwords",
                "Keywords": "iPhone 6s",
                "Quality Score": "3.8",
            }
        ]
        createDataTable($('#topFiveDetailsTable'), topFiveKeywordData, [
            { data: 'Channel' },
            { data: 'Campaign Name' },
            { data: 'Keywords' },
            { data: 'Quality Score' },
        ], false, false);

        //bottom five keywords table
        //change bottomFiveKeywordData for timeline
        var bottomFiveKeywordData = [
            {
                "Channel": "Adwords",
                "Campaign Name": "Cn_Adwords",
                "Keywords": "Earphones",
                "Quality Score": "1.0",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Cn_Adwords",
                "Keywords": "Air Pods",
                "Quality Score": "0.89",
            }, {
                "Channel": "Facebook",
                "Campaign Name": "C2_fb",
                "Keywords": "Wireless Charger",
                "Quality Score": "0.82",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Cn_Adwords",
                "Keywords": "Charger",
                "Quality Score": "0.67",
            }
        ]
        createDataTable($('#bottomFiveDetailsTable'), bottomFiveKeywordData, [
            { data: 'Channel' },
            { data: 'Campaign Name' },
            { data: 'Keywords' },
            { data: 'Quality Score' },
        ], false, false);

        //all details table
        //change allDetailTableData for timeline
        var allDetailTableData = [
            {
                "Channel": "Adwords",
                "Campaign Name": "Cn_Adwords",
                "Keywords": "Earphones",
                "Quality Score": "1.0",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Cn_Adwords",
                "Keywords": "Air Pods",
                "Quality Score": "0.89",
            }, {
                "Channel": "Facebook",
                "Campaign Name": "C2_fb",
                "Keywords": "Wireless Charger",
                "Quality Score": "0.82",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Cn_Adwords",
                "Keywords": "Charger",
                "Quality Score": "0.67",
            }
        ]
        createDataTable($('#allDetailsTable'), allDetailTableData, [
            { data: 'Channel' },
            { data: 'Campaign Name' },
            { data: 'Keywords' },
            { data: 'Quality Score' },
        ], false, false);

        // Keywords table
        $("#campaignSelect").change(function () {
            var selectedTime = $("#campaignSelect option:selected").val();
            console.log(selectedTime);
            if (selectedTime == "Channel") {
                $("#hideCampaignChannel").show();
                campaignTable.column(1).visible(true);
            } else if (selectedTime == "Keywords") {
                $("#hideCampaignKeyword").show();
                campaignTable.column(2).visible(true);
            } else {
                $("#hideCampaignChannel").hide();
                $("#hideCampaignKeyword").hide();
                campaignTable.column(1).visible(false);
                campaignTable.column(2).visible(false);
            }
        });
        $('#hideCampaignChannel').click(function () {
            $('#hideCampaignChannel').hide();
            campaignTable.column(1).visible(false);
        });
        $('#hideCampaignKeyword').click(function () {
            $('#hideCampaignKeyword').hide();
            campaignTable.column(2).visible(false);
        });
    }

    //campaign this year changes
    function campaignsYearChanges() {
        //top row
        //add data in text()
        $('#clicks').text('200,000');
        $('#clicksPercent').text('3.33%').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#ctr').text('3.3%');
        $('#ctrPercent').text('0.25%').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#cpc').text('$1.28');
        $('#cpcPercent').text('0.25%').append('<i class="up-trend-icon fa fa-arrow-up trend-icons"></i>');
        $('#impressions').text('6,530,000');
        $('#impressionsPercent').text('0.25%').append('<i class="down-trend-icon fa fa-arrow-down trend-icons"></i>');

        // Devices horizontal graph
        //change dataDesktops, dataMobiles and dataTablets for timeline
        var dataDesktops = [63000, 23450, 13450];
        var dataTablets = [58500, 10000, 7860];
        var dataMobiles = [67500, 3450, 2340];
        createGraph('horizontalBar', 'deviceGraph', {
            labels: ["Clicks", "CTR", "CPC"],
            datasets: [{
                data: dataDesktops,
                backgroundColor: "rgb(144,135,192)"
            },
            {
                data: dataTablets,
                backgroundColor: "rgb(150,209,243)"
            },
            {
                data: dataMobiles,
                backgroundColor: "rgb(244,137,167)"
            }
            ]
        }, {
                tooltips: {
                    enabled: true
                },
                scales: {
                    xAxes: [{
                        ticks: {
                            beginAtZero: true,
                            fontFamily: "'Open Sans Bold', sans-serif",
                            fontSize: 11
                        },
                        scaleLabel: {
                            display: false
                        },
                        gridLines: {
                        },
                        stacked: true
                    }],
                    yAxes: [{
                        gridLines: {
                            display: false,
                            color: "#fff",
                            zeroLineColor: "#fff",
                            zeroLineWidth: 0
                        },
                        ticks: {
                            fontFamily: "'Open Sans Bold', sans-serif",
                            fontSize: 11
                        },
                        stacked: true
                    }]
                },
                legend: {
                    display: false
                }
            });

        // clicks/CTR line graph
        //change clicksData and ctrData for timeline
        var clicksData = [{
            x: 10,
            y: 100
        }, {
            x: 20,
            y: 11
        }, {
            x: 23,
            y: 12
        }, {
            x: 27,
            y: 9
        }, {
            x: 28,
            y: 16
        }, {
            x: 29,
            y: 19
        }, {
            x: 30,
            y: 25
        }, {
            x: 31,
            y: 36
        }, {
            x: 32,
            y: 34
        }, {
            x: 33,
            y: 18
        }, {
            x: 34,
            y: 25
        }, {
            x: 35,
            y: 12
        }
        ]
        var ctrData = [{
            x: 10,
            y: 11
        }, {
            x: 20,
            y: 12
        }, {
            x: 23,
            y: 13
        }, {
            x: 27,
            y: 15
        }, {
            x: 28,
            y: 17
        }, {
            x: 29,
            y: 5
        }, {
            x: 30,
            y: 27
        }, {
            x: 31,
            y: 24
        }, {
            x: 32,
            y: 32
        }, {
            x: 33,
            y: 12
        }, {
            x: 34,
            y: 7
        }, {
            x: 35,
            y: 16
        }
        ]
        createGraph('line', 'clicksGraph', {
            labels: thisYearLabels,
            datasets: [
                {
                    label: "Clicks",
                    backgroundColor: "rgb(144,135,192)",
                    borderColor: "rgb(144,135,192)",
                    fill: false,
                    data: clicksData
                }, {
                    label: "CTR",
                    backgroundColor: "rgb(150,209,243)",
                    borderColor: "rgb(150,209,243)",
                    fill: false,
                    data: ctrData
                }
            ]
        }, {
                elements: {
                    line: {
                        tension: 0, // disables bezier curves
                    }
                }
            });

        //ctr/cpc line graph
        //change ctrLineData and cpcData for timeline
        var ctrLineData = [{
            x: 10,
            y: 11
        }, {
            x: 20,
            y: 12
        }, {
            x: 23,
            y: 13
        }, {
            x: 27,
            y: 15
        }, {
            x: 28,
            y: 17
        }, {
            x: 29,
            y: 5
        }, {
            x: 30,
            y: 27
        }, {
            x: 31,
            y: 24
        }, {
            x: 32,
            y: 32
        }, {
            x: 33,
            y: 12
        }, {
            x: 34,
            y: 7
        }, {
            x: 35,
            y: 16
        }
        ]
        var cpcData = [{
            x: 10,
            y: 25
        }, {
            x: 20,
            y: 16
        }, {
            x: 23,
            y: 9
        }, {
            x: 27,
            y: 36
        }, {
            x: 28,
            y: 49
        }, {
            x: 29,
            y: 25
        }, {
            x: 30,
            y: 54
        }, {
            x: 31,
            y: 36
        }, {
            x: 32,
            y: 12
        }, {
            x: 33,
            y: 24
        }, {
            x: 34,
            y: 28
        }, {
            x: 35,
            y: 35
        }
        ]
        createGraph('line', 'cpcGraph', {
            labels: thisYearLabels,
            datasets: [
                {
                    label: "CTR",
                    backgroundColor: "rgb(150,209,243)",
                    borderColor: "rgb(150,209,243)",
                    fill: false,
                    data: ctrLineData
                }, {
                    label: "CPC",
                    backgroundColor: "rgb(244,137,167)",
                    borderColor: "rgb(244,137,167)",
                    fill: false,
                    data: cpcData
                }

            ]
        }, {
                elements: {
                    line: {
                        tension: 0, // disables bezier curves
                    }
                }
            });

        //impressions data
        //add data in text()
        // $('#impressionDataCampaign').text('');
        $('#costDataCampaign').text('$215,600');
        $('#conversionDataCampaign').text('6,488');
        $('#costPerConversionDataCampaign').text('$33');

        //$('#impressionData').text('');
        $('#costData').text('$215,600');
        $('#conversionData').text('6,488');
        $('#costPerConversionData').text('$33');

        // Donut for clicks
        //change clickLabels and clickData for timeline
        var clickLabels = ["Adwords", "Facebook", "Instagram"];
        var clickData = [300, 200, 100];
        createGraph('doughnut', "clickDonut", {
            labels: clickLabels,
            datasets: [{
                data: clickData,
                backgroundColor: ["#9087C0", "#96D1F3", "#F489A7", "#C5E5D6"]
            }]
        }, {
                legend: {
                    position: 'bottom',
                    onClick: null
                }
            });

        // Donut for costs
        //change costLabels and costData for timeline
        var costLabels = ["Adwords", "Facebook", "Instagram"];
        var costData = [170, 200, 250];
        createGraph('doughnut', "costDonut", {
            labels: costLabels,
            datasets: [{
                data: costData,
                backgroundColor: ["#9087C0", "#96D1F3", "#F489A7", "#C5E5D6"]
            }]
        }, {
                legend: {
                    position: 'bottom',
                    onClick: null
                }
            });

        // Donut for conversion 
        //change conversionLabels and conversionData for timeline
        var conversionLabels = ["Adwords", "Facebook", "Instagram"];
        var conversionData = [400, 80, 100];
        createGraph('doughnut', "conversionDonut", {
            labels: conversionLabels,
            datasets: [{
                data: conversionData,
                backgroundColor: ["#9087C0", "#96D1F3", "#F489A7", "#C5E5D6"]
            }]
        }, {
                legend: {
                    position: 'bottom',
                    onClick: null
                }
            });

        //keyword statistics table
        //change keywordData for timeline
        var keywordData = [
            {
                "CampaignName": "Google Adwords Electronics",
                "Status": "Enabled",
                "Keywords": "usb drive",
                "Impression": "1,012,698",
                "Clicks": "28,050",
                "CTR": "0.03",
                "Conversions": "2,658",
                "Spend": "$66,800",
                "CPC": "$2.38",
                "Cost / Conversion": "$25",
                "Quality Score": "8"
            }, {
                "CampaignName": "Google Adwords Home",
                "Status": "Enabled",
                "Keywords": "google clock",
                "Impression": "407,106",
                "Clicks": "14,025",
                "CTR": "0.03",
                "Conversions": "1,980",
                "Spend": "$67,500",
                "CPC": "$4.81",
                "Cost / Conversion": "$34",
                "Quality Score": "6"
            }, {
                "CampaignName": "Facebook Gadgets",
                "Status": "Enabled",
                "Keywords": "facebook variables clothing",
                "Impression": "547,560",
                "Clicks": "9,075",
                "CTR": "0.02",
                "Conversions": "1,200",
                "Spend": "$75,000",
                "CPC": "$8.26",
                "Cost / Conversion": "$63",
                "Quality Score": "7"
            }
        ]


        var campaignTable = createDataTable($('#campaignDetailsKeywordAndChannelTable'),keywordData,[
            { data : 'CampaignName' },   
            { data : 'Status'},
            { data : 'Keywords'},
            { data : 'Impression' },
            { data : 'Clicks' },
            { data : 'CTR' },
            { data : 'Conversions'},
            { data : 'Spend' },
            { data : 'CPC' },
            { data : 'Cost / Conversion' },
            { data : 'Quality Score'}
        ],true,true);

        //ad statistics table
        //change adData for timeline
        var adData = [
            {
                "CampaignName": "Google Adwords Electronics",
                "Channel": "GoogleAds",
                "AdGroup": "Buy Electronics",
                "Ad": "All Electric",
                "Impression": "506,349",
                "Clicks": "14,025",
                "CTR": "0.03",
                "Conversions": "1,329",
                "Spend": "$33,400",
                "CPC": "$1.19",
                "Cost / Conversion": "$25"
            }, {
                "CampaignName": "Google Adwords Home",
                "Channel": "GoogleAds",
                "AdGroup": "Home Stats",
                "Ad": "Google Home",
                "Impression": "203,553",
                "Clicks": "7,012",
                "CTR": "0.03",
                "Conversions": "990",
                "Spend": "$33,750",
                "CPC": "$2.40",
                "Cost / Conversion": "$34"
            }, {
                "CampaignName": "Facebook Gadgets",
                "Channel": "FacebookAds",
                "AdGroup": "Gadgets",
                "Ad": "All Gadgets",
                "Impression": "273,780",
                "Clicks": "4,537",
                "CTR": "0.02",
                "Conversions": "600",
                "Spend": "$37,500",
                "CPC": "$4.13",
                "Cost / Conversion": "$63"
            }
        ]


        var adTable = createDataTable($('#adDetailsTable'),adData,[
            { data : 'CampaignName' },   
            { data : 'Channel'},
            { data : 'AdGroup'},
            { data : 'Ad'},
            { data : 'Impression' },
            { data : 'Clicks' },
            { data : 'CTR' },
            { data : 'Conversions'},
            { data : 'Spend' },
            { data : 'CPC' },
            { data : 'Cost / Conversion' }
        ],true,true);

        //platform details table
        //change platformDetailData for timeline
        var platformDetailData = [
            {
                "Platform": "Adwords",
                "Clicks": "42,075",
                "Impressions": "1,419,804",
                "CTR": "0.03",
                "CPC": "$3.19",
                "Cost": "$134,300",
                "Conversions": "4638",
                "Conversion rate": "0.11",
                "Cost per Conversion": "$29"
            }, {
                "Platform": "Facebook",
                "Clicks": "7,025",
                "Impressions": "20,716",
                "CTR": "0.03",
                "CPC": "$4.81",
                "Cost": "$37,500",
                "Conversions": "980",
                "Conversion rate": "0.14",
                "Cost per Conversion": "$34"
            }, {
                "Platform": "Instagram",
                "Clicks": "7,000",
                "Impressions": "20,000",
                "CTR": "0.05",
                "CPC": "$8.81",
                "Cost": "$30,000",
                "Conversions": "1,000",
                "Conversion rate": "0.20",
                "Cost per Conversion": "$54"
            }
        ]
        createDataTable($('#platformDetailsTable'), platformDetailData, [
            { data: 'Platform' },
            { data: 'Clicks' },
            { data: 'Impressions' },
            { data: 'CTR' },
            { data: 'CPC' },
            { data: 'Cost' },
            { data: 'Conversions' },
            { data: 'Conversion rate' },
            { data: 'Cost per Conversion' }
        ], true, true);

        //top five keywords table
        //change topFiveKeywordData for timeline
        var topFiveKeywordData = [
            {
                "Channel": "Adwords",
                "Campaign Name": "Offer-Cross-Sell",
                "Keywords": "electronics+gadget+usb",
                "Quality Score": "4.8",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Offer-Cross-Sell",
                "Keywords": "iphone adapter",
                "Quality Score": "4.3",
            }, {
                "Channel": "Facebook",
                "Campaign Name": "Offer-Cross-Sell",
                "Keywords": "headphone for kids",
                "Quality Score": "3.9",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Offer-Cross-Sell",
                "Keywords": "mac air",
                "Quality Score": "3.8",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Offer-Cross-Sell",
                "Keywords": "charger adapter",
                "Quality Score": "3.5",
            }

        ]
        createDataTable($('#topFiveDetailsTable'), topFiveKeywordData, [
            { data: 'Channel' },
            { data: 'Campaign Name' },
            { data: 'Keywords' },
            { data: 'Quality Score' },
        ], false, false);

        //bottom five keywords table
        //change bottomFiveKeywordData for timeline
        var bottomFiveKeywordData = [
            {
                "Channel": "Adwords",
                "Campaign Name": "Offer-Cross-Sell_A1",
                "Keywords": "car charger for laptop",
                "Quality Score": "1.0",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Offer-Cross-Sell_B",
                "Keywords": "straps - cable ties velcro",
                "Quality Score": "0.8",
            }, {
                "Channel": "Facebook",
                "Campaign Name": "Offer-Cross-Sell_B2",
                "Keywords": "power bank 15000",
                "Quality Score": "0.6",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Offer-Cross-Sell_C",
                "Keywords": "gaming laptop under 10000",
                "Quality Score": "0.4",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Offer-Cross-Sell_C3",
                "Keywords": "portable charger with outlet",
                "Quality Score": "0.2",
            }
        ]
        createDataTable($('#bottomFiveDetailsTable'), bottomFiveKeywordData, [
            { data: 'Channel' },
            { data: 'Campaign Name' },
            { data: 'Keywords' },
            { data: 'Quality Score' },
        ], false, false);

        //all details table
        //change allDetailTableData for timeline
        var allDetailTableData = [
            {
                "Channel": "Adwords",
                "Campaign Name": "Cn_Adwords",
                "Keywords": "Earphones",
                "Quality Score": "1.0",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Cn_Adwords",
                "Keywords": "Air Pods",
                "Quality Score": "0.89",
            }, {
                "Channel": "Facebook",
                "Campaign Name": "C2_fb",
                "Keywords": "Wireless Charger",
                "Quality Score": "0.82",
            }, {
                "Channel": "Adwords",
                "Campaign Name": "Cn_Adwords",
                "Keywords": "Charger",
                "Quality Score": "0.67",
            }
        ]
        createDataTable($('#allDetailsTable'), allDetailTableData, [
            { data: 'Channel' },
            { data: 'Campaign Name' },
            { data: 'Keywords' },
            { data: 'Quality Score' },
        ], false, false);

        // Keywords table
        $("#campaignSelect").change(function () {
            var selectedTime = $("#campaignSelect option:selected").val();
            console.log(selectedTime);
            if (selectedTime == "Channel") {
                $("#hideCampaignChannel").show();
                campaignTable.column(1).visible(true);
            } else if (selectedTime == "Keywords") {
                $("#hideCampaignKeyword").show();
                campaignTable.column(2).visible(true);
            } else {
                $("#hideCampaignChannel").hide();
                $("#hideCampaignKeyword").hide();
                campaignTable.column(1).visible(false);
                campaignTable.column(2).visible(false);
            }
        });
        $('#hideCampaignChannel').click(function () {
            $('#hideCampaignChannel').hide();
            campaignTable.column(1).visible(false);
        });
        $('#hideCampaignKeyword').click(function () {
            $('#hideCampaignKeyword').hide();
            campaignTable.column(2).visible(false);
        });
    }


});