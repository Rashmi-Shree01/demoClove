$('[data-toggle="popover"]').popover();

$(document).ready(function () {

    function createShoppingDataTable(idToUse, tableData, columns) {

        $("#" + idToUse).DataTable(
            {
                destroy: true,
                data: tableData,
                responsive: false,
                paging: true, // false
                lengthChange: false,
                bFilter: false,
                bInfo: false, // false
                scrollX: false,
                language: {
                    emptyTable: "Data not available",
                    "thousands": ",",
                    "decimals": "."
                },
                columns: columns
            });
        $('.dataTable').wrap('<div class="dataTables_scroll" />');
    }

    //merchant center products data
    var merchantCenterProductsData = [
        {
            "Target": "Google",
            "Name": "Primary Feed",
            "Processing Status": "Processed",
            "Type": "Primary",
            "Source": "Magento Store",
            "Country": "India",
            "Last Build": "2018-09-09",
            "Language": "en",
            "Currency": "INR",
            "Actions": "Send Feed"
        },
        {
            "Target": "Google",
            "Name": "Primary Feed",
            "Processing Status": "Processed",
            "Type": "Primary",
            "Source": "Recommended Products",
            "Country": "India",
            "Last Build": "2018-09-09",
            "Language": "en",
            "Currency": "INR",
            "Actions": "Send Feed"
        }
    ]

    //merchant center products columns
    var merchantCenterProductsColumn = [
        { data: "Target" },
        { data: "Name" },
        { data: "Processing Status" },
        { data: "Type" },
        { data: "Source" },
        { data: "Country" },
        { data: "Last Build" },
        { data: "Language" },
        { data: "Currency" },
        { data: "Actions" ,
            render: function(data,type,row){
                return "<a href='#' class='linkColor'>"+data+"</a>"
            }    
        }
    ]

    createShoppingDataTable('feedsTable', merchantCenterProductsData, merchantCenterProductsColumn);

    //campaigns data
    var campaignsData = [
        {
            "Campaign": "Primary",
            "Budget": "₹50.00",
            "Impressions": "4,143",
            "Clicks": "23",
            "CTR": "0.45%",
            "Avg CPC": "₹0.08",
            "Ad Spend": "₹2.13",
            "Conversions": "0.00",
            "Conversion Rate": "0.00%",
            "Cost/Conversion": "₹0.00",
            "Sales": "₹0.00"
        }
    ]

    //merchant center products columns
    var campaignsColumn = [
        { data: "Campaign" },
        { data: "Budget" },
        { data: "Impressions" },
        { data: "Clicks" },
        { data: "CTR" },
        { data: "Avg CPC" },
        { data: "Ad Spend" },
        { data: "Conversions" },
        { data: "Conversion Rate" },
        { data: "Cost/Conversion" },
        { data: "Sales" }
    ]

    createShoppingDataTable('campaignsTable', campaignsData, campaignsColumn);

    tableAlignment();
});