$('[data-toggle="popover"]').popover();

$(document).ready(function() {

    function customerChart(id, data, color) {
        var ctx = $("#"+id);
	    var chart = new Chart( ctx, {
            type: 'horizontalBar',
            maintainAspectRatio: false,
            data: {
                labels: [ "About to Churn","Cannot lose them","Champions","Churned out Customers",
                            "Loyalists","New Customers"],
                datasets: [ {
                    data: data,
                    borderColor: color,
                    borderWidth: "0",
                    backgroundColor:  color
                } ],
            },
            options: {
                legend: {
                    display: false,
                },
                scales : {
                    xAxes : [ {
                        ticks : {
                            beginAtZero : true
                        }
                    } ]
                },
                responsive : true
            }
        });
    }

    var customerSegmentData = [5886,3203,746,4071,2022,590];
    customerChart("customerSegment",customerSegmentData,"rgb(144,135,192)");

    //var avgLtvData = [40.50,37,112.66,24,75,710,400,110];
    //customerChart("avgLtvCustomerSegment",avgLtvData,"rgb(150,209,243)");

    var driftData = [
        {
            "PreviousReport" : "About to Churn",
            "CurrentReport" : "Champions",
            "Count" : "8",
            "Movement" : "Positive"
        },
        {
            "PreviousReport" : "About to Churn",
            "CurrentReport" : "Churned Out Customers",
            "Count" : "272",
            "Movement" : "Negative"
        },
        {
            "PreviousReport" : "About to Churn",
            "CurrentReport" : "Loyalists",
            "Count" : "17",
            "Movement" : "Positive"
        },
        {
            "PreviousReport" : "About to Churn",
            "CurrentReport" : "Cannot Lose Them",
            "Count" : "5",
            "Movement" : "Positive"
        }
    ]
    var driftColumns = [
        {data : "PreviousReport"},
        {data : "CurrentReport"},
        {data : "Count"},
        {data : "Movement",
        render: function(data,type,row){
            if(data.toLowerCase() == "positive"){
                return "<p style='color: limegreen'>"+data+"</p>";
            }else{
                return "<p style='color: red'>"+data+"</p>";
            }
        }
        }
    ]

    var customerDetail = [
        {
            "Customer" : "Jane Williams",
            "City" : "London",
            "LTV" : "$750",
            "Total Orders" : "4",
            "Avg Qty/Order" : "2",
            "Purchase Frequency" : "4",
            "Last Ordered Date" : "04-12-2018",
        },
        {
            "Customer" : "Sam West",
            "City" : "New York",
            "LTV" : "$240",
            "Total Orders" : "2",
            "Avg Qty/Order" : "3",
            "Purchase Frequency" : "2",
            "Last Ordered Date" : "03-01-2018",
        },
        {
            "Customer" : "Tim J",
            "City" : "Hong Kong",
            "LTV" : "$150",
            "Total Orders" : "2",
            "Avg Qty/Order" : "2",
            "Purchase Frequency" : "2",
            "Last Ordered Date" : "04-12-2018",
        },
        {
            "Customer" : "Sri Kant",
            "City" : "Delhi",
            "LTV" : "$290",
            "Total Orders" : "2",
            "Avg Qty/Order" : "2",
            "Purchase Frequency" : "3",
            "Last Ordered Date" : "06-11-2018",
        },
        {
            "Customer" : "Samson",
            "City" : "Chennai",
            "LTV" : "$350",
            "Total Orders" : "3",
            "Avg Qty/Order" : "4",
            "Purchase Frequency" : "3",
            "Last Ordered Date" : "07-11-2018",
        }
    ]
    var customerDetailColumns = [
        {data : "Customer"},
        {data : "City"},
        {data : "LTV"},
        {data : "Total Orders"},
        {data : "Avg Qty/Order"},
        {data : "Purchase Frequency"},
        {data : "Last Ordered Date"}
    ];
    
    createDataTable('advanceCustomerTable',customerDetail,customerDetailColumns);
    createDataTable('customerDriftTable',driftData,driftColumns);

    tableAlignment();
});