$(document).ready(function(){
    $.ajax({
        url: "dummyJsons/customerPage.json",
        type: "GET",
        success: function(response){
            
            var d = response['customerFunnel'];
            // const data = response['customerFunnel'];
            console.log(d);

            //var funnelData = [];
            const data = [
                { label: 'Landing', value: 10000 },
                { label: 'View Product', value: 8000 },
                { label: 'Added To Cart', value: 4125 },
                { label: 'Bought', value: 2015 }
            ];
            // var funnelData = [];
            // for(var i=0; i<d.length;i++) {
            //     funnelData.push(d[i]);
            // }

           //console.log(data)
            var obj = {};
            //customerFunnel(d);
            const funnelData = [];
            $.each(d,  function(key, val){
                //console.log(val['label']);
                obj = {label: val['label'], value: parseInt(val['value'])};
                //console.log(obj)
                funnelData.push(obj);
            })
            console.log(funnelData)

                // for(var i=0; i<data.length;i++) {
                //     funnelData.push(data[i]);
                // };
                // console.log(funnelData);

                const options = {
                    chart: {
                        width: 350,
                        height: 300,
                        animate: 200
                    },
                    block: {
                        dynamicHeight: true,
                        minHeight: 15,
                        fill: {
                            type: 'gradient',
                            scale: ['#9087c0','#96d1f3','#f489a7','#c5e5d6']
                        }
                    },
                    label: {
                        fontFamily: 'Open sans',
                        fontSize: 12,
                    },
                    tooltip: {
                        enabled: true
                    }
                };
            
                const chart = new D3Funnel('#funnel');
                chart.draw(funnelData, options);
            
            
            }
    });
    
})