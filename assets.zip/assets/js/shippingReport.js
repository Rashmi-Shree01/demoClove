$('[data-toggle="popover"]').popover();

$(document).ready(function () {
    var courierData1 = {
        label: ["Bluedart"],
        data: [163, 206, 183, 188, 148, 222, 161, 135, 89, 112, 86, 101],
        fill: false,
        tension: 0,
        borderColor: "rgb(144,135,192)",
        backgroundColor: 'transparent',
        pointRadius: 2,
        pointHoverRadius: 5,
        pointHitRadius: 30,
        pointBorderWidth: 1,
        borderWidth: 2
    }

    var courierData2 = {
        label: ["Dart Plus"],
        data: [162, 183, 152, 154, 148, 107, 148, 162, 123, 135, 127, 123],
        fill: false,
        tension: 0,
        borderColor: "rgb(150,209,243)",
        backgroundColor: 'transparent',
        pointRadius: 2,
        pointHoverRadius: 5,
        pointHitRadius: 30,
        pointBorderWidth: 1,
        borderWidth: 2
    }

    var courierData3 = {
        label: ["Delhivery"],
        data: [150, 200, 250, 200, 180, 150, 160, 260, 120, 100, 170, 190],
        fill: false,
        tension: 0,
        borderColor: "rgb(244,137,167)",
        backgroundColor: 'transparent',
        pointRadius: 2,
        pointHoverRadius: 5,
        pointHitRadius: 30,
        pointBorderWidth: 1,
        borderWidth: 2
    }

    var courierData4 = {
        label: ["Dotzot"],
        data: [170, 220, 170, 220, 200, 170, 180, 180, 150, 120, 190, 110],
        fill: false,
        tension: 0,
        borderColor: "rgb(197,229,214)",
        backgroundColor: 'transparent',
        pointRadius: 2,
        pointHoverRadius: 5,
        pointHitRadius: 30,
        pointBorderWidth: 1,
        borderWidth: 2
    }

    var courierData5 = {
        label: ["Ekart"],
        data: [130, 180, 130, 180, 160, 130, 140, 140, 110, 180, 150, 170],
        fill: false,
        tension: 0,
        borderColor: "rgb(231,180,211)",
        backgroundColor: 'transparent',
        pointRadius: 2,
        pointHoverRadius: 5,
        pointHitRadius: 30,
        pointBorderWidth: 1,
        borderWidth: 2
    }

    var courierData6 = {
        label: ["Fedex"],
        data: [100, 180, 120, 125, 140, 200, 150, 120, 70, 100, 80, 95],
        fill: false,
        tension: 0,
        borderColor: "rgb(71,120,230,0.92)",
        backgroundColor: 'transparent',
        pointRadius: 2,
        pointHoverRadius: 5,
        pointHitRadius: 30,
        pointBorderWidth: 1,
        borderWidth: 2
    }

    var courierData7 = {
        label: ["Xpressbees"],
        data: [80, 150, 80, 100, 130, 170, 140, 100, 135, 172, 180, 85],
        fill: false,
        tension: 0,
        borderColor: "rgb(248,202,177)",
        backgroundColor: 'transparent',
        pointRadius: 2,
        pointHoverRadius: 5,
        pointHitRadius: 30,
        pointBorderWidth: 1,
        borderWidth: 2
    }

    var courierData8 = {
        label: ["Gati"],
        data: [120, 130, 140, 125, 110, 130, 110, 120, 135, 125, 110, 110],
        fill: false,
        tension: 0,
        borderColor: "rgb(246,133,103)",
        backgroundColor: 'transparent',
        pointRadius: 2,
        pointHoverRadius: 5,
        pointHitRadius: 30,
        pointBorderWidth: 1,
        borderWidth: 2
    }

    var labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

    drawBarChartHere('line', 'carrierTrendChart', labels, [courierData1, courierData2, courierData3,
        courierData4, courierData5, courierData6, courierData7, courierData8], ["Time Period", "Orders"]);

    var returnData1 = {
        label: ["Bluedart"],
        data: [16, 20, 13, 18, 18, 22, 61, 35, 9, 12, 6, 11],
        fill: false,
        tension: 0,
        borderColor: "rgb(144,135,192)",
        backgroundColor: 'transparent',
        pointRadius: 2,
        pointHoverRadius: 5,
        pointHitRadius: 30,
        pointBorderWidth: 1,
        borderWidth: 2
    }

    var returnData2 = {
        label: ["Dart Plus"],
        data: [12, 83, 15, 14, 48, 7, 48, 62, 12, 35, 27, 23],
        fill: false,
        tension: 0,
        borderColor: "rgb(150,209,243)",
        backgroundColor: 'transparent',
        pointRadius: 2,
        pointHoverRadius: 5,
        pointHitRadius: 30,
        pointBorderWidth: 1,
        borderWidth: 2
    }

    var returnData3 = {
        label: ["Delhivery"],
        data: [50, 20, 25, 20, 80, 10, 60, 60, 10, 10, 17, 90],
        fill: false,
        tension: 0,
        borderColor: "rgb(244,137,167)",
        backgroundColor: 'transparent',
        pointRadius: 2,
        pointHoverRadius: 5,
        pointHitRadius: 30,
        pointBorderWidth: 1,
        borderWidth: 2
    }

    var returnData4 = {
        label: ["Dotzot"],
        data: [10, 20, 10, 20, 20, 10, 10, 10, 10, 10, 10, 10],
        fill: false,
        tension: 0,
        borderColor: "rgb(197,229,214)",
        backgroundColor: 'transparent',
        pointRadius: 2,
        pointHoverRadius: 5,
        pointHitRadius: 30,
        pointBorderWidth: 1,
        borderWidth: 2
    }

    var returnData5 = {
        label: ["Ekart"],
        data: [30, 80, 30, 10, 60, 30, 10, 40, 11, 80, 15, 17],
        fill: false,
        tension: 0,
        borderColor: "rgb(231,180,211)",
        backgroundColor: 'transparent',
        pointRadius: 2,
        pointHoverRadius: 5,
        pointHitRadius: 30,
        pointBorderWidth: 1,
        borderWidth: 2
    }

    var returnData6 = {
        label: ["Fedex"],
        data: [10, 10, 20, 15, 40, 20, 10, 20, 7, 10, 8, 5],
        fill: false,
        tension: 0,
        borderColor: "rgb(71,120,230,0.92)",
        backgroundColor: 'transparent',
        pointRadius: 2,
        pointHoverRadius: 5,
        pointHitRadius: 30,
        pointBorderWidth: 1,
        borderWidth: 2
    }

    var returnData7 = {
        label: ["Xpressbees"],
        data: [8, 50, 0, 10, 30, 10, 14, 10, 15, 12, 18, 85],
        fill: false,
        tension: 0,
        borderColor: "rgb(248,202,177)",
        backgroundColor: 'transparent',
        pointRadius: 2,
        pointHoverRadius: 5,
        pointHitRadius: 30,
        pointBorderWidth: 1,
        borderWidth: 2
    }

    var returnData8 = {
        label: ["Gati"],
        data: [12, 30, 14, 15, 10, 13, 11, 20, 35, 15, 10, 11],
        fill: false,
        tension: 0,
        borderColor: "rgb(246,133,103)",
        backgroundColor: 'transparent',
        pointRadius: 2,
        pointHoverRadius: 5,
        pointHitRadius: 30,
        pointBorderWidth: 1,
        borderWidth: 2
    }

    drawBarChartHere('line', 'carrierReturnsTrendChart', labels, [returnData1, returnData2, returnData3,
        returnData4, returnData5, returnData6, returnData7, returnData8], ["Time Period", "Returns"]);

    var totalSales = {
        label: ["Total Sales"],
        data: [300, 200, 150, 350, 500, 330, 270, 250, 300, 260, 230, 340],
        fill: false,
        tension: 0,
        borderColor: "rgb(144,135,192)",
        backgroundColor: 'transparent',
        pointRadius: 2,
        pointHoverRadius: 5,
        pointHitRadius: 30,
        pointBorderWidth: 1,
        borderWidth: 2
    }

    var codReceived = {
        label: ["COD Received"],
        data: [180, 120, 100, 200, 300, 230, 170, 150, 180, 140, 150, 210],
        fill: false,
        tension: 0,
        borderColor: "rgb(150,209,243)",
        backgroundColor: 'transparent',
        pointRadius: 2,
        pointHoverRadius: 5,
        pointHitRadius: 30,
        pointBorderWidth: 1,
        borderWidth: 2
    }

    var codReceivable = {
        label: ["COD Receivable"],
        data: [120, 80, 50, 150, 200, 100, 100, 100, 120, 120, 80, 130],
        fill: false,
        tension: 0,
        borderColor: "rgb(244,137,167)",
        backgroundColor: 'transparent',
        pointRadius: 2,
        pointHoverRadius: 5,
        pointHitRadius: 30,
        pointBorderWidth: 1,
        borderWidth: 2
    }

    drawBarChartHere('line', 'codSalesChart', labels, [totalSales, codReceived, codReceivable],
        ["Time Period", "Amount"]);

    var codByGeography = [
        {
            "Count": "253",
            "City": "Bangalore",
            "State": "Karnataka"
        },
        {
            "Count": "200",
            "City": "Mumbai",
            "State": "Maharastra"
        },
        {
            "Count": "300",
            "City": "Hyderabad",
            "State": "Telangana"
        },
    ];
    var byGeographyColumns = [
        {data: "Count"},
        {data: "City"},
        {data: "State"}
    ];
    populateTable(codByGeography, byGeographyColumns, "codByGeographyTable");

    var rtoByGeography = [
        {
            "Count": "25",
            "City": "Pune",
            "State": "Maharastra"
        },
        {
            "Count": "20",
            "City": "Kasaragod",
            "State": "Kerala"
        },
        {
            "Count": "30",
            "City": "Bhopal",
            "State": "Madhya Pradesh"
        },
    ];
    populateTable(rtoByGeography, byGeographyColumns, "rtoByGeographyTable");

    var highRtoCustomers = [
        {
            "Customer Name": "Ananya P",
            "No of Orders": "20",
            "No of RTO": "15"
        },
        {
            "Customer Name": "Sanjay Behl",
            "No of Orders": "15",
            "No of RTO": "13"
        },
        {
            "Customer Name": "Sanya Malhotra",
            "No of Orders": "14",
            "No of RTO": "12"
        },
    ];
    var highRtoCustomersColumns = [
        {data: "Customer Name"},
        {data: "No of Orders"},
        {data: "No of Orders"}
    ];
    populateTable(highRtoCustomers, highRtoCustomersColumns, "highRtoCustomersTable");

    var highCodCustomers = [
        {
            "Customer Name": "Saranya Sahu",
            "No of COD Orders": "30"
        },
        {
            "Customer Name": "Rakesh Sharma",
            "No of COD Orders": "25"
        },
        {
            "Customer Name": "Kavya",
            "No of COD Orders": "14"
        },
    ];
    var highCodCustomersColumns = [
        {data: "Customer Name"},
        {data: "No of COD Orders"}
    ];
    populateTable(highCodCustomers, highCodCustomersColumns, "highCodTable");
    //function to draw charts
    function drawBarChartHere(type, idToUse, label, data, axisName) {

        $.each(charts, function (index, bar) {
            if (bar['id'] == idToUse) {
                bar['object'].destroy();
            }
        })
        var parent = $("#" + idToUse).parent();
        $(parent).html("");
        $(parent).append("<canvas id='" + idToUse + "' />");
        var ctx = $('#' + idToUse);
        var chart = new Chart(ctx, {
            type: type,
            data: {
                labels: label,
                datasets: data
            },
            options: {
                legend: {
                    display: true,
                    position: 'top',
                    labels: {
                        boxWidth: 10,
                        fontSize: 10
                    }
                },
                scales: {
                    xAxes: [{
                        scaleLabel: {
                            display: true,
                            labelString: axisName[0]
                        },
                        ticks: {
                            stepSize: 1,
                            min: 0,
                            autoSkip: false
                        }
                    }],
                    yAxes: [{
                        scaleLabel: {
                            display: true,
                            labelString: axisName[1]
                        },
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                },
                responsive: true,
                title: {
                    display: false
                }
            }
        });
        var index = -1;
        $.each(charts, function (i, bar) {
            if (bar['id'] == idToUse) {
                index = i;
            }
        })
        if (index != -1) {
            charts.splice(index, 1);
        }
        var bar = {
            id: idToUse,
            object: chart
        }
        charts.push(bar);
    };

    function populateTable(dataRequired, columnsRequired, idToUse) {

        $("#"+idToUse).DataTable({
            order: [],
            data: dataRequired,
            destroy: true,
            paging : false,
            bFilter: false,
            destroy : true,
            bInfo: false,
            language: {
                emptyTable: "Data not available"
            },
            columns: columnsRequired
        });
        $('.dataTable').wrap('<div class="dataTables_scroll" />');
    }

    //table alignment
    $('td').filter(function() {
        return this.innerHTML.match(/^[0-9\%\$\s\-\.,]+$/);
    }).css('text-align','right');
});