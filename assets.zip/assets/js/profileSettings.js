$(document).ready(function() {
    $("div.profile-tab-menu>div.list-group>a").click(function(e) {
        e.preventDefault();
        $(this).siblings('a.active').removeClass("active");
        $(this).addClass("active");
        var index = $(this).index();
        $("div.profile-tab>div.profile-tab-content").removeClass("active");
        $("div.profile-tab>div.profile-tab-content").eq(index).addClass("active");
    });

    var userDetailData = [
            {
                "Name"          :   "Bill G",
                "Recipient ID"  :   "billyg@gmail.com",
                "Password"      :   "**********",
                "Permissions"   :   "View",
                ""              :   "Manage",
                ""              :   "Remove"
            }
    ]
    
    // $("#userDetails").DataTable({
    //     order : [],
    //     data : userDetailData,
    //     paging : true,
    //     bFilter: false,
    //     "scrollX": true,
    //     sDom: "<'row'<'col-sm-12'tr>>" +
    //              "<'row'<'col-sm-4'i><'col-sm-8'p>>" ,
    //     language : {
    //         emptyTable : "Data not available"
    //     },
    //     columns : [ 
    //                 { data : 'Name'},
    //                 { data : 'Recipient ID' },   
    //                 { data : 'Password' },
    //                 { data : 'Permissions' },
    //                 { data : '' },
    //                 { data : ''}
    //     ]
    // });
    $('.dataTable').wrap('<div class="dataTables_scroll" />');
    $('.removeRow').click(function () {
        $(this).parents("tr").remove();
    });
    // $("#something").o
    //     $(this).parent("tr:first").remove()
    //   })
});